package com.sssports.sssports.ui.widgets.checkoutsummary;

import com.sssports.sssports.ui.checkoutbilling.builder.OnSummaryReadyListener;

/**
 * Created by mlukovic on 9/5/17.
 */

public interface WidgetOrderSummaryListener {

    void onRefreshSummaryRequested(OnSummaryReadyListener onSummaryReadyListener);
}
