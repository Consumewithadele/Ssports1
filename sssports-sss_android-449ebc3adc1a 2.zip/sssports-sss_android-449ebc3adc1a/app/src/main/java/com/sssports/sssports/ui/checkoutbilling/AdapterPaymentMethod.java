package com.sssports.sssports.ui.checkoutbilling;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.magento.PaymentMethod;
import com.sssports.sssports.util.CommonConstants;

import java.util.List;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class AdapterPaymentMethod extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<PaymentMethod> paymentMethods;
    private OnPaymentMethodClick onPaymentMethodClick;
    private Activity activity;

    public AdapterPaymentMethod(List<PaymentMethod> paymentMethods, Activity activity) {
        this.paymentMethods = paymentMethods;
        this.activity = activity;
    }

    public void setOnPaymentMethodClick(final OnPaymentMethodClick onPaymentMethodClick) {
        this.onPaymentMethodClick = onPaymentMethodClick;
    }

    class PaymentMethodHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public ImageView ivPaymentMethodIcon;
        public TextView tvPaymentMethodName;
        public ImageView ivCheckmark;
        public RelativeLayout rlPaymentMethod;

        public PaymentMethodHolder(View itemView) {
            super(itemView);

            ivPaymentMethodIcon = itemView.findViewById(R.id.iv_payment_method_icon);
            tvPaymentMethodName = itemView.findViewById(R.id.tv_payment_method_name);
            ivCheckmark = itemView.findViewById(R.id.iv_check_mark);
            rlPaymentMethod = itemView.findViewById(R.id.rl_payment_method);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (onPaymentMethodClick != null && !paymentMethods.get(getAdapterPosition()).isSelected()) {
                onPaymentMethodClick.onItemClick(v, getLayoutPosition());
            }
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        View v;

        v = LayoutInflater.from(parent.getContext()).inflate(R.layout.payment_method_item, parent, false);
        viewHolder = new PaymentMethodHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        PaymentMethod paymentMethod = paymentMethods.get(position);
        PaymentMethodHolder paymentMethodHolder = (PaymentMethodHolder) holder;

        if (paymentMethod.getCode().equalsIgnoreCase(CommonConstants.CASH_ON_DELIVERY_PAYMENT)) {
            paymentMethodHolder.ivPaymentMethodIcon.setImageResource(R.drawable.ic_cod);
            paymentMethodHolder.tvPaymentMethodName.setText(R.string.cach_on_delivery);
        } else if (paymentMethod.getCode().equalsIgnoreCase(CommonConstants.CREDIT_DEBIT_CARD_PAYMENT)) {
            paymentMethodHolder.ivPaymentMethodIcon.setImageResource(R.drawable.ic_cc);
            paymentMethodHolder.tvPaymentMethodName.setText(R.string.credit_debit_card_payment);
        }

        if (paymentMethod.isSelected()) {
            paymentMethodHolder.ivCheckmark.setVisibility(View.VISIBLE);
            paymentMethodHolder.rlPaymentMethod.setBackground(activity.getResources().getDrawable(R.drawable.rectangle_vd));
        } else {
            paymentMethodHolder.ivCheckmark.setVisibility(View.GONE);
            paymentMethodHolder.rlPaymentMethod.setBackgroundColor(activity.getResources().getColor(R.color.munsell));
        }
    }

    @Override
    public int getItemCount() {
        return paymentMethods.size();
    }

    public interface OnPaymentMethodClick {
        void onItemClick(View view, int position);

    }
}
