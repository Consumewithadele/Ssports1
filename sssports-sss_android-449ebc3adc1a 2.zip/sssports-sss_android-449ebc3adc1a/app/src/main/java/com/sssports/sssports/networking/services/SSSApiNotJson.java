package com.sssports.sssports.networking.services;

import com.sssports.sssports.models.custom.Token;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

/**
 * Created by Adeleclark on 9/10/17.
 */

public interface SSSApiNotJson {

    @FormUrlEncoded
    @POST("/oauth/token")
    Observable<Token>  getAuthToken(@Field("grant_type") String grantType, @Field("client_id") int clientId, @Field("client_secret") String clientSecret);
}
