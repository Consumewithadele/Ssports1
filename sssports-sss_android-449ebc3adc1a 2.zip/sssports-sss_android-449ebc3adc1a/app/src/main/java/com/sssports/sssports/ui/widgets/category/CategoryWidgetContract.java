package com.sssports.sssports.ui.widgets.category;

import com.sssports.sssports.models.jsonapi.Block;

import java.util.List;

/**
 * Contract for implementing MVP pattern for Category Widget
 */

public class CategoryWidgetContract {

    interface CategoryWidgetView {

        void showLoader();

        void showCategories(List<Block> blockList);

        void showError();

        void showTitle(String label);

        void showDescription(String text);

        void hideTitle();

        void hideDescription();

        void hideWidget();
    }

    interface CategoryWidgetPresenter {

        void loadData();
    }
}
