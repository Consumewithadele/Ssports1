package com.sssports.sssports.util;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public class CommonConstants {

    public static final String INTENT_FRAGMENT_ID = "intent_fragment_id";
    public static final String INTENT_AVAILABLE_SHIPPING_METHODS = "intent_available_shipping_methods";
    public static final String SIZE = "size";
    public static final String COLOR = "color";
    public static final String INCLUDE_CONFIG = "config";
    public static final String CASH_ON_DELIVERY_PAYMENT = "cashondelivery";
    public static final String CREDIT_DEBIT_CARD_PAYMENT = "cybersource";
    public static final String INTENT_ORDER_ID = "intent_order_id";
    public static final String INTENT_SAVE_DATA = "intent_save_data";

    public class FragmentId {

        public static final int FRAGMENT_HOME_PAGE = 1;
        public static final int FRAGMENT_MAIN_CATEGORY = 2;
        public static final int FRAGMENT_CATEGORY = 3;
        public static final int FRAGMENT_SHOP_BY_BRAND = 4;
        public static final int FRAGMENT_PLP = 5;
    }

    public static final String INTENT_PRODUCT_ID = "intent_product_id";
    public static final String INTENT_PRODUCT_SKU = "intent_product_sku";
    public static final String PRODUCT_DETAILS_TYPE_USP = "product_details_type_usp";
    public static final String BUNDLE_PRODUCT = "bundle_product";
    public static final String LOCALE_KEY = "locale";
    public static final int DIALOG_ONE_BUTTON = 1;
    public static final int DIALOG_TWO_BUTTONS = 2;
    public static final int DIALOG_LOADER = 3;
    public static final String EMPTY_STRING = "";
    public static String PHONE_NUMBER_TO_CALL = "+971 04 314 9001";
    public static final int DIALOG_THREE_OPTIONS = 3;
    public static final int DIALOG_TWO_OPTIONS = 2;
    public static final int DIALOG_ONE_OPTION = 1;
}
