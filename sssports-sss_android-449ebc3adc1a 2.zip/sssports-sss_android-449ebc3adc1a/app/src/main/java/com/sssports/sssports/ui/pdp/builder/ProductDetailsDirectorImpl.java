package com.sssports.sssports.ui.pdp.builder;

import android.app.Activity;
import android.widget.LinearLayout;

import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.ui.widgets.contact.WidgetTypeContact;
import com.sssports.sssports.ui.widgets.productdetail.ProductDetailListener;
import com.sssports.sssports.util.CommonConstants;

import java.util.ArrayList;

import timber.log.Timber;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public class ProductDetailsDirectorImpl implements ProductDetailsDirector {

    private Product product;
    private ProductDetailsBuilder productDetailsBuilder;
    private WidgetTypeContact.OnCallClickListener onCallClickListener;

    public ProductDetailsDirectorImpl(LinearLayout productDetailsLayout, Product product, Activity activity, WidgetTypeContact.OnCallClickListener onCallClickListener) {
        this.product = product;
        this.onCallClickListener = onCallClickListener;
        productDetailsBuilder = new ProductDetailsBuilderImpl(productDetailsLayout, activity);
    }

    @Override
    public void construct(ProductDetailListener productDetailListener) {
        try {

            productDetailsBuilder.buildProductDetail(product, productDetailListener);
            productDetailsBuilder.buildProductDetailsContact(product, onCallClickListener);
            productDetailsBuilder.buildProductDetailsTwoTabs(product);
            productDetailsBuilder.buildProductDetailsUSP();
            productDetailsBuilder.buildProductDetailsShopAll(product);
        } catch (Exception e) {
            Timber.d("Error construct(): " + e.toString());
        }
    }
}
