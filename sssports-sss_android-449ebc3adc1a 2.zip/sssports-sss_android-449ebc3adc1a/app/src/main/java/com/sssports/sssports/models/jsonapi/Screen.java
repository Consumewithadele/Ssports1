package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import java.io.Serializable;
import java.util.List;

import moe.banana.jsonapi2.HasMany;
import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by mlukovic on 7/23/17.
 */
@JsonApi(type = "screens")
public class Screen extends Resource implements Serializable {

    @Json(name = "created_at")
    private String createdAt;
    @Json(name = "updated_at")
    private String updatedAt;
    @Json(name = "title")
    private String title;
    @Json(name = "kind")
    private String kind;
    @Json(name = "status")
    private Integer status;
    @Json(name = "locale")
    private String locale;
    @Json(name = "widget_schema")
    private List<String> widgetSchema = null;

    //Relationship

    @Json(name = "widgets")
    private HasMany<Widget> widgets = null;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public List<String> getWidgetSchema() {
        return widgetSchema;
    }

    public void setWidgetSchema(List<String> widgetSchema) {
        this.widgetSchema = widgetSchema;
    }

    public List<Widget> getWidgets() {
        return widgets.get(getContext());
    }

}
