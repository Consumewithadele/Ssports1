package com.sssports.sssports.di.component;

import android.app.Activity;

import com.sssports.sssports.di.PerActivity;
import com.sssports.sssports.di.modules.ActivityModule;

import dagger.Component;

/**
 * A component which will live during the lifetime of an activity.
 */

@PerActivity
@Component (dependencies = ApplicationComponent.class, modules = ActivityModule.class)
public interface ActivityComponent {

    //Exposed to sub-graphs.
    Activity activity();
}
