package com.sssports.sssports.ui.main.shopbybrand;


import com.hannesdorfmann.mosby3.mvp.MvpPresenter;
import com.hannesdorfmann.mosby3.mvp.MvpView;
import com.sssports.sssports.models.jsonapi.Brand;

import java.util.List;

/**
 * Created by natalijaratajac on 7/31/17.
 */

public class ShopByBrandContract {

    interface ShopByBrandFragmentView extends MvpView {

        void showBrandList(List<Brand> brandList);

        void showBrandLogos(List<Brand> brandLogoList);

        void showLoading();

        void hideLoading();

        void showError();
    }

    interface ShopByBrandFragmentPresenter extends MvpPresenter<ShopByBrandFragmentView> {

        void loadData();
    }
}
