package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;
import com.sssports.sssports.models.jsonapi.BillingAddress;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class PaymentInformation {

    @Json(name = "email")
    private String email;
    @Json(name = "payment_method")
    private PaymentData paymentData;
    @Json(name = "billingAddress")
    private UserDetailsDto billingAddress;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public PaymentData getPaymentData() {
        return paymentData;
    }

    public void setPaymentData(PaymentData paymentData) {
        this.paymentData = paymentData;
    }

    public UserDetailsDto getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(UserDetailsDto billingAddress) {
        this.billingAddress = billingAddress;
    }
}
