package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;
import com.sssports.sssports.models.custom.CardDetails;

import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by mlukovic on 9/17/17.
 */

@JsonApi(type = "orders")
public class Order extends Resource {

    @Json(name = "payment_method")
    private String paymentMethod;
    @Json(name = "cart_id")
    private String cartId;
    @Json(name = "billing_address")
    private BillingAddress billingAddress;
    @Json(name = "card")
    private CardDetails card;
    @Json(name = "amount")
    private String amount;
    @Json(name = "currency_code")
    private String currencyCode;
    @Json(name = "increment_id")
    private String orderNumber;

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getCartId() {
        return cartId;
    }

    public void setCartId(String cartId) {
        this.cartId = cartId;
    }

    public BillingAddress getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }

    public CardDetails getCard() {
        return card;
    }

    public void setCard(CardDetails card) {
        this.card = card;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }


    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }
}
