package com.sssports.sssports.ui.widgets.blog;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.main.MainScreenListener;
import com.sssports.sssports.ui.widgets.WidgetType;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;


/**
 * Main class responsible for building Category Widget layout and functionality
 *
 */

public class WidgetTypeBlogPost implements WidgetType, WidgetBlogPostContract.WidgetBlogPostView {

    private Activity mActivity;
    private Widget mWidget;
    private WidgetBlogPostContract.WidgetBlogPostPresenter mBlogPostPresenter;

    @BindView(R.id.image_view_hero_widget) ImageView ivBackgroundImage;
    @BindView(R.id.text_view_hero_title) TextView tvTitle;
    @BindView(R.id.btn_call_to_action_1) Button btnCTA1;
    @BindView(R.id.btn_call_to_action_2) Button btnCTA2;
    @BindView(R.id.button_watch_video) Button btnWatchVideo;
    @BindView(R.id.ic_play_video) ImageView ivPlayVideo;
//    @BindView(R.id.space1) Space space1;
//    @BindView(R.id.space2) Space space2;
    @BindView(R.id.text_view_hero_description) TextView tvDescription;
    @BindView(R.id.ll_hero_widget) LinearLayout llWidget;

    public WidgetTypeBlogPost(Activity activity, Widget widget) {
        mActivity = activity;
        mWidget = widget;
    }

    @Override
    public View buildView() {
        View widgetBlogPostView = mActivity.getLayoutInflater().inflate(R.layout.adapter_hero_widget, null);
        ButterKnife.bind(this, widgetBlogPostView);

        mBlogPostPresenter = new WidgetBlogPostPresenterImpl(this, mWidget);
        mBlogPostPresenter.loadData();

        return widgetBlogPostView;
    }

    @OnClick({R.id.button_watch_video, R.id.ic_play_video})
    void onVideoButtonClick() {
        mBlogPostPresenter.loadVideo();
    }

    @OnClick(R.id.btn_call_to_action_1)
    void onCallToAction1Click() {
        mBlogPostPresenter.loadAction(0);
    }

    @OnClick(R.id.btn_call_to_action_2)
    void onCallToAction2Click() {
        mBlogPostPresenter.loadAction(1);
    }

    @Override
    public void showLoader() {
        //TODO implement if we will go with lazy loading
    }

    @Override
    public void showError() {

    }

    @Override
    public void showTitle(String label) {
        tvTitle.setText(label);
    }

    @Override
    public void showDescription(String text) {
        tvDescription.setText(text);
    }

    @Override
    public void hideTitle() {
        tvTitle.setVisibility(View.GONE);
    }

    @Override
    public void hideDescription() {
        tvDescription.setVisibility(View.GONE);
    }

    @Override
    public void hideWidget() {
        llWidget.setVisibility(View.GONE);
    }


    @Override
    public void showCTA1(String text) {
        btnCTA1.setText(text);
        btnCTA1.setVisibility(View.VISIBLE);
//        setSpace1Visibility();
    }

//    private void setSpace1Visibility() {
//        if (btnCTA1.getVisibility() == View.VISIBLE && btnCTA2.getVisibility() == View.VISIBLE) {
//            space1.setVisibility(View.VISIBLE);
//        } else {
//            space1.setVisibility(View.GONE);
//        }
//    }

    @Override
    public void hideCTA1() {
        btnCTA1.setVisibility(View.GONE);
//        setSpace1Visibility();
    }

    @Override
    public void showCTA2(String text) {
        btnCTA2.setText(text);
        btnCTA2.setVisibility(View.VISIBLE);
//        setSpace1Visibility();
    }

    @Override
    public void hideCTA2() {
        btnCTA2.setVisibility(View.GONE);
//        setSpace1Visibility();
    }

    @Override
    public void showVideo() {
        tvTitle.setVisibility(View.GONE);
        btnWatchVideo.setVisibility(View.VISIBLE);
        ivPlayVideo.setVisibility(View.VISIBLE);
//        space1.setVisibility(View.GONE);
    }

    @Override
    public void playVideo(String videoUrl) {
        Intent youtubeIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl));
        //TODO see if it's better fullscreen or portrait mode?
        youtubeIntent.putExtra("force_fullscreen",true);
        mActivity.startActivity(youtubeIntent);
    }

    @Override
    public void showErrorLoadingContent() {
        Snackbar.make(mActivity.findViewById(R.id.rl_fragment_home), R.string.error_while_loading_content, Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public void openLink(String link) {
        ((BaseActivity)mActivity).getNavigator().openLink(mActivity, link);
    }

    @Override
    public void showHeaderImage(String imageUrl) {
        GlideApp.with(mActivity)
                .load(imageUrl)
                .transition(withCrossFade())
                .placeholder(R.drawable.loading_placeholder)
                .error(R.drawable.loading_placeholder)
                .into(ivBackgroundImage);
    }
}
