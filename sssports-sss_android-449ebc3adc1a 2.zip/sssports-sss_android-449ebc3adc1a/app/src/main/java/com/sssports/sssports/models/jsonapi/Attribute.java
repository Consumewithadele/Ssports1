package com.sssports.sssports.models.jsonapi;

import android.os.Parcel;
import android.os.Parcelable;

import com.squareup.moshi.Json;
import com.sssports.sssports.models.meta.Pricing;

import java.io.Serializable;
import java.util.List;

import moe.banana.jsonapi2.HasMany;
import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by mlukovic on 8/7/17.
 */

@JsonApi(type = "attributes")
public class Attribute extends Resource {

//    private final static long serialVersionUID = -5817314187476354173L;
    @Json(name = "attribute_id")
    private Integer attributeId;
    @Json(name = "attribute_code")
    private String attributeCode;
    @Json(name = "is_required")
    private Integer isRequired;
    @Json(name = "default_value")
    private String defaultValue;
    @Json(name = "is_filterable")
    private Integer isFilterable;
    @Json(name = "is_visible")
    private Integer isVisible;
    @Json(name = "position")
    private Integer position;
    @Json(name = "label")
    private String label;
    @Json(name = "is_searchable")
    private Integer isSearchable;
    @Json(name = "is_comparable")
    private Integer isComparable;
    //Custom attribute
    private Pricing pricing;

    //Relationships
    @Json(name = "options")
    private HasMany<Option> optionList;

    public Integer getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(Integer attributeId) {
        this.attributeId = attributeId;
    }

    public String getAttributeCode() {
        return attributeCode;
    }

    public void setAttributeCode(String attributeCode) {
        this.attributeCode = attributeCode;
    }

    public Integer getIsRequired() {
        return isRequired;
    }

    public void setIsRequired(Integer isRequired) {
        this.isRequired = isRequired;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public Integer getIsFilterable() {
        return isFilterable;
    }

    public void setIsFilterable(Integer isFilterable) {
        this.isFilterable = isFilterable;
    }

    public Integer getIsVisible() {
        return isVisible;
    }

    public void setIsVisible(Integer isVisible) {
        this.isVisible = isVisible;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Integer getIsSearchable() {
        return isSearchable;
    }

    public void setIsSearchable(Integer isSearchable) {
        this.isSearchable = isSearchable;
    }

    public Integer getIsComparable() {
        return isComparable;
    }

    public void setIsComparable(Integer isComparable) {
        this.isComparable = isComparable;
    }

    public List<Option> getOptionList() {
        if (optionList == null) return null;
        return optionList.get(getContext());
    }

    public Pricing getPricing() {
        return pricing;
    }

    public void setPricing(Pricing pricing) {
        this.pricing = pricing;
    }

}
