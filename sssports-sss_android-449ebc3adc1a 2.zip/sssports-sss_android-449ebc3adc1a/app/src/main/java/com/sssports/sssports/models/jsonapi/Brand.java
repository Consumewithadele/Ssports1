package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import java.io.Serializable;

import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by natalijaratajac on 7/31/17.
 */
@JsonApi(type = "brands")
public class Brand extends Resource implements Serializable {

    @Json(name = "name")
    private String name;
    @Json(name = "slug")
    private String slug;
    @Json(name = "thumbnail_image")
    private String imageUrl;
    @Json(name = "featured")
    private String featured;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getFeatured() {
        return featured;
    }

    public void setFeatured(String featured) {
        this.featured = featured;
    }
}
