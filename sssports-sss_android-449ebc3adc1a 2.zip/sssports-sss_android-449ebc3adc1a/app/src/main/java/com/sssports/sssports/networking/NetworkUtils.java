package com.sssports.sssports.networking;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * Created by Adeleclark on 8/2/17.
 */

public class NetworkUtils {

    public static final String getLastSegmentOfPath(String uriString) {
        URI uri;
        String idStr = null;
        try {
            uri = new URI(uriString);
            String[] segments = uri.getPath().split("/");
            idStr = segments[segments.length-1];
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        return idStr;
    }

    public static boolean isOnline(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
        return (netInfo != null && netInfo.isConnected());
    }
}
