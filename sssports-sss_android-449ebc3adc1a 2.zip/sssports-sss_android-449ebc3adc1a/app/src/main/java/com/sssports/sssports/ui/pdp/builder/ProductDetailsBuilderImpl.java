package com.sssports.sssports.ui.pdp.builder;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;

import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.ui.widgets.multiselection.WidgetTypeProductConfiguration;
import com.sssports.sssports.ui.widgets.contact.WidgetTypeContact;
import com.sssports.sssports.ui.widgets.productdetail.ProductDetailListener;
import com.sssports.sssports.ui.widgets.productdetail.WidgetTypeProductDetail;
import com.sssports.sssports.ui.widgets.shopall.WidgetShopAll;
import com.sssports.sssports.ui.widgets.tab.WidgetTypeTab;
import com.sssports.sssports.ui.widgets.uspbar.WidgetTypeUspBarWithIcons;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public class ProductDetailsBuilderImpl implements ProductDetailsBuilder {

    private LinearLayout productDetailsLayout;
    private Activity activity;

    public ProductDetailsBuilderImpl(LinearLayout productDetailsLayout, Activity activity) {
        this.productDetailsLayout = productDetailsLayout;
        this.activity = activity;
    }

    @Override
    public void buildProductDetail(Product product, ProductDetailListener productDetailListener) {

        WidgetTypeProductDetail widgetTypeProductDetail = new WidgetTypeProductDetail(activity, product, false, productDetailListener);
        View productDetailView = widgetTypeProductDetail.buildView();

        productDetailsLayout.addView(productDetailView);
    }

    @Override
    public void buildProductDetailsContact(Product product, WidgetTypeContact.OnCallClickListener onCallClickListener) {

        WidgetTypeContact widgetTypeContact = new WidgetTypeContact(activity);
        View contactView = widgetTypeContact.buildView();
        widgetTypeContact.setOnCallClickListener(onCallClickListener);

        productDetailsLayout.addView(contactView);
    }

    @Override
    public void buildProductDetailsUSP() {

        WidgetTypeUspBarWithIcons widgetTypeUspBarWithIcons = new WidgetTypeUspBarWithIcons(activity);
        View uspView = widgetTypeUspBarWithIcons.buildView();

        productDetailsLayout.addView(uspView);
    }

    @Override
    public void buildProductDetailsTwoTabs(Product product) {

        WidgetTypeTab widgetTypeTab = new WidgetTypeTab(activity, product);
        View tabView = widgetTypeTab.buildView();

        productDetailsLayout.addView(tabView);
    }

    @Override
    public void buildProductDetailsShopAll(Product product) {
        WidgetShopAll widgetShopAll = new WidgetShopAll(activity, product);
        View shopAllView = widgetShopAll.buildView();

        productDetailsLayout.addView(shopAllView);
    }

}
