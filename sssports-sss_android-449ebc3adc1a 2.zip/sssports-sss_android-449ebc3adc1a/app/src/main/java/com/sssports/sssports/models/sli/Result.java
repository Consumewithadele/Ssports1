
package com.sssports.sssports.models.sli;

import java.util.List;
import com.squareup.moshi.Json;

public class Result {

    @Json(name = "title")
    private String title;
    @Json(name = "url")
    private String url;
    @Json(name = "text")
    private String text;
    @Json(name = "rank")
    private Integer rank;
    @Json(name = "s_id")
    private Integer sId;
    @Json(name = "image_url")
    private String imageUrl;
    @Json(name = "name")
    private String name;
    @Json(name = "description")
    private String description;
    @Json(name = "sku")
    private String sku;
    @Json(name = "id")
    private String id;
    @Json(name = "price")
    private String price;
    @Json(name = "final_price")
    private String finalPrice;
    @Json(name = "on_sale")
    private String onSale;
    @Json(name = "image")
    private String image;
    @Json(name = "suggestions")
    private List<Suggestion> suggestions = null;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Integer getSId() {
        return sId;
    }

    public void setSId(Integer sId) {
        this.sId = sId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(String finalPrice) {
        this.finalPrice = finalPrice;
    }

    public String getOnSale() {
        return onSale;
    }

    public void setOnSale(String onSale) {
        this.onSale = onSale;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public List<Suggestion> getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(List<Suggestion> suggestions) {
        this.suggestions = suggestions;
    }

}
