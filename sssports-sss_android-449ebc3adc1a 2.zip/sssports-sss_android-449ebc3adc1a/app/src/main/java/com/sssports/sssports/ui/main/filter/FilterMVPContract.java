package com.sssports.sssports.ui.main.filter;

import com.hannesdorfmann.mosby3.mvp.MvpPresenter;
import com.hannesdorfmann.mosby3.mvp.MvpView;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.meta.Pricing;

import java.util.HashMap;
import java.util.List;

/**
 * Created by mlukovic on 8/7/17.
 */

public class FilterMVPContract {

    interface View extends MvpView {

        void showFilterList(List<Attribute> attributeList);

        void showError();

        void showOptionList(Attribute attribute);

        void showTitle(String label);

        void showCloseButton();

        void showLoader(boolean visible);

        void applyFilter(HashMap<Attribute, List<Option>> attributeList);

        String getPriceLabel();

        void showPriceRange(Pricing pricing);

        void showClearButton(boolean visible);

        void resetPriceRange(Pricing mPricing);

        void showBrandList(List<Option> optionList);
    }

    interface Presenter extends MvpPresenter<View> {

        void loadFilterList(String categoryId);

        void onFilterListDataReady(List<Attribute> attributeList);

        void onGettingFilterListError(Throwable throwable);

        void onAttributeItemClick(Attribute attribute);

        void onBackFilterClick();

        void onOptionClick(Option option);

        void onApplyFilterClick();

        void clearAllOptions();

        void clearAllAttributes();

        void setPriceRange(Pricing pricing);

        void setMinMaxPriceValue(Number minValue, Number maxValue);

        void onCancelButtonClick();
    }

    interface Interactor {

        void getFilterList(String categoryId);
    }
}
