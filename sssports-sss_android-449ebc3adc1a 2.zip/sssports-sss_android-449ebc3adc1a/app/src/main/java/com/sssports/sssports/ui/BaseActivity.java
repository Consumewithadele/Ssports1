package com.sssports.sssports.ui;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.sssports.sssports.SSSApp;
import com.sssports.sssports.di.component.ApplicationComponent;
import com.sssports.sssports.di.modules.ActivityModule;
import com.sssports.sssports.navigation.Navigator;
import com.sssports.sssports.networking.services.MagentoApi;
import com.sssports.sssports.networking.services.SSSApi;
import com.sssports.sssports.locale.LocaleHelper;
import com.sssports.sssports.networking.services.SliApi;

import javax.inject.Inject;

/**
 * Created by Adeleclark on 6/29/17.
 */

public abstract class BaseActivity extends AppCompatActivity {

    @Inject protected Navigator navigator;
    @Inject protected SSSApi sssApi;
    @Inject protected MagentoApi magentoApi;
    @Inject protected SliApi sliApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getApplicationComponent().inject(this);
    }

    protected ApplicationComponent getApplicationComponent() {
        return ((SSSApp)getApplication()).getApplicationComponent();
    }

    protected ActivityModule getActivityModule() {
        return new ActivityModule(this);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.wrap(newBase));
    }

    public Navigator getNavigator() {
        return navigator;
    }

    public void setNavigator(Navigator navigator) {
        this.navigator = navigator;
    }
}
