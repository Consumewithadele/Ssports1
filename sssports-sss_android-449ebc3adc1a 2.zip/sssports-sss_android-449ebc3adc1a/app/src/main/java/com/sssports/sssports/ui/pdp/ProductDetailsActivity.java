package com.sssports.sssports.ui.pdp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.locale.SharedPrefConstants;
import com.sssports.sssports.locale.SharedPreferenceManager;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.customviews.CustomDialog;
import com.sssports.sssports.ui.customviews.ListDialog;
import com.sssports.sssports.ui.customviews.MovableButton;
import com.sssports.sssports.ui.pdp.builder.ProductDetailsDirector;
import com.sssports.sssports.ui.pdp.builder.ProductDetailsDirectorImpl;
import com.sssports.sssports.ui.widgets.WidgetDirector;
import com.sssports.sssports.ui.widgets.WidgetDirectorImp;
import com.sssports.sssports.ui.widgets.contact.WidgetTypeContact;
import com.sssports.sssports.util.ActionPermissionHandler;
import com.sssports.sssports.util.CommonConstants;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

public class ProductDetailsActivity extends BaseActivity implements ProductDetailsContract.ProductDetailsView {

    @BindView(R.id.product_details_toolbar) Toolbar toolbar;
    @BindView(R.id.loader_product_details) ProgressBar loader;
    @BindView(R.id.linear_layout_product_details_holder) LinearLayout llProductDetailsHolder;
    @BindView(R.id.tv_add_to_bag) MovableButton tvAddToBag;

    private Activity mActivity;
    private String productId;
    private String productSku;
    private ProductDetailsContract.ProductDetailsPresenter productDetailsPresenter;
    private WidgetTypeContact.OnCallClickListener onCallClickListener;
    private CustomDialog mLoaderDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        ButterKnife.bind(this);
        mActivity = ProductDetailsActivity.this;

        Intent intent = getIntent();
        //TODO Maybe it will work with airbnb/DeepLinkDispatch ¯\_(ツ)_/¯
        Uri data = intent.getData();
        if (data != null) {
            productId = data.getLastPathSegment();
        } else {
            productId = getIntent().getStringExtra(CommonConstants.INTENT_PRODUCT_ID);
        }

        productSku = getIntent().getStringExtra(CommonConstants.INTENT_PRODUCT_SKU);

        onCallClickListener = this::showCallDialog;

        productDetailsPresenter = new ProductDetailsPresenterImpl(this, sssApi, magentoApi);

        if (TextUtils.isEmpty(productId)) {
            productDetailsPresenter.loadDataBySku(productSku);
        } else {
            productDetailsPresenter.loadDataByProductId(productId);
        }

        hideAddToBagButton();
        setToolbar();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void setToolbar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public void showProductDetails(Product product) {
        SharedPreferenceManager sharedPreferenceManager = new SharedPreferenceManager(mActivity, SharedPrefConstants.PreferenceName.USER_DATA);
        boolean pinchToZoomFlag = sharedPreferenceManager.getBoolean(SharedPrefConstants.PreferenceKeyName.PINCH_TO_ZOOM);

        if (!pinchToZoomFlag) {
            showPinchToZoomDialog(product);
            sharedPreferenceManager.putBoolean(SharedPrefConstants.PreferenceKeyName.PINCH_TO_ZOOM, true);
        }
        showAddToBagButton();

        ProductDetailsDirector productDetailsDirector = new ProductDetailsDirectorImpl(llProductDetailsHolder, product, mActivity, onCallClickListener);
        productDetailsDirector.construct(productChild -> productDetailsPresenter.onProductChildChanged(productChild));
    }

    private void showPinchToZoomDialog(Product product) {
        final Dialog dialog = new Dialog(mActivity);
        dialog.setContentView(R.layout.dialog_layout_pinch_to_zoom);

        ImageView closeButton = dialog.findViewById(R.id.iv_close_pinch_to_zoom);
        // if button is clicked, close the custom dialog
        closeButton.setOnClickListener(v -> dialog.dismiss());


        ImageView image = dialog.findViewById(R.id.iv_product_detail_image_dialog);

        GlideApp.with(mActivity)
                .load(product.getThumbnailUrl())
                .transition(withCrossFade())
                .placeholder(R.drawable.bg)
                .error(R.drawable.loading_placeholder)
                .into(image);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();

        wlp.gravity = Gravity.BOTTOM;
        wlp.width = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(wlp);

        dialog.show();
    }

    @Override
    public void showRelatedProductsAndWidgets(List<Widget> widgets) {
        WidgetDirector widgetDirector = new WidgetDirectorImp(llProductDetailsHolder, widgets, mActivity, null);
        widgetDirector.construct();
    }

    @Override
    public void enableAddToBagButton(boolean enabled) {
        tvAddToBag.setSelected(enabled);
    }

    @Override
    public void showEnableToAddToBagMessage() {
        showSnackBarMessage(getResources().getString(R.string.please_select_size));
    }

    @Override
    public void showAddToBagSuccessDialog() {
        ListDialog listDialog = new ListDialog(mActivity, getString(R.string.item_added_to_your_bag), getString(R.string.continue_shopping), getString(R.string.view_bag));
        listDialog.setTitleText(getString(R.string.what_do_you_want_to_do_now));

        listDialog.setOnFirstButtonClickListener(view -> {
            listDialog.cancel();
            finish();
        });

        listDialog.setOnSecondButtonClickListener(view -> {
            listDialog.cancel();
            navigator.navigateToShoppingCart(this);
        });
        listDialog.show();
    }

    @Override
    public void showAddToBagError() {
        showSnackBarMessage(getResources().getString(R.string.add_to_bag_error));
    }

    @Override
    public void showAddToBagLoader(boolean visible) {
        if (visible) {
            mLoaderDialog = new CustomDialog(mActivity, CommonConstants.DIALOG_LOADER);
            mLoaderDialog.setTitle(getResources().getString(R.string.adding_item_to_bag));
            mLoaderDialog.show();
        } else if (mLoaderDialog != null) {
            mLoaderDialog.cancel();
            mLoaderDialog = null;
        }
//        loader.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    @Override
    public void showLoading() {
        loader.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loader.setVisibility(View.GONE);
    }

    public void showAddToBagButton() {
        tvAddToBag.setVisibility(View.VISIBLE);
    }

    public void hideAddToBagButton() {
        tvAddToBag.setVisibility(View.GONE);
    }

    @Override
    public void showError() {
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        if (requestCode == ActionPermissionHandler.REQUEST_PERMISSION_CALL_ID) {

            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                callPhone(CommonConstants.PHONE_NUMBER_TO_CALL);
            } else {
                showSnackBarMessage(getResources().getString(R.string.permissions_denied));
            }

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            showSnackBarMessage(getResources().getString(R.string.permissions_denied));
        }
    }

    private void showSnackBarMessage(String message) {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.ll_email), message, Snackbar.LENGTH_SHORT);
        View view = snackbar.getView();
        view.setBackgroundColor(ContextCompat.getColor(ProductDetailsActivity.this, R.color.dark_grey));
        snackbar.show();
    }

    public void showCallDialog() {
        final CustomDialog cst = new CustomDialog(ProductDetailsActivity.this, CommonConstants.DIALOG_TWO_BUTTONS);

        cst.setArrayTextContent(R.array.dialog_call_cc)
                .setOnPositiveButtonClickListener(customDialog -> {
                    customDialog.dismiss();
                    callPhone(CommonConstants.PHONE_NUMBER_TO_CALL);
                })
                .setOnNegativeButtonClickListener(customDialog -> {
                    cst.dismiss();
                });

        cst.show();

    }

    public void callPhone(String phone) {
        String uri = "tel:" + phone;
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse(uri));

        ActionPermissionHandler actionPermissionHandler = new ActionPermissionHandler(ActionPermissionHandler.PermissionType.REQUEST_PERMISSION_CALL, ProductDetailsActivity.this);
        if (actionPermissionHandler.handlePermissions()) {
            startActivity(intent);
        }
    }

    @OnClick(R.id.tv_add_to_bag)
    void onAddToBagClick() {
        productDetailsPresenter.onAddToBagClick();
    }

    public static Intent getCallingIntent(Context context, String productId, String productSku) {
        Intent intent = new Intent(context, ProductDetailsActivity.class);
        intent.putExtra(CommonConstants.INTENT_PRODUCT_ID, productId);
        intent.putExtra(CommonConstants.INTENT_PRODUCT_SKU, productSku);
        return intent;
    }
}
