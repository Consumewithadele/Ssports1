package com.sssports.sssports.models.custom;

import android.content.Context;

/**
 * Created by mlukovic on 8/16/17.
 */

public class Country {

    private String code;
    private int labelResourceId;
    private String currencyCode;
    private Context context;

    public Country(String code) {
        this.code = code;
    }

    public Country(Context context, String code, int labelResourceId, String currencyCode) {
        this.code = code;
        this.labelResourceId = labelResourceId;
        this.context = context;
        this.currencyCode = currencyCode;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getLabelResourceId() {
        return labelResourceId;
    }

    public void setLabelResourceId(int labelResourceId) {
        this.labelResourceId = labelResourceId;
    }

    @Override
    public boolean equals(Object obj) {
        Country country1 = (Country) obj;
        return code.equalsIgnoreCase(country1.code);
    }

    @Override
    public String toString() {
        return context.getResources().getString(labelResourceId);
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }
}
