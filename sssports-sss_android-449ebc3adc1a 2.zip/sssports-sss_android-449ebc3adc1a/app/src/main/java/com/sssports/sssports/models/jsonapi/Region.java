package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import java.io.Serializable;

import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by natalijaratajac on 8/25/17.
 */
@JsonApi(type = "regions")
public class Region extends Resource implements Serializable {

    @Json(name = "name")
    private String name;
    @Json(name = "country_id")
    private String countryId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    @Override
    public String toString() {
        return name;
    }
}
