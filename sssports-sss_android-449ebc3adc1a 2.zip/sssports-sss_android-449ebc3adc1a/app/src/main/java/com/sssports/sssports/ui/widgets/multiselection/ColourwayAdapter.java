package com.sssports.sssports.ui.widgets.multiselection;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.ProductChild;

import java.util.List;

/**
 * Created by natalijaratajac on 8/9/17.
 */

public class ColourwayAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Activity activity;
    private List<Option> mOptionColorList;
    private ColourClickListener mColourClickListener;

    public ColourwayAdapter(Activity activity, List<Option> optionColorList) {
        this.activity = activity;
        this.mOptionColorList = optionColorList;
    }

    public void setOnColourClickListener(final ColourClickListener colourClickListener) {
        this.mColourClickListener = colourClickListener;
    }

    public void setSelected(ProductChild productChild) {
        //TODO setSelected(ProductChild productChild)
    }

    public class ImageColourHolder extends RecyclerView.ViewHolder {

        public ImageView imageColour;

        public ImageColourHolder(View itemView) {
            super(itemView);
            imageColour = itemView.findViewById(R.id.iv_image_colour);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
        return new ImageColourHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        Option option = mOptionColorList.get(position);
        ImageColourHolder imageColourHolder = (ImageColourHolder) holder;

        if (option != null) {

            if (option.getThumbnailImage() != null) {

                GlideApp.with(activity)
                        .load(option.getThumbnailImage())
                        .placeholder(R.drawable.bg)
                        .error(R.drawable.loading_placeholder)
                        .into(imageColourHolder.imageColour);
            }

            imageColourHolder.imageColour.setSelected(option.isSelected());

            imageColourHolder.imageColour.setOnClickListener(v -> {
                deselectAllItems();
                option.setSelected(true);
                notifyDataSetChanged();
                mColourClickListener.onClick(option);
            });
        }

    }

    private void deselectAllItems() {
        for (Option option : mOptionColorList) {
            option.setSelected(false);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.adapter_image_colourway;
    }

    @Override
    public int getItemCount() {
        if (mOptionColorList == null) return 0;
        return mOptionColorList.size();
    }

    public interface ColourClickListener {
        void onClick(Option option);
    }
}
