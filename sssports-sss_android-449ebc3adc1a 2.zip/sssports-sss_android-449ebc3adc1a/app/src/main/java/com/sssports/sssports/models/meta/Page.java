package com.sssports.sssports.models.meta;

import com.squareup.moshi.Json;

/**
 * Created by mlukovic on 7/30/17.
 */

public class Page {

    @Json(name = "current-page")
    private Integer currentPage;
    @Json(name = "per-page")
    private Integer perPage;
    @Json(name = "from")
    private Integer from;
    @Json(name = "to")
    private Integer to;
    @Json(name = "total")
    private Integer total;
    @Json(name = "last-page")
    private Integer lastPage;

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public Integer getPerPage() {
        return perPage;
    }

    public void setPerPage(Integer perPage) {
        this.perPage = perPage;
    }

    public Integer getFrom() {
        return from;
    }

    public void setFrom(Integer from) {
        this.from = from;
    }

    public Integer getTo() {
        return to;
    }

    public void setTo(Integer to) {
        this.to = to;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getLastPage() {
        return lastPage;
    }

    public void setLastPage(Integer lastPage) {
        this.lastPage = lastPage;
    }
}
