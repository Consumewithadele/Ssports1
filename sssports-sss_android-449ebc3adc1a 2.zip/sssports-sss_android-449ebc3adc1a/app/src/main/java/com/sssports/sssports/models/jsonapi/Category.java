package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import java.io.Serializable;
import java.util.List;

import moe.banana.jsonapi2.HasMany;
import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by mlukovic on 8/2/17.
 */

@JsonApi(type = "categories")
public class Category extends Resource implements Serializable {

    private final static long serialVersionUID = -4493959454085326685L;

    //Attributes
    @Json(name = "parent_id")
    private Integer parentId;
    @Json(name = "created_at")
    private String createdAt;
    @Json(name = "updated_at")
    private String updatedAt;
    @Json(name = "position")
    private Integer position;
    @Json(name = "level")
    private Integer level;
    @Json(name = "children_count")
    private Integer childrenCount;
    @Json(name = "name")
    private String name;
    @Json(name = "slug")
    private String slug;
    @Json(name = "description")
    private String description;
    @Json(name = "screen_id")
    private Integer screenId;
    @Json(name = "image_url")
    private String imageUrl;

    //Relationships
    @Json(name = "children")
    private HasMany<Category> categoryList;

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getChildrenCount() {
        return childrenCount;
    }

    public void setChildrenCount(Integer childrenCount) {
        this.childrenCount = childrenCount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getScreenId() {
        return screenId;
    }

    public void setScreenId(Integer screenId) {
        this.screenId = screenId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public List<Category> getCategoryList() {
        return categoryList.get(getContext());
    }

    @Override
    public String toString() {
        return this.name;
    }
}
