package com.sssports.sssports.ui.main.category;

import com.hannesdorfmann.mosby3.mvp.MvpPresenter;
import com.hannesdorfmann.mosby3.mvp.MvpView;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Widget;

import java.util.List;

/**
 * Created by mlukovic on 7/31/17.
 */

public class CategoryFragmentMVPContract {

    interface View extends MvpView {

        void showCategoryList(List<Category> categoryList);

        void showWidgets(List<Widget> widgetList);

        void showLoader(boolean visible);

        void showError();

        void showHeaderImage(String imageUrl);

        void showDescription(String description);

        void setTitle(String name);
    }

    interface Presenter extends MvpPresenter<View> {

        void loadData(String categoryId);

        void onCategoryDataReady(Category category);

        void onWidgetsDataReady(List<Widget> widgetList);

        void showError();
    }

    interface Interactor {

        void getCategories(String categoryId);

        void getWidgets(String id, Integer screenId);
    }
}
