package com.sssports.sssports.ui.shoppingbag;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.custom.CartItemViewModel;
import com.sssports.sssports.models.magento.CartItem;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.checkoutshipping.CheckoutShippingActivity;
import com.sssports.sssports.ui.customviews.CustomDialog;
import com.sssports.sssports.ui.customviews.ExpandableHeightListView;
import com.sssports.sssports.ui.customviews.ListDialog;
import com.sssports.sssports.ui.customviews.MovableButton;
import com.sssports.sssports.ui.shoppingbag.widgetbuilder.ShoppingBagDirector;
import com.sssports.sssports.ui.shoppingbag.widgetbuilder.ShoppingBagDirectorImpl;
import com.sssports.sssports.util.ActionPermissionHandler;
import com.sssports.sssports.util.CommonConstants;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ShoppingBagActivity extends BaseActivity implements ShoppingBagMvpContract.View, AdapterCartItem.CartItemListener {

    @BindView(R.id.toolbar) Toolbar toolbar;
    @BindView(R.id.button_checkout_now) MovableButton btnCheckoutNow;
    @BindView(R.id.progress_bar_loader) ProgressBar progressBar;
    @BindView(R.id.lv_cart_product_items) ExpandableHeightListView cartItemListView;
    @BindView(R.id.ll_widget_holder) LinearLayout llWidgetHolder;
    @BindView(R.id.error_empty_constraint_layout) ConstraintLayout mErrorEmptyLayout;
    @BindView(R.id.error_title) TextView tvErrorTitle;
    @BindView(R.id.error_message) TextView tvErrorMessage;
    @BindView(R.id.error_cta_button) Button btnCtaButton;

    private ShoppingBagMvpContract.Presenter presenter;
    private AdapterCartItem adapterCartItem;
    private ShoppingBagDirector mShoppingBagDirector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_bag);
        ButterKnife.bind(this);
        this.setToolbar();
        presenter = new ShoppingBagPresenterImpl(this, magentoApi, sssApi);
        presenter.loadCartItems();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @OnClick(R.id.button_checkout_now)
    public void onButtonCheckOutClick() {
        if (btnCheckoutNow.isSelected()) {
            Intent intent = new Intent(this, CheckoutShippingActivity.class);
            startActivity(intent);
        }
    }

    private void setToolbar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    public static Intent getCallingIntent(Context context) {
        return new Intent(context, ShoppingBagActivity.class);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        presenter.onViewDetached();
    }

    @Override
    public void showCartItemList(List<CartItemViewModel> cartItemList) {
        adapterCartItem = new AdapterCartItem(this, cartItemList);
        adapterCartItem.addCartItemListener(this);
        cartItemListView.setExpanded(true);
        cartItemListView.setAdapter(adapterCartItem);
    }

    @Override
    public void showCheckoutButton(boolean visible) {
        btnCheckoutNow.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    @Override
    public void showLoader(boolean visible) {
        progressBar.setVisibility(visible ? View.VISIBLE : View.GONE);
        btnCheckoutNow.setSelected(!visible);
        if (adapterCartItem != null) {
            adapterCartItem.setClickable(!visible);
            adapterCartItem.notifyDataSetChanged();
        }
    }

    @Override
    public void onRemoveOneItemClick(CartItemViewModel cartItemViewModel) {
        presenter.deleteOneItemToCart(cartItemViewModel);
    }

    @Override
    public void onAddOneItemClick(CartItem cartItem) {
        presenter.addOneItemToCart(cartItem);
    }

    @Override
    public void unableToAddItemEvent(String name) {
        String message = getResources().getString(R.string.unable_to_add_item_to_cart);
        showSnackBarMessage(String.format(message, name));
    }

    @Override
    public void unableToRemoveItemEvent() {
        //TODO unableToRemoveItemEvent()
    }

    @Override
    public void removeItemFromCart(CartItemViewModel cartItem) {
        ListDialog listDialog = new ListDialog(this, getString(R.string.are_you_sure_to_remove_item), getString(R.string.cancel), getString(R.string.yes));

        listDialog.setOnFirstButtonClickListener(view -> listDialog.cancel());

        listDialog.setOnSecondButtonClickListener(view -> {
            presenter.removeItemFromCart(cartItem);
            listDialog.cancel();
        });

        listDialog.show();
    }

    @Override
    public void showDeleteCartItemError(CartItemViewModel cartItemViewModel) {
        hideOverlayError();
        String message = String.format(getResources().getString(R.string.unable_to_remove_item), cartItemViewModel.getName());
        showSnackBarMessage(message);
    }

    @Override
    public void showErrorEmptyMessage() {
        mErrorEmptyLayout.setVisibility(View.VISIBLE);
        tvErrorTitle.setText(R.string.empty_cart);
        tvErrorMessage.setText(R.string.cart_is_empty_or_expired);
        btnCtaButton.setText(R.string.menu_shop_now);
        btnCtaButton.setOnClickListener(view -> onBackPressed());
        btnCheckoutNow.setVisibility(View.GONE);
    }

    @Override
    public void showInternetConnectionErrorMessage() {
        mErrorEmptyLayout.setVisibility(View.VISIBLE);
        tvErrorTitle.setText(R.string.internet_error_title);
        tvErrorMessage.setText(R.string.internet_error_message);
        btnCtaButton.setText(R.string.try_again_button);
        btnCtaButton.setOnClickListener(view -> presenter.loadCartItems());
        btnCheckoutNow.setVisibility(View.GONE);
    }

    @Override
    public void hideOverlayError() {
        mErrorEmptyLayout.setVisibility(View.GONE);
        btnCheckoutNow.setVisibility(View.GONE);
    }

    @Override
    public void showCartItemDeletedMessage(CartItemViewModel cartItem) {
        adapterCartItem.removeCartItem(cartItem);
        if (adapterCartItem.getCount() == 0) {
            showErrorEmptyMessage();
        }
        String message = String.format(getResources().getString(R.string.item_deleted), cartItem.getName());
        showSnackBarMessage(message);
    }

    @Override
    public void showAddItemToCartError() {
        showSnackBarMessage(getResources().getString(R.string.add_to_bag_error));
    }

    @Override
    public void updateItem(CartItem cartItem) {
        if (adapterCartItem != null) {
            adapterCartItem.updateCartItemQuantity(cartItem);
        }
    }

    @Override
    public void showWidgets() {
        mShoppingBagDirector = new ShoppingBagDirectorImpl(llWidgetHolder, this, () -> {
            final CustomDialog cst = new CustomDialog(ShoppingBagActivity.this, CommonConstants.DIALOG_TWO_BUTTONS);

            cst.setArrayTextContent(R.array.dialog_call_cc)
                    .setOnPositiveButtonClickListener(customDialog -> {
                        customDialog.dismiss();
                        callPhone(CommonConstants.PHONE_NUMBER_TO_CALL);
                    })
                    .setOnNegativeButtonClickListener(customDialog -> {
                        cst.dismiss();
                    });

            cst.show();
        });
        mShoppingBagDirector.construct(null);
    }

    public void callPhone(String phone) {
        String uri = "tel:" + phone;
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse(uri));

        ActionPermissionHandler actionPermissionHandler = new ActionPermissionHandler(ActionPermissionHandler.PermissionType.REQUEST_PERMISSION_CALL, ShoppingBagActivity.this);
        if (actionPermissionHandler.handlePermissions()) {
            startActivity(intent);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        if (requestCode == ActionPermissionHandler.REQUEST_PERMISSION_CALL_ID) {

            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                callPhone(CommonConstants.PHONE_NUMBER_TO_CALL);
            } else {
                showSnackBarMessage(getResources().getString(R.string.permissions_denied));
            }

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            showSnackBarMessage(getResources().getString(R.string.permissions_denied));
        }
    }

    @Override
    public void showErrorItemNotAvailable(CartItem cartItem) {
        showSnackBarMessage(getResources().getString(R.string.item_not_available));
    }

    @Override
    public void showErrorDeletingItem() {
        showSnackBarMessage(getResources().getString(R.string.error_deleting));
    }

    @Override
    public void updateItemDelete(CartItemViewModel cartItemViewModel) {
        if (adapterCartItem != null) {
            CartItem cartItem = new CartItem(cartItemViewModel.getSku(), cartItemViewModel.getQuantity(), cartItemViewModel.getQuoteId());
            adapterCartItem.onOneItemRemoved(cartItem);
        }
    }

    @Override
    public void refreshSummary() {
        mShoppingBagDirector.refreshSummary(null);
    }

    private void showSnackBarMessage(String message) {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.root_view), message, Snackbar.LENGTH_LONG);
        View view = snackbar.getView();
        view.setBackgroundColor(ContextCompat.getColor(ShoppingBagActivity.this, R.color.dark_grey));
        snackbar.show();
    }
}
