package com.sssports.sssports.ui.main;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.instabug.library.Instabug;
import com.miguelcatalan.materialsearchview.MaterialSearchView;
import com.sssports.sssports.R;
import com.sssports.sssports.locale.LocaleBuilder;
import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.custom.Country;
import com.sssports.sssports.models.custom.Language;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.models.meta.Pricing;
import com.sssports.sssports.models.sli.Result;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.customviews.ExpandableHeightListView;
import com.sssports.sssports.ui.customviews.SpinnerListener;
import com.sssports.sssports.ui.main.category.CategoryFragment;
import com.sssports.sssports.ui.main.filter.FilterListFragment;
import com.sssports.sssports.ui.main.home.HomeFragment;
import com.sssports.sssports.ui.main.maincategory.MainCategoryFragment;
import com.sssports.sssports.ui.main.maincategory.MainCategoryFragment.OnMainCategorySelectedListener;
import com.sssports.sssports.ui.main.menu.MoreMenuBuilder;
import com.sssports.sssports.ui.main.menu.MoreMenuListAdapter;
import com.sssports.sssports.ui.main.plp.PLPFragment;
import com.sssports.sssports.ui.main.search.SearchMvpContract;
import com.sssports.sssports.ui.main.search.SearchPresenterImpl;
import com.sssports.sssports.ui.main.search.SearchResultsAdapter;
import com.sssports.sssports.ui.main.shopbybrand.ShopByBrandFragment;
import com.sssports.sssports.ui.splash.SplashScreenActivity;
import com.sssports.sssports.util.CommonConstants;

import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.zhanghai.android.materialprogressbar.MaterialProgressBar;

import static com.sssports.sssports.util.CommonConstants.FragmentId.FRAGMENT_CATEGORY;
import static com.sssports.sssports.util.CommonConstants.FragmentId.FRAGMENT_HOME_PAGE;
import static com.sssports.sssports.util.CommonConstants.FragmentId.FRAGMENT_MAIN_CATEGORY;
import static com.sssports.sssports.util.CommonConstants.FragmentId.FRAGMENT_PLP;
import static com.sssports.sssports.util.CommonConstants.FragmentId.FRAGMENT_SHOP_BY_BRAND;

/**
 * Main Activity which holds fragments like: {@link HomeFragment}, {@link MainCategoryFragment},
 * {@link CategoryFragment}, {@link PLPFragment}, {@link FilterListFragment},
 * {@link ShopByBrandFragment}
 */
public class MainActivity extends BaseActivity implements SearchMvpContract.View, HomeFragment.OnShopButtonClickListener, OnMainCategorySelectedListener, MainScreenListener, CategoryFragment.OnCategorySelectedListener, SearchResultsAdapter.OnItemClickListener {

    public static final String INTENT_WIDGETS = "intent-screen";
    public static final String INTENT_LINK = "intent-link";

    @BindView(R.id.home_toolbar) Toolbar toolbar;
    @BindView(R.id.drawer_layout) DrawerLayout mDrawerLayout;
    @BindView(R.id.toolbar_spinner) Spinner mSpinnerCategory;
    @BindView(R.id.country_spinner) Spinner mCountrySpinner;
    @BindView(R.id.language_spinner) Spinner mLanguageSpinner;
    @BindView(R.id.nav_view_right) NavigationView rightDrawerView;
    @BindView(R.id.menu_list_view) ExpandableHeightListView mMoreMenuListView;
    @BindView(R.id.search_view) MaterialSearchView mSearchView;
    @BindView(R.id.search_result_list) RecyclerView mSearchResultList;
    @BindView(R.id.searchTextView) EditText mSearchEditText;
    @BindView(R.id.search_loader) MaterialProgressBar mSearchLoader;

    private SearchMvpContract.Presenter mSearchPresenter;
    Fragment fragment = null;
    Fragment fragmentFilter = null;
    private boolean rightDrawerViewEnabled = false;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        mContext = MainActivity.this;
        this.initActionBar();
        this.handleIntent(getIntent());
        this.initMoreMenu(this);
        this.initLanguage();
        this.initCountryList();
        this.initSearch();
    }

    private void initSearch() {
        mSearchPresenter = new SearchPresenterImpl(sliApi, this);
        mSearchPresenter.onAttach();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mSearchResultList.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mContext, LinearLayoutManager.VERTICAL);
        mSearchResultList.addItemDecoration(dividerItemDecoration);
        mSearchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                mSearchView.hideKeyboard(mSearchView);
                mSearchPresenter.search(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                mSearchPresenter.search(newText);
                return false;
            }
        });

        mSearchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
            @Override
            public void onSearchViewShown() {
                mSearchResultList.setVisibility(View.VISIBLE);
            }

            @Override
            public void onSearchViewClosed() {
                mSearchResultList.setVisibility(View.GONE);
                showSearchLoader(false);
                clearResultList();
            }
        });
    }

    private void initCountryList() {
        List<Country> countryList = LocaleBuilder.buildCountryList(MainActivity.this);
        ArrayAdapter<Country> countryAdapter = new ArrayAdapter<>(this, R.layout.spinner_more_menu_item, countryList);
        countryAdapter.setDropDownViewResource(R.layout.spinner_category_dropdown_item);
        mCountrySpinner.setAdapter(countryAdapter);

        //Set selected country
        int index = countryAdapter.getPosition(new Country(SPDataManager.INSTANCE.getCountry()));
        mCountrySpinner.setSelection(index);

        SpinnerListener spinnerListener = new SpinnerListener(position -> {
            Country country = countryList.get(position);
            SPDataManager.INSTANCE.saveCountry(country.getCode());
            SPDataManager.INSTANCE.saveCurrentCurrency(country.getCurrencyCode());
            Intent refresh = new Intent(MainActivity.this, SplashScreenActivity.class);
            startActivity(refresh);
            finish();
        });

        mCountrySpinner.setOnTouchListener(spinnerListener);
        mCountrySpinner.setOnItemSelectedListener(spinnerListener);

    }

    private void initLanguage() {
        List<Language> languageList = LocaleBuilder.buildLanguageList(this);
        ArrayAdapter<Language> languageAdapter = new ArrayAdapter<>(this, R.layout.spinner_more_menu_item, languageList);
        languageAdapter.setDropDownViewResource(R.layout.spinner_category_dropdown_item);
        mLanguageSpinner.setAdapter(languageAdapter);

        String locale = SPDataManager.INSTANCE.getLanguageCode();
        int index = LocaleBuilder.getSelectedLanguageIndex(languageList, locale);
        mLanguageSpinner.setSelection(index);

        SpinnerListener spinnerInteractionListener = new SpinnerListener(position -> {
            String language = languageList.get(position).getCode();
            SPDataManager.INSTANCE.saveLanguage(language);
            Intent refresh = new Intent(MainActivity.this, SplashScreenActivity.class);
            startActivity(refresh);
            finish();
        });
        mLanguageSpinner.setOnTouchListener(spinnerInteractionListener);
        mLanguageSpinner.setOnItemSelectedListener(spinnerInteractionListener);
    }

    private void initMoreMenu(Context context) {
        List<com.sssports.sssports.models.custom.MenuItem> menuItems = MoreMenuBuilder.build();
        MoreMenuListAdapter moreMenuListAdapter = new MoreMenuListAdapter(context, menuItems, menuItemCode -> {
            switch (menuItemCode) {
                case MoreMenuBuilder.ACTION_SHOP_NOW:
                    if (!(fragment instanceof MainCategoryFragment)) {
                        onShopButtonClicked();
                    }
                    closeFilterMenu();
                    break;
                case MoreMenuBuilder.ACTION_HOME:
                    if(!(fragment instanceof HomeFragment)) {
                        displaySelectedScreen(FRAGMENT_HOME_PAGE, null);
                    }
                    closeFilterMenu();
                    break;
                case MoreMenuBuilder.ACTION_BLOG:
                    closeFilterMenu();
                    navigator.openLink(this, "https://blog.sssports.com");
                    break;
                case MoreMenuBuilder.ACTION_SHOPPING_BAG:
                    closeFilterMenu();
                    navigator.navigateToShoppingCart(this);
                    break;
                case MoreMenuBuilder.ACTION_SEND_FEEDBACK:
                    closeFilterMenu();
                    Instabug.invoke();
                    break;

            }
        });
        mMoreMenuListView.setExpanded(true);
        mMoreMenuListView.setAdapter(moreMenuListAdapter);;

    }

    private void handleIntent(Intent intent) {
//        default is FRAGMENT_HOME_PAGE
        int intentFragmentId = intent.getIntExtra(CommonConstants.INTENT_FRAGMENT_ID, FRAGMENT_HOME_PAGE);
        String link = intent.getStringExtra(INTENT_LINK);
        displaySelectedScreen(intentFragmentId, link);
    }

    public void displaySelectedScreen(int pageId, Object link) {

        switch (pageId) {
            case FRAGMENT_HOME_PAGE: {
                Screen screen = (Screen) getIntent().getSerializableExtra(INTENT_WIDGETS);
                fragment = HomeFragment.newInstance(screen);
                break;
            }
            case FRAGMENT_MAIN_CATEGORY: {
//                TODO: return to MainCategoryFragment
                fragment = MainCategoryFragment.newInstance();
                break;
            }
            case FRAGMENT_CATEGORY: {
                fragment = CategoryFragment.newInstance((String) link);
                break;
            }
            case FRAGMENT_SHOP_BY_BRAND: {
                fragment = ShopByBrandFragment.newInstance();
                break;
            }
            case FRAGMENT_PLP: {
                fragment = PLPFragment.newInstance(link);
                break;
            }

        }

        FragmentManager manager = getSupportFragmentManager();

        String backStateName = fragment.getClass().getName();
        String fragmentTag = backStateName;
        boolean fragmentPopped = manager.popBackStackImmediate(backStateName, 0);

        if (!fragmentPopped && manager.findFragmentByTag(fragmentTag) == null) {
            FragmentTransaction ft = manager.beginTransaction();
            ft.setCustomAnimations(R.anim.fadein, R.anim.fadeout, R.anim.fadein, R.anim.fadeout);
            ft.replace(R.id.content_frame, fragment);
            ft.addToBackStack(backStateName);
            ft.commit();
        }
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_bag: {
                navigator.navigateToShoppingCart(this);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onStart() {
        mSearchPresenter.onAttach();
        super.onStart();
    }

    private void initActionBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, 0, 0) {
            @Override
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                super.onDrawerSlide(drawerView, 0);
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, 0); // this disables the animation
                if (drawerView == rightDrawerView) {
                    if (rightDrawerViewEnabled) {
                        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, rightDrawerView);
                    } else {
                        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, rightDrawerView);
                    }

                }
            }
        };
        mDrawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }


    public static Intent getCallingIntent(Context context, Screen screen) {
        Intent callingIntent = new Intent(context, MainActivity.class);
        callingIntent.putExtra(INTENT_WIDGETS, screen);
        return callingIntent;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_navigation_main, menu);

        MenuItem searchMenuItem = menu.findItem(R.id.action_search);
        mSearchView.setMenuItem(searchMenuItem);
        return true;
    }

    @Override
    public void onShopButtonClicked() {
        displaySelectedScreen(FRAGMENT_MAIN_CATEGORY, null);
    }

    @Override
    public void onBackPressed() {
        if (mSearchView.isSearchOpen()) {
            mSearchView.closeSearch();
        } else {
            if (mDrawerLayout.isDrawerOpen(GravityCompat.START) || mDrawerLayout.isDrawerOpen(GravityCompat.END)) {
                mDrawerLayout.closeDrawers();
                return;
            }

            if (getSupportFragmentManager() != null && getSupportFragmentManager().getBackStackEntryCount() == 1) {
                finish();
            } else {
                super.onBackPressed();
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        mSearchPresenter.onDetach();
        super.onDestroy();
    }

    @Override
    public void onCategorySelected(String link) {
//        if (link.contains("category/61")) {
//            displaySelectedScreen(FRAGMENT_SHOP_BY_BRAND, link);
//        } else {
//            displaySelectedScreen(FRAGMENT_CATEGORY, link);
            navigator.openLink(this, link);
//        }
    }

    @Override
    public void showScreenTitle(String title) {
        if (!TextUtils.isEmpty(title)) {
            ((TextView) toolbar.findViewById(R.id.tv_toolbar_title)).setText(title);
            toolbar.findViewById(R.id.tv_toolbar_title).setVisibility(View.VISIBLE);
            toolbar.findViewById(R.id.iv_sss_logo).setVisibility(View.GONE);
            mSpinnerCategory.setVisibility(View.GONE);
        } else {
            toolbar.findViewById(R.id.tv_toolbar_title).setVisibility(View.GONE);
            toolbar.findViewById(R.id.iv_sss_logo).setVisibility(View.VISIBLE);
            mSpinnerCategory.setVisibility(View.GONE);
        }
    }

    @Override
    public void showDropDownTitle(List<Category> categoryList, int selectedPosition) {
        ArrayAdapter<Category> adapter = new ArrayAdapter<>(this, R.layout.spinner_category_item, categoryList);
        adapter.setDropDownViewResource(R.layout.spinner_category_dropdown_item);
        mSpinnerCategory.setAdapter(adapter);
        mSpinnerCategory.setVisibility(View.VISIBLE);
        SpinnerListener listener = new SpinnerListener(position -> {
            if (fragment instanceof PLPFragment) {
                ((PLPFragment) fragment).changeCategory(categoryList.get(position));
            }
        });
        mSpinnerCategory.setOnTouchListener(listener);
        mSpinnerCategory.setOnItemSelectedListener(listener);
        mSpinnerCategory.setSelection(selectedPosition);
        //Hide title and logo
        toolbar.findViewById(R.id.tv_toolbar_title).setVisibility(View.GONE);
        toolbar.findViewById(R.id.iv_sss_logo).setVisibility(View.GONE);
    }

    @Override
    public void loadFilterList(String category, Pricing pricing) {
        FragmentManager manager = getSupportFragmentManager();
        fragmentFilter = FilterListFragment.newInstance(category, pricing);
        FragmentTransaction ft = manager.beginTransaction();
        ft.replace(R.id.menu_content_frame, fragmentFilter);
        ft.commit();
        rightDrawerViewEnabled = true;
    }

    @Override
    public void closeFilterMenu() {
        mDrawerLayout.closeDrawers();
    }

    @Override
    public void showFilterList() {
        mDrawerLayout.openDrawer(Gravity.END);
    }

    @Override
    public void filterProductList(HashMap<Attribute, List<Option>> filterHashMap) {
        if (fragment instanceof PLPFragment) {
            ((PLPFragment) fragment).filterProductList(filterHashMap);
        }
    }

    @Override
    public void disableRightMenu() {
        rightDrawerViewEnabled = false;
    }

    @Override
    public void openLink(String link) {
//        navigator.navigateToProductDetailsPage(mContext, link, null);
        navigator.openLink(this, link);
//
//
//        Intent intent = new Intent (Intent.ACTION_VIEW);
//        intent.setData (Uri.parse (link));
//        startActivity(intent);
    }

    @Override
    public void onCategoryClick(Category category) {
        displaySelectedScreen(FRAGMENT_PLP, category);
    }

    @Override
    public void showSearchResults(List<Object> searchResult, String mKeyWord) {
        SearchResultsAdapter searchResultsAdapter = new SearchResultsAdapter(mContext, searchResult, mKeyWord, this);
        mSearchResultList.setAdapter(searchResultsAdapter);
    }

    @Override
    public void clearResultList() {
        SearchResultsAdapter searchResultsAdapter = new SearchResultsAdapter(mContext, null, null, this);
        mSearchResultList.setAdapter(searchResultsAdapter);
    }

    @Override
    public void showSearchLoader(boolean visible) {
        mSearchLoader.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onSuggestionClicked(String suggestion) {
        mSearchEditText.setText(suggestion);
        if (!TextUtils.isEmpty(mSearchEditText.getText())) {
            mSearchEditText.setSelection(mSearchEditText.getText().length());
        }
        mSearchView.hideKeyboard(mSearchView);
        mSearchPresenter.search(suggestion);
    }

    @Override
    public void onProductClicked(Result result) {
        navigator.navigateToProductDetailsPage(this, null, result.getSku());
    }
}
