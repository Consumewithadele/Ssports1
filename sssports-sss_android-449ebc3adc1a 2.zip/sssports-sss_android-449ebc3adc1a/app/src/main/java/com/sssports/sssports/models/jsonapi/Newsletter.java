package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by natalijaratajac on 9/8/17.
 */
@JsonApi(type = "newsletter")
public class Newsletter extends Resource{

    @Json(name = "email")
    private String email;
    @Json(name = "fields")
    private Field field;
    @Json(name = "emailtype")
    private String emailType;
    @Json(name = "datafields")
    private DataField[] dataField;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    public String getEmailType() {
        return emailType;
    }

    public void setEmailType(String emailType) {
        this.emailType = emailType;
    }

    public DataField[] getDataField() {
        return dataField;
    }

    public void setDataField(DataField[] dataField) {
        this.dataField = dataField;
    }
}
