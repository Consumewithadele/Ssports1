package com.sssports.sssports.models.meta;

import com.squareup.moshi.Json;

/**
 * Created by mlukovic on 7/30/17.
 */

public class Meta {

    @Json(name = "page")
    private Page page;
    @Json(name = "pricing")
    private Pricing pricing;

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public Pricing getPricing() {
        return pricing;
    }

    public void setPricing(Pricing pricing) {
        this.pricing = pricing;
    }
}
