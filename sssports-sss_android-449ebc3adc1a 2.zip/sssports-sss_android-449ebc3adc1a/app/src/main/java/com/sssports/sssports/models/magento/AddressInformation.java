package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class AddressInformation {

    @Json(name = "shipping_address")
    private UserDetailsDto shippingAddress;
    @Json(name = "billing_address")
    private UserDetailsDto billingAddress;
    @Json(name = "shipping_method_code")
    private String shippingMethodCode;
    @Json(name = "shipping_carrier_code")
    private String shippingCarrierCode;

    public UserDetailsDto getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(UserDetailsDto shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public UserDetailsDto getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(UserDetailsDto billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getShippingMethodCode() {
        return shippingMethodCode;
    }

    public void setShippingMethodCode(String shippingMethodCode) {
        this.shippingMethodCode = shippingMethodCode;
    }

    public String getShippingCarrierCode() {
        return shippingCarrierCode;
    }

    public void setShippingCarrierCode(String shippingCarrierCode) {
        this.shippingCarrierCode = shippingCarrierCode;
    }
}
