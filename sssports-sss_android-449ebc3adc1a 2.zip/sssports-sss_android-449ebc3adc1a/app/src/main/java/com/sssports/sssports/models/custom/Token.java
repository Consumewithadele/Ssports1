package com.sssports.sssports.models.custom;

import com.squareup.moshi.Json;

/**
 * Created by natalijaratajac on 9/10/17.
 */

public class Token {

    @Json(name = "token_type")
    private String tokenType;
    @Json(name = "expires_in")
    private Integer expiresIn;
    @Json(name = "access_token")
    private String accessToken;

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public Integer getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Integer expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
