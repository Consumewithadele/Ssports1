package com.sssports.sssports.ui.main.category;

import android.app.Activity;
import android.text.TextUtils;

import com.hannesdorfmann.mosby3.mvp.MvpBasePresenter;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Widget;

import java.util.List;

/**
 * Created by mlukovic on 7/31/17.
 */

public class CategoryFragmentPresenterImpl extends MvpBasePresenter<CategoryFragmentMVPContract.View> implements CategoryFragmentMVPContract.Presenter {

    private CategoryFragmentMVPContract.View mCategoryView;
    private Activity mActivity;
    private CategoryFragmentMVPContract.Interactor fragmentInteractor;

    public CategoryFragmentPresenterImpl(CategoryFragmentMVPContract.View categoryView, Activity activity) {
        mCategoryView = categoryView;
        mActivity = activity;
    }

    @Override
    public void loadData(String categoryId) {
        if (TextUtils.isEmpty(categoryId) || !isViewAttached()) {
            mCategoryView.showError();
            return;
        }
        mCategoryView.showLoader(true);
        fragmentInteractor = new CategoryFragmentInteractorImpl(mActivity, this);
        fragmentInteractor.getCategories(categoryId);
    }

    @Override
    public void onCategoryDataReady(Category category) {
        if (isViewAttached()) {
            mCategoryView.showCategoryList(category.getCategoryList());
            mCategoryView.showHeaderImage(category.getImageUrl());
            mCategoryView.showDescription(category.getDescription());
            mCategoryView.setTitle(category.getName());
            //Based on categoryId and screenId get Widgets for the screen
            fragmentInteractor.getWidgets(category.getId(), category.getScreenId());
        }
    }

    @Override
    public void onWidgetsDataReady(List<Widget> widgetList) {
        if (isViewAttached()) {
            mCategoryView.showWidgets(widgetList);
            mCategoryView.showLoader(false);
        }
    }

    @Override
    public void showError() {
        if (isViewAttached()) mCategoryView.showError();
    }
}
