package com.sssports.sssports.ui.splash;


import com.sssports.sssports.models.jsonapi.Screen;

/**
 * Created by Adeleclark on 7/2/17.
 */

public interface SplashScreenContract {

    public interface View {

        void showError();

        void showHomeScreen(Screen screen);
    }

    public interface Presenter {

        public void loadData();
    }
}
