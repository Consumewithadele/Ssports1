package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by mlukovic on 9/1/17.
 */

public class TotalSegment {

    @Json(name = "code")
    private String code;
    @Json(name = "title")
    private String title;
    @Json(name = "value")
    private Double value;
    @Json(name = "area")
    private String area;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
