
package com.sssports.sssports.models.sli;

import com.squareup.moshi.Json;

public class Suggestion {

    @Json(name = "rank")
    private String rank;
    @Json(name = "phrase")
    private String phrase;

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getPhrase() {
        return phrase;
    }

    public void setPhrase(String phrase) {
        this.phrase = phrase;
    }

}
