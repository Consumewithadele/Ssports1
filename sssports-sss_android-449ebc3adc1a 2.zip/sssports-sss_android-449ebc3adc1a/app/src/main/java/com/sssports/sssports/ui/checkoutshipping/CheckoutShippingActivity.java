package com.sssports.sssports.ui.checkoutshipping;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.jsonapi.Region;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.checkoutbilling.CheckoutBillingActivity;
import com.sssports.sssports.ui.customviews.CustomDialog;
import com.sssports.sssports.util.CommonConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class CheckoutShippingActivity extends BaseActivity implements CheckoutShippingContract.CheckoutShippingView {

    @BindView(R.id.checkout_shipping_toolbar) Toolbar toolbar;
    @BindView(R.id.tv_customer_information) TextView tvCustomerInformation;
    @BindView(R.id.cb_subscribe_to_newsletter) AppCompatCheckBox cbSubscribeToNewsletter;
    @BindView(R.id.tv_shipping_address) TextView tvShippingAddress;
    @BindView(R.id.tv_continue_to_shipping_method) TextView tvContinueToShippingMethod;
    @BindView(R.id.et_email) EditText etEmail;
    @BindView(R.id.ti_email) TextInputLayout tiEmail;
    @BindView(R.id.et_first_name) EditText etFirstName;
    @BindView(R.id.et_last_name) EditText etLastName;
    @BindView(R.id.et_address) EditText etAddress;
    @BindView(R.id.et_po_box) EditText etPoBox;
    @BindView(R.id.et_phone_number) EditText etPhoneNumber;
    @BindView(R.id.ti_phone_number) TextInputLayout tiPhoneNumber;
    @BindView(R.id.spinner_country) Spinner spinnerCountry;
    @BindView(R.id.spinner_city) Spinner spinnerCity;
    @BindView(R.id.loader_checkout_shipping) ProgressBar loader;
    @BindView(R.id.cb_save_data) AppCompatCheckBox cbSaveData;

    private CheckoutShippingContract.CheckoutShippingPresenter presenter;
    private CustomDialog mLoaderDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_shipping);

        ButterKnife.bind(this);
        presenter = new CheckoutShippingPresenterImpl(this, CheckoutShippingActivity.this);
        setupCbSubscription();
        setupCbSaveData();
        setupEtEmail();
        setupEtFirstName();
        setupEtLastName();
        setupEtAddress();
        setupEtPoBox();
        setupEtPhoneNumber();
        setToolbar();
        presenter.loadData();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void setToolbar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    private void setupCityDropDownList(List<Region> regions, AtomicInteger positionRegion) {
        if (regions == null || regions.isEmpty()) {
            hideRegionDropDown();
            presenter.setRegion(null);
            return;
        }

        showRegionDropDown();
        ArrayAdapter<Region> cityAdapter = new ArrayAdapter<>(this, R.layout.spinner_shipping_adress_item, regions);
        cityAdapter.setDropDownViewResource(R.layout.spinner_category_dropdown_item);
        spinnerCity.setAdapter(cityAdapter);
        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (positionRegion.get() != -1) {
                    presenter.setRegion(regions.get(positionRegion.get()).getName());
                    positionRegion.set(-1);
                } else {
                    presenter.setRegion(regions.get(i).getName());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        if (positionRegion.get() != -1) {
            spinnerCity.setSelection(positionRegion.get());
        }
    }

    private void setupCountryDropDownList(List<Country> countryList, int positionCountry, AtomicInteger positionRegion) {
        if (countryList == null || countryList.isEmpty()) {
            hideCountryDropDown();
            return;
        }

        showCountryDropDown();
        ArrayAdapter<Country> countryAdapter = new ArrayAdapter<>(this, R.layout.spinner_shipping_adress_item, countryList);
        countryAdapter.setDropDownViewResource(R.layout.spinner_category_dropdown_item);
        spinnerCountry.setAdapter(countryAdapter);
        spinnerCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                presenter.setCountry(countryList.get(i).getCode().toUpperCase(), countryList.get(i).getName());
                setupCityDropDownList(countryList.get(i).getRegionList(), positionRegion);
                positionRegion.set(-1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerCountry.setSelection(positionCountry);

    }

    private void setupEtPhoneNumber() {
        etPhoneNumber.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setPhoneNumber(s.toString());
                hidePhoneNumberErrorMessage();
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupEtPoBox() {
        etPoBox.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setPoBox(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupEtAddress() {
        etAddress.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setAddress(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupEtLastName() {
        etLastName.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setLastName(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupEtFirstName() {
        etFirstName.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setFirstName(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupEtEmail() {
        etEmail.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setEmail(s.toString());
                hideEmailErrorMessage();
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupCbSubscription() {
        cbSubscribeToNewsletter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                presenter.setSubscriptionToNewsletter(isChecked);
            }
        });
    }

    private void setupCbSaveData() {
        cbSaveData.setOnCheckedChangeListener((compoundButton, isChecked) -> presenter.setSaveData(isChecked));
    }

    @Override
    public void showLoading() {
        loader.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loader.setVisibility(View.GONE);
    }

    @Override
    public void showAllTextViews() {
        tvCustomerInformation.setVisibility(View.VISIBLE);
        tvShippingAddress.setVisibility(View.VISIBLE);
        tvContinueToShippingMethod.setVisibility(View.VISIBLE);
        cbSubscribeToNewsletter.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideAllTextViews() {
        tvCustomerInformation.setVisibility(View.GONE);
        tvShippingAddress.setVisibility(View.GONE);
        tvContinueToShippingMethod.setVisibility(View.GONE);
        cbSubscribeToNewsletter.setVisibility(View.GONE);
    }

    @Override
    public void showAllEditTexts() {
        etEmail.setVisibility(View.VISIBLE);
        etFirstName.setVisibility(View.VISIBLE);
        etLastName.setVisibility(View.VISIBLE);
        etAddress.setVisibility(View.VISIBLE);
        etPoBox.setVisibility(View.VISIBLE);
        etPhoneNumber.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideAllEditTexts() {
        etEmail.setVisibility(View.GONE);
        etFirstName.setVisibility(View.GONE);
        etLastName.setVisibility(View.GONE);
        etAddress.setVisibility(View.GONE);
        etPoBox.setVisibility(View.GONE);
        etPhoneNumber.setVisibility(View.GONE);
    }

    @Override
    public void showCountryDropDown() {
        spinnerCountry.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideCountryDropDown() {
        spinnerCountry.setVisibility(View.GONE);
    }

    @Override
    public void showRegionDropDown() {
        spinnerCity.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideRegionDropDown() {
        spinnerCity.setVisibility(View.GONE);
    }

    @Override
    public void showLoaderDialog() {
        mLoaderDialog = new CustomDialog(CheckoutShippingActivity.this, CommonConstants.DIALOG_LOADER);
        mLoaderDialog.setTitle(getResources().getString(R.string.checking_for_available_shipping_methods));
        mLoaderDialog.show();
    }

    @Override
    public void hideLoaderDialog() {
        if (mLoaderDialog != null)
            mLoaderDialog.cancel();
    }

    @Override
    public void openCheckoutBillingScreen() {
        Intent intent = new Intent(CheckoutShippingActivity.this, CheckoutBillingActivity.class);
        intent.putExtra(CommonConstants.INTENT_AVAILABLE_SHIPPING_METHODS, (ArrayList) presenter.getAvailableShippingMethods());
        intent.putExtra(CommonConstants.INTENT_SAVE_DATA, presenter.getSaveData());
        startActivity(intent);
    }

    @Override
    public void showSnackBarPleaseFillAllData() {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.checkout_shipping_scroll_view), getResources().getString(R.string.please_fill_all_data), Snackbar.LENGTH_SHORT);
        View view = snackbar.getView();
        view.setBackgroundColor(ContextCompat.getColor(CheckoutShippingActivity.this, R.color.dark_grey));
        snackbar.show();
    }

    @Override
    public void prefillEmail(String email) {
        etEmail.setText(email);
    }

    @Override
    public void prefillFirstName(String firstName) {
        etFirstName.setText(firstName);
    }

    @Override
    public void prefillLastName(String lastName) {
        etLastName.setText(lastName);
    }

    @Override
    public void prefillAddress(String address) {
        etAddress.setText(address);
    }

    @Override
    public void prefillCountry(int position) {
        spinnerCountry.setSelection(position);
    }

    @Override
    public void prefillRegion(int position) {
        spinnerCity.setSelection(position);
    }

    @Override
    public void prefillPoBox(String poBox) {
        etPoBox.setText(poBox);
    }

    @Override
    public void prefillPhoneNumber(String phoneNumber) {
        etPhoneNumber.setText(phoneNumber);
    }

    @Override
    public void prefillCountryAndRegion(List<Country> country, int positionCountry, int positionRegion) {
        setupCountryDropDownList(country, positionCountry, new AtomicInteger(positionRegion));
    }

    @Override
    public void showEmailErrorMessage() {
        tiEmail.setErrorEnabled(true);
        tiEmail.setError(getResources().getString(R.string.error_invalid_email));
    }

    @Override
    public void hideEmailErrorMessage() {
        if (tiEmail.isErrorEnabled()) {
            tiEmail.setError(null);
        }
    }

    @Override
    public void showPhoneNumberErrorMessage() {
        tiPhoneNumber.setErrorEnabled(true);
        tiPhoneNumber.setError(getResources().getString(R.string.error_invalid_phone_number));
    }

    @Override
    public void hidePhoneNumberErrorMessage() {
        if (tiPhoneNumber.isErrorEnabled()) {
            tiPhoneNumber.setError(null);
        }
    }

    @Override
    public void showErrorDialog() {
        new CustomDialog(CheckoutShippingActivity.this, CommonConstants.DIALOG_ONE_BUTTON)
                .setTitle(getString(R.string.error))
                .setContentText(getString(R.string.error_not_shipping_to_selected_location))
                .show();
    }

    @Override
    public void setSaveShippingInfoCheckbox(boolean shippingInfoSaved) {
        cbSaveData.setChecked(shippingInfoSaved);
    }

    @OnClick(R.id.tv_continue_to_shipping_method)
    public void onContinueToShippingMethodClick() {
        presenter.continueToShippingMethod();
    }
}
