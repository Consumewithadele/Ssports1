package com.sssports.sssports.models.jsonapi;

import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by mlukovic on 8/1/17.
 */

@JsonApi(type = "galleries")
public class Gallery extends Resource {
}
