package com.sssports.sssports.ui.checkoutbilling;

import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.magento.PaymentMethod;
import com.sssports.sssports.models.magento.ShippingMethod;
import com.sssports.sssports.models.magento.TotalSegment;

import java.util.List;

/**
 * Created by natalijaratajac on 8/25/17.
 */

public interface CheckoutBillingContract {

    interface CheckoutBillingView {

        void initializeShippingMethodAdapter();

        void initializePaymentMethodAdapter();

        void initializeWidgetForSummary();

        void setupCountryDropDownList(List<Country> countryList);

        void setShippingAddress(String shippingAddress);

//        void setCashOnDeliveryPaymentMethod();
//
//        void setCadsPaymentMethod();

        void setCardIconVisa();

        void setCardIconMasterCard();

        void setCardIconAmericanExpress();

        void setCardIconDinersClub();

        void setCardIconDiscover();

        void setCardIconJCB();

        void setDefaultCardIcon();

        void showCardDetails();

        void hideCardDetails();

        void showScreen();

        void hideScreen();

        void showCardNumberErrorMessage();

        void hideCardNumberErrorMessage();

        void showPhoneNumberErrorMessage();

        void hidePhoneNumberErrorMessage();

        void showLoading();

        void hideLoading();

        void disableBuyButton();

        void enableBuyButton();

        void showSnackBarPleaseFillAllData();

        void showLoaderDialog();

        void hideLoaderDialog();

        void openNextScreen(String orderId);

        void showPlacingOrderError();

        void showErrorDialog();

        void refreshSummary();

        void showCardHolderError();
    }

    interface CheckoutBillingPresenter {

        void loadData();

        void initializeScreen();

        List<PaymentMethod> getPaymentMethods();

        void setSameAsShippingAddressSelected(boolean flag);

        void setCardNumber(String cardNumber);

        void setCardHolder(String cardHolder);

        void setExpirationDate(String expirationDate);

        void setExpirationYear(int year);

        void setExpirationMonth(int month);

        void setCvv(String cvv);

        void findCardIcon(String s);

        void setPhoneNumber(String s);

        void setPoBox(String s);

        void setRegion(String s);

        void setCountry(String countryId, String countryName);

        void setAddress(String s);

        void setChosenShippingMethod(ShippingMethod shippingMethod);

        void setChosenPaymentMethod(PaymentMethod paymentMethod);

        void sendPaymentMethod(PaymentMethod paymentMethod);

        void buyItems();

        void setTotalAmountSegmentList(List<TotalSegment> totalSegmentList);

        void onRefreshSummaryError();


//        void setBillingAddressSameAsShipping();
    }
}
