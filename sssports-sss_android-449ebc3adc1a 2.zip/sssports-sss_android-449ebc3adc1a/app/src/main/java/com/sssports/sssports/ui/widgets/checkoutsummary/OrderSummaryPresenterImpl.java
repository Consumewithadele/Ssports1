package com.sssports.sssports.ui.widgets.checkoutsummary;

import android.text.TextUtils;

import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.magento.CartTotalSummary;
import com.sssports.sssports.networking.services.MagentoApi;

/**
 * Created by mlukovic on 9/1/17.
 */

public class OrderSummaryPresenterImpl implements SummaryMvpContract.Presenter {

    private SummaryMvpContract.View view;
    private SummaryMvpContract.Interactor interactor;
    private boolean isViewAttached;

    public OrderSummaryPresenterImpl(MagentoApi magentoApi, SummaryMvpContract.View view) {
        isViewAttached = true;
        interactor = new OrderSummaryInteractorImpl(magentoApi, this);
        this.view = view;
    }

    @Override
    public void loadSummary() {
        String cartId = SPDataManager.INSTANCE.getProductCartId();
        if (!TextUtils.isEmpty(cartId)) {
            interactor.getSummaryTotalList(cartId);
            view.showLoader(true);
        } else {
            view.showErrorSummary();
        }
    }

    @Override
    public void onSummaryDataReady(CartTotalSummary cartTotalSummary) {
        if (cartTotalSummary != null && cartTotalSummary.getItems() != null) {
            view.showSummary(cartTotalSummary.getTotalSegments(), cartTotalSummary.getBaseCurrencyCode());
            view.showLoader(false);
        } else {
            view.showErrorSummary();
            view.showLoader(false);
        }
    }

    @Override
    public void onViewDetached() {
        isViewAttached = false;
    }

    @Override
    public void onSummaryDataError() {
        view.showErrorSummary();
    }
}
