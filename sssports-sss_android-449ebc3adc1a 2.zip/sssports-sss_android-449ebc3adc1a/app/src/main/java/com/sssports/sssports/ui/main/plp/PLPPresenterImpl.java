package com.sssports.sssports.ui.main.plp;

import android.app.Activity;
import android.text.TextUtils;

import com.hannesdorfmann.mosby3.mvp.MvpBasePresenter;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.meta.Meta;

import java.util.HashMap;
import java.util.List;

import moe.banana.jsonapi2.ArrayDocument;

/**
 * Created by mlukovic on 8/3/17.
 */

public class PLPPresenterImpl extends MvpBasePresenter<PLPMVPContract.View> implements PLPMVPContract.Presenter {

    private static final String SORT_PRICE_DESCENDING = "-price";
    private static final String SORT_PRICE_ASCENDING = "price";
    private static final String SORT_NAME_DESCENDING = "-name";
    private static final String SORT_NAME_ASCENDING = "name";
    private static final String SORT_BY_LATEST = "-created_at";

    private PLPMVPContract.Interactor interactor;

    private boolean isProductsLoading;
    private static final int PAGE_SIZE = 8;
    private int currentPage = 0;
    private int lastPage = 1;
    private String mSortingCriteria = null;
    private String mCategoryId;
    private HashMap<Attribute, List<Option>> mFilterHashMap;
    private boolean shouldLoadFilters = true;

    public PLPPresenterImpl(Activity activity) {
        interactor = new PLPInteractorImpl(activity, this);
    }

    @Override
    public void loadProducts(String categoryId) {
        loadProducts(categoryId, mFilterHashMap);
    }

    public void loadProducts(String categoryId, HashMap<Attribute, List<Option>> filterMapString) {
        if (categoryId == null || TextUtils.isEmpty(categoryId)) {
            getView().showError();
            return;
        }
        mCategoryId = categoryId;
        if (!isProductsLoading && currentPage < lastPage) {
            isProductsLoading = true;
            interactor.getProducts(mCategoryId, currentPage + 1, PAGE_SIZE, mSortingCriteria, filterMapString);
            getView().showLoader(true);
        }
    }

    @Override
    public void onProductListDataReady(ArrayDocument<Product> products, Meta meta) {
        if (isViewAttached()) {
            if (products.size() == 0) {
                getView().showLoader(false);
                getView().showError();
            }
            lastPage = meta.getPage().getLastPage();
            currentPage = meta.getPage().getCurrentPage();
            getView().showProducts(products);
            getView().showNumberOfResults(meta.getPage().getTotal());

            if (shouldLoadFilters) {
                getView().loadFilterList(mCategoryId, meta.getPricing());
                shouldLoadFilters = false;
            }


            isProductsLoading = false;
            if (lastPage == currentPage)
                getView().showLoader(false);
        }
    }

    public void resetPaging() {
        currentPage = 0;
        lastPage = 1;
        getView().resetProductList();
    }

    @Override
    public void sortByPrice() {
        if (mSortingCriteria != null && mSortingCriteria.equalsIgnoreCase(SORT_PRICE_ASCENDING)) {
            mSortingCriteria = SORT_PRICE_DESCENDING;
            getView().showPriceDescending();
        } else {
            mSortingCriteria = SORT_PRICE_ASCENDING;
            getView().showPriceAscending();
        }
        resetPaging();
        isProductsLoading = false;
        loadProducts(mCategoryId);
    }

    @Override
    public void sortByName() {
        if (mSortingCriteria != null && mSortingCriteria.equalsIgnoreCase(SORT_NAME_ASCENDING)) {
            mSortingCriteria = SORT_NAME_DESCENDING;
            getView().showNameDescending();
        } else {
            mSortingCriteria = SORT_NAME_ASCENDING;
            getView().showNameAscending();
        }
        resetPaging();
        isProductsLoading = false;
        loadProducts(mCategoryId);
    }

    @Override
    public void sortByLatest() {
        mSortingCriteria = SORT_BY_LATEST;
        resetPaging();
        isProductsLoading = false;
        loadProducts(mCategoryId);
    }

    @Override
    public void changeCategory(String categoryId) {
        removeSortingCriteria();
        getView().resetProductList();
        resetPaging();
        resetFilters();
        isProductsLoading = false;
        loadProducts(categoryId);
    }

    private void resetFilters() {
        mFilterHashMap = null;
        shouldLoadFilters = true;
    }

    private void removeSortingCriteria() {
        mSortingCriteria = null;
        getView().hideSortingCriteria();
    }

    @Override
    public void onCategoryListReady(List<Category> categories) {
        if(isViewAttached()) {
            getView().showCategoryList(categories);
        }
    }

    @Override
    public void loadCategories(Integer parentId) {
        interactor.getCategories(String.valueOf(parentId));
    }

    @Override
    public void filterProductList(HashMap<Attribute, List<Option>> filterHashMap) {
        mFilterHashMap = filterHashMap;
        resetPaging();
        isProductsLoading = false;
        loadProducts(mCategoryId, filterHashMap);
    }

}
