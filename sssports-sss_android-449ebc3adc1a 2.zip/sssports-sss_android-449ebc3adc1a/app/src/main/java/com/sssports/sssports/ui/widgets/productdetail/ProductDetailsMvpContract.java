package com.sssports.sssports.ui.widgets.productdetail;

import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.ProductChild;
import com.sssports.sssports.models.jsonapi.ProductImage;

import java.util.List;

/**
 * Created by mlukovic on 8/18/17.
 */

public class ProductDetailsMvpContract {

    interface View {

        void showProductColor(String color);

        void showSizeList(List<ProductChild> filteredProductsBySize);

        void showErrorGettingSizeList();

        void showSelectedSize(ProductChild productChild);

        void showColorWayList(List<Option> optionColorList);

        void showProductName(String name);

        void showProductImages(List<ProductImage> images);

        void resetSizeLabel();

        void showPrice(ProductChild productChild);

        void showPrice(Product product);

        void disableProductSizeList();

        void disableColorWayList();

        void hideProductColor();
    }

    interface Presenter {

        void loadLoadData(Product product);

        void getSizeList();

        void onSizeChange(ProductChild productChild);

        void onColorChange(Option option);
    }
}
