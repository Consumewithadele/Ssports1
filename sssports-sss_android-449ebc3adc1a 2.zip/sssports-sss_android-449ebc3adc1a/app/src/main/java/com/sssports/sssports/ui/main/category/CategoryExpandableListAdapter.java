package com.sssports.sssports.ui.main.category;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Category;

import java.util.List;

/**
 * Created by mlukovic on 8/1/17.
 */

public class CategoryExpandableListAdapter extends BaseExpandableListAdapter {

    private OnCategoryClickListener mOnCategoryClickListener;

    private Context context;
    private List<Category> mCategoryList;

    public CategoryExpandableListAdapter(Context context, List<Category> categoryList, OnCategoryClickListener onCategoryClickListener) {
        this.context = context;
        mOnCategoryClickListener = onCategoryClickListener;
        mCategoryList = categoryList;
    }


    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return mCategoryList.get(groupPosition).getCategoryList().get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
//        if (convertView == null) {
            Category category = (Category) getChild(groupPosition, childPosition);
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.adapter_category_sub_item, null);
            TextView expandedListTextView = convertView.findViewById(R.id.tv_sub_category);
            LinearLayout llSubcategoryItem = convertView.findViewById(R.id.ll_subcategory_item);
            expandedListTextView.setText(category.getName());

            llSubcategoryItem.setOnClickListener(view -> mOnCategoryClickListener.onCategoryClick(category));
//        }
        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if (mCategoryList.get(groupPosition) == null)
            return 0;
        return mCategoryList.get(groupPosition).getCategoryList().size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return mCategoryList.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return mCategoryList.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int listPosition, boolean isExpanded, View convertView, ViewGroup parent) {

        if (context == null) return null;

        LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = layoutInflater.inflate(R.layout.adapter_category_group, null);
        TextView listTitleTextView = convertView.findViewById(R.id.category_title);
        Category category = (Category) getGroup(listPosition);
        listTitleTextView.setText(category.getName());

        ImageView ivGroupIndicator = convertView.findViewById(R.id.iv_group_indicator);
        RelativeLayout rlCategoryItem = convertView.findViewById(R.id.rl_category_item);

        if (getChildrenCount(listPosition) == 0) {
            ivGroupIndicator.setVisibility(View.GONE);
            rlCategoryItem.setOnClickListener(view -> mOnCategoryClickListener.onCategoryClick(category));
        } else {
            ivGroupIndicator.setVisibility(View.VISIBLE);
        }

        if (isExpanded) {

            ivGroupIndicator.setImageResource(R.drawable.icon_arrow_active);
            listTitleTextView.setTextColor(context.getResources().getColor(R.color.orange));
        } else {
            ivGroupIndicator.setImageResource(R.drawable.ic_arrow_down);
            listTitleTextView.setTextColor(context.getResources().getColor(R.color.dark_grey));
        }

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }

    public interface OnCategoryClickListener {
        void onCategoryClick(Category category);
    }
}
