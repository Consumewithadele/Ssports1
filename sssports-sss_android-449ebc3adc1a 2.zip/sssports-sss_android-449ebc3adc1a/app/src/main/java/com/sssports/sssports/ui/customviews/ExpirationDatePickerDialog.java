package com.sssports.sssports.ui.customviews;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Build;
import android.view.View;
import android.widget.DatePicker;

import com.sssports.sssports.R;

/**
 * Created by mlukovic on 8/30/17.
 */

public class ExpirationDatePickerDialog extends DatePickerDialog implements DatePicker.OnDateChangedListener {

    public ExpirationDatePickerDialog(Context context, OnDateSetListener callBack, int year, int monthOfYear, int dayOfMonth) {
        super(
                context,
                Build.VERSION.SDK_INT >= 21 ? R.style.MyDialogTheme : 0,
                callBack,
                year,
                monthOfYear,
                dayOfMonth
        );

        init(context);
    }

    private void init(Context context) {
        setTitle("");
        getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        getDatePicker().setCalendarViewShown(false);

        int day = context.getResources().getIdentifier("android:id/day", null, null);
        if(day != 0){
            View dayPicker = getDatePicker().findViewById(day);
            if(dayPicker != null){
                dayPicker.setVisibility(View.GONE);
            }
        }
    }

    public void onDateChanged(DatePicker view, int year, int month, int day) {

    }
}
