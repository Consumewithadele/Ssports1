package com.sssports.sssports.ui.widgets.checkoutsummary;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.magento.TotalSegment;

import java.util.List;

/**
 * Created by mlukovic on 9/1/17.
 */

public class AdapterSummary extends BaseAdapter {

    private List<TotalSegment> totalCartItemList;
    private String mBaseCurrencyCode;
    private Context mContext;

    public AdapterSummary(Context context, List<TotalSegment> totalCartItemList, String baseCurrencyCode) {
        this.totalCartItemList = totalCartItemList;
        mBaseCurrencyCode = baseCurrencyCode;
        mContext = context;
    }

    @Override
    public int getCount() {
        return totalCartItemList.size();
    }

    @Override
    public Object getItem(int i) {
        return totalCartItemList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;

        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.adapter_summary_order_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.totalSegmentName = convertView.findViewById(R.id.total_segment_name);
            viewHolder.totalSegmentValue = convertView.findViewById(R.id.total_segment_value);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        TotalSegment totalCartItem = totalCartItemList.get(position);

        viewHolder.totalSegmentName.setText(totalCartItem.getTitle());

        String formattedPrice = mContext.getResources().getString(R.string.dash);
        if (totalCartItem.getValue() != null) {
            formattedPrice = String.format(mContext.getResources().getString(R.string.price_formatting), totalCartItem.getValue().toString(), mBaseCurrencyCode);
        }
        viewHolder.totalSegmentValue.setText(formattedPrice);

        return convertView;
    }

    class ViewHolder {
        TextView totalSegmentName;
        TextView totalSegmentValue;
    }
}
