package com.sssports.sssports.ui.pdp;

import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.jsonapi.ProductChild;
import com.sssports.sssports.models.magento.CartItem;
import com.sssports.sssports.models.magento.CartItemRequest;
import com.sssports.sssports.networking.NetworkConstants;
import com.sssports.sssports.networking.services.MagentoApi;

import retrofit2.Response;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Created by Adeleclark on 8/25/17.
 */

public class ProductDetailsInteractorImpl implements ProductDetailsContract.ProductDetailsInteractor {

    private MagentoApi mMagentoApi;
    private ProductDetailsContract.ProductDetailsPresenter mPresenter;

    public ProductDetailsInteractorImpl(ProductDetailsContract.ProductDetailsPresenter presenter, MagentoApi magentoApi) {
        mMagentoApi = magentoApi;
        mPresenter = presenter;
    }

    @Override
    public void createCart() {
        mMagentoApi.createCart()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(response -> mPresenter.onCartCreated(response.body()),
                        throwable -> mPresenter.addToBagError());
    }


    @Override
        public void addToCart(String cartId, ProductChild productChild) {

        CartItem cartItem = new CartItem();
        cartItem.setSku(productChild.getSku());
        cartItem.setQty(1);
        cartItem.setQuoteId(cartId);
        CartItemRequest cartItemRequest = new CartItemRequest();
        cartItemRequest.setCartItem(cartItem);
        Timber.d("addToCart():  " + cartItem.toString());
        mMagentoApi.addToCart(cartId, cartItemRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Response<CartItem>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        mPresenter.addToBagError();
                    }

                    @Override
                    public void onNext(Response<CartItem> cartItemResponse) {
                        if (cartItemResponse.isSuccessful()) {
                            mPresenter.onAddToCartSuccess();
                        } else {
                            if (cartItemResponse.code() == NetworkConstants.HttpCode.HTTP_404) {
                                SPDataManager.INSTANCE.deleteProductCartId();
                                createCart();
                            } else {
                                mPresenter.addToBagError();
                            }
                        }
                    }
                });
    }

}
