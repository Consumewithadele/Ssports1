package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

import java.io.Serializable;

/**
 * Created by natalijaratajac on 9/3/17.
 */

public class ShippingMethod implements Serializable{

    @Json(name = "carrier_code")
    private String carrierCode;
    @Json(name = "method_code")
    private String methodCode;
    @Json(name = "carrier_title")
    private String carrierTitle;
    @Json(name = "method_title")
    private String methodTitle;
    @Json(name = "amount")
    private String amount;
    @Json(name = "base_amount")
    private String baseAmount;
    @Json(name = "available")
    private boolean available;
    @Json(name = "error_message")
    private String errorMessage;
    @Json(name = "price_excl_tax")
    private String priceExclTax;
    @Json(name = "price_incl_tax")
    private String priceInclTax;

    private transient boolean selected;

    public String getCarrierCode() {
        return carrierCode;
    }

    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public String getMethodCode() {
        return methodCode;
    }

    public void setMethodCode(String methodCode) {
        this.methodCode = methodCode;
    }

    public String getCarrierTitle() {
        return carrierTitle;
    }

    public void setCarrierTitle(String carrierTitle) {
        this.carrierTitle = carrierTitle;
    }

    public String getMethodTitle() {
        return methodTitle;
    }

    public void setMethodTitle(String methodTitle) {
        this.methodTitle = methodTitle;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBaseAmount() {
        return baseAmount;
    }

    public void setBaseAmount(String baseAmount) {
        this.baseAmount = baseAmount;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getPriceExclTax() {
        return priceExclTax;
    }

    public void setPriceExclTax(String priceExclTax) {
        this.priceExclTax = priceExclTax;
    }

    public String getPriceInclTax() {
        return priceInclTax;
    }

    public void setPriceInclTax(String priceInclTax) {
        this.priceInclTax = priceInclTax;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
