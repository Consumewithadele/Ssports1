
package com.sssports.sssports.models.sli;

import com.squareup.moshi.Json;

public class ResultMeta {

    @Json(name = "total")
    private Integer total;
    @Json(name = "this_page")
    private Integer thisPage;
    @Json(name = "requested")
    private Integer requested;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getThisPage() {
        return thisPage;
    }

    public void setThisPage(Integer thisPage) {
        this.thisPage = thisPage;
    }

    public Integer getRequested() {
        return requested;
    }

    public void setRequested(Integer requested) {
        this.requested = requested;
    }

}
