package com.sssports.sssports.ui.widgets;

/**
 * Created by Adeleclark on 7/3/17.
 */

public interface WidgetDirector {

    void construct();
}
