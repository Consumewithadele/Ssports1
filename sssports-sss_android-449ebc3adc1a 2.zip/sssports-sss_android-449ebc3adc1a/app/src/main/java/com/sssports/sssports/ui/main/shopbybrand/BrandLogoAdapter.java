package com.sssports.sssports.ui.main.shopbybrand;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Brand;

import java.util.List;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by natalijaratajac on 8/3/17.
 */

public class BrandLogoAdapter extends BaseAdapter {

    private List<Brand> mBrandList;
    private Context mContext;
    private CategoryClickListener mCategoryClickListener;

    public BrandLogoAdapter(List<Brand> brandList, Context context, CategoryClickListener categoryClickListener) {
        mBrandList = brandList;
        mContext = context;
        mCategoryClickListener = categoryClickListener;
    }

    @Override
    public int getCount() {
        if (mBrandList == null) return 0;
        return mBrandList.size();
    }

    @Override
    public Object getItem(int i) {
        return mBrandList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {

            convertView = inflater.inflate(R.layout.adapter_brand_logo_item, null);

            ImageView imageViewBrandLogo = convertView.findViewById(R.id.image_view_brand_logo);
            RelativeLayout rlBrandLogoItem = convertView.findViewById(R.id.rl_brand_logo_item);

            Brand brandLogo = mBrandList.get(position);

            if (brandLogo != null) {

                if (brandLogo.getImageUrl() != null) {

                    GlideApp.with(mContext)
                            .load(brandLogo.getImageUrl())
                            .transition(withCrossFade())
                            .placeholder(R.drawable.loading_placeholder)
                            .error(R.drawable.loading_placeholder)
                            .into(imageViewBrandLogo);
                }
            }

            rlBrandLogoItem.setOnClickListener(view -> mCategoryClickListener.onCategoryItemClick(position));
        }

        return convertView;
    }

    interface CategoryClickListener {
        void onCategoryItemClick(int position);
    }

}
