package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

import java.io.Serializable;

/**
 * Created by mlukovic on 7/25/17.
 */

@JsonApi(type = "actions")
public class Action extends Resource implements Serializable {

    private final static long serialVersionUID = 2261182681195644458L;

    @Json(name = "created-at")
    private String createdAt;
    @Json(name = "updated-at")
    private String updatedAt;
    @Json(name = "block-id")
    private Integer blockId;
    @Json(name = "text")
    private String text;
    @Json(name = "link")
    private String link;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Integer getBlockId() {
        return blockId;
    }

    public void setBlockId(Integer blockId) {
        this.blockId = blockId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

}
