package com.sssports.sssports.ui.widgets.salebanner;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Action;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.widgets.WidgetType;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Main class responsible for building Sale Widget layout and functionality
 */

public class WidgetTypeSaleBanner implements WidgetType {

    private Activity mActivity;
    private Widget mWidget;

    @BindView(R.id.tv_sale_banner_title) TextView tvTitle;
    @BindView(R.id.tv_sale_banner_description) TextView tvDescription;
    @BindView(R.id.button_cta_sale_banner) Button buttonCTA;

    public WidgetTypeSaleBanner(Activity activity, Widget widget){
        mActivity = activity;
        mWidget = widget;
    }

    @Override
    public View buildView() {
        View saleBannerWidget = mActivity.getLayoutInflater().inflate(R.layout.widget_type_sale_banner, null);
        ButterKnife.bind(this, saleBannerWidget);

        if (isWidgetAvailable(mWidget)) {
            tvTitle.setText(mWidget.getBlockList().get(0).getLabel());
            tvDescription.setText(mWidget.getBlockList().get(0).getText());
            Action action = mWidget.getBlockList().get(0).getActionList().get(0);
            if (action != null && !TextUtils.isEmpty(action.getText()) && !TextUtils.isEmpty(action.getLink())) {
                buttonCTA.setText(action.getText());
            } else {
                buttonCTA.setVisibility(View.GONE);
            }
        } else {
            return null;
        }

        return saleBannerWidget;
    }

    private boolean isWidgetAvailable(Widget mWidget) {
        return mWidget != null && mWidget.getBlockList() != null
                && mWidget.getBlockList().size() > 0
                && mWidget.getBlockList().get(0) != null
                && !TextUtils.isEmpty(mWidget.getBlockList().get(0).getLabel())
                && !TextUtils.isEmpty(mWidget.getBlockList().get(0).getText())
                && mWidget.getBlockList().get(0).getActionList() != null
                && mWidget.getBlockList().get(0).getActionList().size() > 0;
    }

    @OnClick(R.id.button_cta_sale_banner)
    public void onShopNowButtonClick() {
        Action action = mWidget.getBlockList().get(0).getActionList().get(0);
        ((BaseActivity) mActivity).getNavigator().openLink(mActivity, action.getLink());
    }
}
