package com.sssports.sssports.ui.main.plp;

import android.app.Activity;
import android.text.TextUtils;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.sssports.sssports.SSSApp;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.meta.Meta;
import com.sssports.sssports.networking.services.SSSApi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import moe.banana.jsonapi2.Document;
import moe.banana.jsonapi2.Resource;
import retrofit2.http.Query;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import rx.subjects.PublishSubject;
import timber.log.Timber;

/**
 * Created by mlukovic on 8/3/17.
 */

public class PLPInteractorImpl implements PLPMVPContract.Interactor {

    private SSSApi sssApi;
    private PLPMVPContract.Presenter mPresenter;
    PublishSubject<HashMap<String, String>> subjectGetProducts; //use this to cancel all old API request and to return only latest one

    public PLPInteractorImpl(Activity activity, PLPMVPContract.Presenter presenter) {
        sssApi = ((SSSApp) activity.getApplication()).getApplicationComponent().sssService();
        mPresenter = presenter;
        initGetProductsSubject();
    }

    @Override
    public void getProducts(String categoryId, int pageNumber, int pageSize, String sortingCriteria, HashMap<Attribute, List<Option>> attributeFilterList) {
        HashMap<String, String> stringListHashMap = new HashMap<>();

        if (!TextUtils.isEmpty(categoryId)) stringListHashMap.put(SSSApi.FILTER_CATEGORY_ID, categoryId);
        if (!TextUtils.isEmpty(sortingCriteria)) stringListHashMap.put(SSSApi.SORT, sortingCriteria);
        stringListHashMap.put(SSSApi.PAGE_NUMBER, String.valueOf(pageNumber));
        stringListHashMap.put(SSSApi.PAGE_SIZE, String.valueOf(pageSize));

        if (attributeFilterList != null) {
            for (HashMap.Entry<Attribute, List<Option>> entry : attributeFilterList.entrySet()) {
                StringBuilder optionsStringBuilder = new StringBuilder();
                String attributeCode = entry.getKey().getAttributeCode();
                if (entry.getValue().size() > 0) {
                    for (Option option : entry.getValue()) {
                        optionsStringBuilder.append(option.getId());
                        optionsStringBuilder.append(",");
                    }
                    optionsStringBuilder.deleteCharAt(optionsStringBuilder.length() - 1);
                    stringListHashMap.put("filter[" + attributeCode + "]", optionsStringBuilder.toString());
                }
            }

        }

        subjectGetProducts.onNext(stringListHashMap);
    }

    private void initGetProductsSubject() {
        subjectGetProducts = PublishSubject.create();
        subjectGetProducts.switchMap(stringListHashMap -> sssApi.getProductsByCategory(stringListHashMap)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io()))
                .subscribe(productDocument -> {
                            Meta metaData = parseMetaData(productDocument);
                            mPresenter.onProductListDataReady(productDocument.asArrayDocument(), metaData);
                        },
                        throwable -> Timber.d("Error getting blocks"));
    }


    @Override
    public void getCategories(String categoryId) {
        sssApi.getCategory(categoryId, "children")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(
                        category ->  mPresenter.onCategoryListReady(category.getCategoryList()),
                        throwable -> Timber.d("Error getting categories: " + throwable.getMessage()));

    }

    private Meta parseMetaData(Document<Product> resource) {
        Moshi moshi = new Moshi.Builder().build();
        JsonAdapter<Meta> pageJsonAdapter = moshi.adapter(Meta.class);
        if (resource == null || resource.getMeta() == null) {
            return null;
        } else {
            return (Meta) resource.getMeta().get(pageJsonAdapter);
        }
    }


}
