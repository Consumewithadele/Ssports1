package com.sssports.sssports.ui.main.filter;

import android.app.Activity;

import com.sssports.sssports.SSSApp;
import com.sssports.sssports.networking.services.SSSApi;

import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by mlukovic on 8/7/17.
 */

public class FilterListInteractorImpl implements FilterMVPContract.Interactor {

    private SSSApi sssApi;
    private FilterMVPContract.Presenter mPresenter;

    public FilterListInteractorImpl(Activity activity, FilterMVPContract.Presenter presenter) {
        sssApi = ((SSSApp) activity.getApplication()).getApplicationComponent().sssService();
        mPresenter = presenter;
    }

    @Override
    public void getFilterList(String categoryId) {
        sssApi.getFilterAttributes(categoryId, "options")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(
                        attributeDocument -> mPresenter.onFilterListDataReady(attributeDocument.asArrayDocument()),
                        throwable -> mPresenter.onGettingFilterListError(throwable)
                );
    }
}
