package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class PaymentMethodsAndTotals {

    @Json(name = "payment_methods")
    private List<PaymentMethod> paymentMethods;

    @Json(name = "totals")
    private Totals totals;

    public List<PaymentMethod> getPaymentMethods() {
        return paymentMethods;
    }

    public void setPaymentMethods(ArrayList<PaymentMethod> paymentMethods) {
        this.paymentMethods = paymentMethods;
    }

    public Totals getTotals() {
        return totals;
    }

    public void setTotals(Totals totals) {
        this.totals = totals;
    }
}
