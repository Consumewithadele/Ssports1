package com.sssports.sssports.ui.checkoutsuccess;

/**
 * Created by mlukovic on 9/6/17.
 */

public class SuccessMvpContract {

    interface View {

        void showThankYouMessageWithOrderNumber(String order);

        void showThankYouWithoutOrderNumber();

        void showLoader(boolean visible);

        void hideThankYouText();
    }

    interface Presenter {

        void loadOrderDetails(String orderId);
    }
}
