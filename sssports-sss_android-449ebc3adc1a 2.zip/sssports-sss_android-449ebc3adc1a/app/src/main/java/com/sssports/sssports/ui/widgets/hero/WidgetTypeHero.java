package com.sssports.sssports.ui.widgets.hero;

import android.app.Activity;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.main.MainScreenListener;
import com.sssports.sssports.ui.widgets.WidgetType;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.relex.circleindicator.CircleIndicator;

/**
 * Main class responsible for building Hero Widget layout and functionality
 */

public class WidgetTypeHero implements WidgetType, HeroWidgetContract.HeroWidgetView {

    @BindView(R.id.view_pager_hero) ViewPager viewPagerHero;
    @BindView(R.id.indicator) CircleIndicator circleIndicator;
    @BindView(R.id.ll_hero_widget) LinearLayout llHeroWidget;

    private HeroWidgetContract.HeroWidgetPresenter heroWidgetPresenter;
    private Widget mWidget;
    private Activity mActivity;
    private int mCurrentPage = 0;
    private boolean mAutoScrollEnabled;

    public WidgetTypeHero(Activity activity, Widget widget, boolean autoScrollEnabled) {
        mActivity = activity;
        mWidget = widget;
        mAutoScrollEnabled = autoScrollEnabled;
    }

    @Override
    public View buildView() {
        View widgetCategoryView = mActivity.getLayoutInflater().inflate(R.layout.widget_type_hero, null);
        ButterKnife.bind(this, widgetCategoryView);

        heroWidgetPresenter = new HeroWidgetPresenterImpl(this, mWidget);
        heroWidgetPresenter.loadData();

        return widgetCategoryView;
    }

    @Override
    public void showBlockList(List<Block> blockList) {
        HeroAdapter adapter = new HeroAdapter(mWidget.getBlockList(),
                mActivity,
                link -> ((BaseActivity)mActivity).getNavigator().openLink(mActivity, link));

        viewPagerHero.setAdapter(adapter);
        circleIndicator.setViewPager(viewPagerHero);

        if (mAutoScrollEnabled) {
            playAutoScroll();
        }
    }

    @Override
    public void showLoader() {
        //TODO showLoader() WidgetTypeHero
    }

    @Override
    public void showError() {
        //TODO showError() WidgetTypeHero
    }

    @Override
    public void hideWidget() {
        llHeroWidget.setVisibility(View.GONE);
    }

    private void playAutoScroll() {
        Handler handler = new Handler();

        Runnable update = () -> {
            if (mCurrentPage == mWidget.getBlockList().size()) {
                mCurrentPage = 0;
            }
            viewPagerHero.setCurrentItem(mCurrentPage++, true);
        };

        new Timer().schedule(new TimerTask() {

            @Override
            public void run() {
                handler.post(update);
            }
        }, 0, 4000);
    }
}
