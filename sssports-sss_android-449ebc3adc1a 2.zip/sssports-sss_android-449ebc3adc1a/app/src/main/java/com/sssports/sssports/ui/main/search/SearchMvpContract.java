package com.sssports.sssports.ui.main.search;

import java.util.List;

/**
 * Created by mlukovic on 9/1/17.
 */

public class SearchMvpContract {

    public interface View {

        void showSearchResults(List<Object> searchResult, String mKeyWord);

        void clearResultList();

        void showSearchLoader(boolean visible);
    }

    public interface Presenter {

        void search(String query);

        void onAttach();

        void onDetach();
    }
}
