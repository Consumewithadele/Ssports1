package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class ShippingInformation {

    @Json(name = "addressInformation")
    private AddressInformation addressInformation;

    public AddressInformation getAddressInformation() {
        return addressInformation;
    }

    public void setAddressInformation(AddressInformation addressInformation) {
        this.addressInformation = addressInformation;
    }
}
