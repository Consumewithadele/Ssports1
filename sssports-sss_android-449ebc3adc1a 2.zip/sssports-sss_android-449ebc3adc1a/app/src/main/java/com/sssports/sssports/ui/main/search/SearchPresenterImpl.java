package com.sssports.sssports.ui.main.search;

import android.text.TextUtils;

import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.sli.Result;
import com.sssports.sssports.models.sli.SearchResult;
import com.sssports.sssports.models.sli.Suggestion;
import com.sssports.sssports.networking.NetworkConstants;
import com.sssports.sssports.networking.services.SliApi;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import retrofit2.Response;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import rx.subjects.PublishSubject;
import timber.log.Timber;

/**
 * Created by mlukovic on 9/3/17.
 */

public class SearchPresenterImpl implements SearchMvpContract.Presenter {

    private static final long SEARCH_DELAY_TIME = 500;
    private SearchMvpContract.View view;
    private boolean isViewAttached;
    private SliApi sliApi;
    private PublishSubject<String> subjectSearch;
    private String mKeyWord;

    public SearchPresenterImpl(SliApi sliApi, SearchMvpContract.View view) {
        this.sliApi = sliApi;
        this.view = view;
        this.initSearchSubject();
    }

    /**
     * Query the search result
     *
     * @param query Text for querying the search result
     */
    @Override
    public void search(String query) {
        if (TextUtils.isEmpty(query)) {
            view.clearResultList();
        } else {
            mKeyWord = query;
            subjectSearch.onNext(query);
            view.showSearchLoader(true);
        }
    }

    /**
     * Attaches the view
     */
    @Override
    public void onAttach() {
        isViewAttached = true;
    }

    /**
     * Detaches the view
     */
    @Override
    public void onDetach() {
        isViewAttached = false;
    }

    /**
     * Initializes the search engine.
     * It will return only latest result and all other requests will be canceled.
     */
    private void initSearchSubject() {
        subjectSearch = PublishSubject.create();
        String currency = SPDataManager.INSTANCE.getCurrentCurrency();
        subjectSearch.debounce(SEARCH_DELAY_TIME, TimeUnit.MILLISECONDS)
                .filter(query -> !TextUtils.isEmpty(query))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .switchMap(query -> sliApi.search(query, NetworkConstants.SEARCH_FORMAT_RESPONSE_JSON_FULL, currency)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .unsubscribeOn(Schedulers.io())
                )
                .subscribe(this::showResults, throwable -> view.showSearchLoader(false));
    }

    private void showResults(Response<SearchResult> searchResultResponse) {
        if (isViewAttached) {
            if (searchResultResponse != null && searchResultResponse.isSuccessful() && searchResultResponse.body() != null) {
                SearchResult searchResult = searchResultResponse.body();
                List<Object> searchResultList = new ArrayList<>();
                if (searchResult.getSuggestions() != null) {
                    List<Suggestion> suggestionList = searchResult.getSuggestions();
                    searchResultList.addAll(suggestionList.subList(0, Math.min(suggestionList.size(), 5)));
                }
                if (searchResult.getResults() != null) {
                    List<Result> resultList = searchResult.getResults();
                    searchResultList.addAll(resultList.subList(0, Math.min(resultList.size(), 10)));
                }
                view.showSearchResults(searchResultList, mKeyWord);
                view.showSearchLoader(false);
            }
        }
    }


}
