package com.sssports.sssports.ui.customviews;

/**
 * Created by mlukovic on 7/17/17.
 */

public interface ScrollViewListener {
    void onScrollChanged(ScrollViewExt scrollView, int x, int y, int oldx, int oldy);
}
