package com.sssports.sssports.ui.checkoutshipping;

import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.magento.ShippingMethod;

import java.util.List;

/**
 * Created by natalijaratajac on 8/25/17.
 */

public interface CheckoutShippingContract {

    interface CheckoutShippingView {

        void showLoading();

        void hideLoading();

        void showAllTextViews();

        void hideAllTextViews();

        void showAllEditTexts();

        void hideAllEditTexts();

        void showCountryDropDown();

        void hideCountryDropDown();

        void showRegionDropDown();

        void hideRegionDropDown();

        void showLoaderDialog();

        void hideLoaderDialog();

        void openCheckoutBillingScreen();

        void showSnackBarPleaseFillAllData();

        void prefillEmail(String email);

        void prefillFirstName(String firstName);

        void prefillLastName(String lastName);

        void prefillAddress(String address);

        void prefillCountry(int position);

        void prefillRegion(int position);

        void prefillPoBox(String poBox);

        void prefillPhoneNumber(String phoneNumber);

        void prefillCountryAndRegion(List<Country> country, int positionCountry, int positionRegion);

        void showEmailErrorMessage();

        void hideEmailErrorMessage();

        void showPhoneNumberErrorMessage();

        void hidePhoneNumberErrorMessage();

        void showErrorDialog();

        void setSaveShippingInfoCheckbox(boolean shippingInfoSaved);
    }

    interface CheckoutShippingPresenter {

        void loadData();

        void setPhoneNumber(String s);

        void setPoBox(String s);

        void setRegion(String s);

        void setCountry(String countryId, String countryName);

        void setAddress(String s);

        void setLastName(String s);

        void setFirstName(String s);

        void setEmail(String s);

        void setSubscriptionToNewsletter(boolean isChecked);

        void setSaveData(boolean isChecked);

        boolean getSaveData();

        void continueToShippingMethod();

        void prefillAllDataFromSharedPefs();

        List<ShippingMethod> getAvailableShippingMethods();
    }
}
