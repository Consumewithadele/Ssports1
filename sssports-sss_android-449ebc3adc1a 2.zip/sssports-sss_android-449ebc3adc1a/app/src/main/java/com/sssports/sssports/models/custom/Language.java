package com.sssports.sssports.models.custom;

import android.content.Context;

/**
 * Created by mlukovic on 8/16/17.
 */

public class Language {

    private String code;
    private int label;
    private Context context;

    public Language(Context context, String code, int label) {
        this.code = code;
        this.label = label;
        this.context = context;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getLabel() {
        return label;
    }

    public void setLabel(int label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return context.getResources().getString(label);
    }
}
