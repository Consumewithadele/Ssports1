package com.sssports.sssports.ui.widgets.producthorizontalscroll;

import android.animation.Animator;
import android.app.Activity;
import android.content.res.Resources;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Adapter for Product Horizontal Scroll Widget with the list of Blocks
 */

public class ProductAdapter extends PagerAdapter {

    private Activity activity;
    private List<Product> productList;
    private ProductClickListener mProductClickListener;

    @BindView(R.id.product_item_1) LinearLayout ll_product1;
    @BindView(R.id.product_item_2) LinearLayout ll_product2;

    public ProductAdapter(Activity activity, List<Product> productList, ProductClickListener productClickListener) {
        this.activity = activity;
        this.productList = productList;
        mProductClickListener = productClickListener;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        LayoutInflater inflater = LayoutInflater.from(activity);
        ViewGroup layout = (ViewGroup) inflater.inflate(R.layout.adapter_horizontal_products_widget, container, false);
        ButterKnife.bind(this, layout);
        position = position * 2;

        populateItem(layout, position);
        position++;
        if (position < getRealCount()) {
            ll_product1.setVisibility(View.VISIBLE);
            populateItem(layout, position);
        } else {
            ll_product2.setVisibility(View.INVISIBLE);
        }
        container.addView(layout);

        return layout;
    }

    private void populateItem(ViewGroup layout, int position) {
        LinearLayout linearLayout;

        if (position % 2 == 0) {
            linearLayout = layout.findViewById(R.id.product_item_1);
        } else {
            linearLayout = layout.findViewById(R.id.product_item_2);
        }

        Product product = productList.get(position);

        Resources resources = activity.getResources();
        int numberOfColors = product.getColorCount();
        String numberOfColorsLabel = resources.getQuantityString(R.plurals.number_of_colors, numberOfColors, numberOfColors);

        ((TextView) linearLayout.findViewById(R.id.text_view_product_name)).setText(product.getName());
        ((TextView) linearLayout.findViewById(R.id.text_view_num_colors)).setText(numberOfColorsLabel);

        ImageView productImage = linearLayout.findViewById(R.id.image_view_product);

        GlideApp.with(activity)
                .load(product.getThumbnailUrl())
                .transition(withCrossFade())
                .placeholder(R.drawable.loading_placeholder)
                .error(R.drawable.loading_placeholder)
                .into(productImage);


        linearLayout.setOnClickListener(view -> mProductClickListener.onClick(product.getAppLink()));

        ImageView ivWishListIcon = linearLayout.findViewById(R.id.icon_wish_list);
        LottieAnimationView wishListAnimation = linearLayout.findViewById(R.id.icon_wish_list_anim);

        if (product.isInWishList()) {
            ivWishListIcon.setSelected(true);
        } else {
            ivWishListIcon.setSelected(false);
        }


        wishListAnimation.addAnimatorListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation, boolean isReverse) {
            }

            @Override
            public void onAnimationEnd(Animator animation, boolean isReverse) {
                wishListAnimation.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationStart(Animator animator) {
            }

            @Override
            public void onAnimationEnd(Animator animator) {
                wishListAnimation.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationCancel(Animator animator) {
            }

            @Override
            public void onAnimationRepeat(Animator animator) {
            }
        });

        ivWishListIcon.setOnClickListener(view -> {

            if (product.isInWishList()) {
                ivWishListIcon.setSelected(false);
            } else {
                wishListAnimation.setVisibility(View.VISIBLE);
                wishListAnimation.playAnimation();
                ivWishListIcon.setSelected(true);
            }
            product.setInWishList(!product.isInWishList());
        });

    }

    @Override
    public int getCount() {
        return (productList.size() / 2) + (productList.size() % 2);
    }

    private int getRealCount() {
        return productList.size();
    }

    @Override
    public void destroyItem(ViewGroup collection, int position, Object view) {
        collection.removeView((View) view);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    public interface ProductClickListener {
        void onClick(String link);
    }

    @Override
    public int getItemPosition(Object item) {
        return POSITION_NONE;
    }

}
