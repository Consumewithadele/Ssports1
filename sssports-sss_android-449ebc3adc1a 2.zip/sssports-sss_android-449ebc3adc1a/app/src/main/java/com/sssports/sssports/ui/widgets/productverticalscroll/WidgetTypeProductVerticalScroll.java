package com.sssports.sssports.ui.widgets.productverticalscroll;

import android.app.Activity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.customviews.ExpandableHeightGridView;
import com.sssports.sssports.ui.customviews.ScrollViewExt;
import com.sssports.sssports.ui.customviews.ScrollViewListener;
import com.sssports.sssports.ui.main.MainScreenListener;
import com.sssports.sssports.ui.widgets.WidgetType;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Main class responsible for building Product Vertical Scroll Widget layout and functionality
 */

public class WidgetTypeProductVerticalScroll implements WidgetType, ProductVerticalContract.ProductVerticalView, ScrollViewListener {

    @BindView(R.id.grid_view_products) ExpandableHeightGridView gridViewProducts;
    @BindView(R.id.product_loader) ProgressBar productLoader;
    @BindView(R.id.vertical_scroll_product_title) TextView tvTitle;
    @BindView(R.id.text_view_description) TextView tvDescription;

    private Activity mActivity;
    private Widget mWidget;
    private ProductVerticalAdapter mProductVerticalAdapter;
    private ScrollViewExt mScrollView;
    private ProductVerticalContract.ProductVerticalPresenter presenter;

    public WidgetTypeProductVerticalScroll(Activity activity, Widget widget, ScrollView scrollView) {
        mActivity = activity;
        mWidget = widget;
        mScrollView = (ScrollViewExt) scrollView;
    }

    @Override
    public View buildView() {
        View view = mActivity.getLayoutInflater().inflate(R.layout.widget_type_vertical_scroll_product, null);
        ButterKnife.bind(this, view);

        presenter = new ProductVerticalPresenterImpl(this, mWidget, (BaseActivity) mActivity);
        initProductList();
        presenter.loadProducts();
        return view;
    }

    private void initProductList() {
        ArrayList<Product> products = new ArrayList<>();
        mProductVerticalAdapter = new ProductVerticalAdapter(mActivity, products,
                link -> ((BaseActivity) mActivity).getNavigator().openLink(mActivity, link));
        gridViewProducts.setExpanded(true);
        gridViewProducts.setAdapter(mProductVerticalAdapter);
        mScrollView.setScrollViewListener(this);
    }

    @Override
    public void onScrollChanged(ScrollViewExt scrollView, int x, int y, int oldx, int oldy) {
        // We take the last child in the scrollview
        // TODO Currently it's only possible that ProductVerticalScrollWidget is the last one. Try to create generic solution
        View lastChild = scrollView.getChildAt(scrollView.getChildCount() - 1);
        int diff = (lastChild.getBottom() - (scrollView.getHeight() + scrollView.getScrollY()));

        // load products if scroll reached the end
        if (diff <= mActivity.getResources().getDimensionPixelSize(R.dimen.loaderOffset)) {
            presenter.loadProducts();
        }
    }

    @Override
    public void addProductList(List<Product> productList) {
        mProductVerticalAdapter.addProducts(productList);
    }

    @Override
    public void showLoader() {
        productLoader.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoader() {
        productLoader.setVisibility(View.GONE);
    }

    @Override
    public void showTitle(String label) {
        tvTitle.setText(label);
    }

    @Override
    public void showDescription(String text) {
        tvDescription.setText(text);
    }
}
