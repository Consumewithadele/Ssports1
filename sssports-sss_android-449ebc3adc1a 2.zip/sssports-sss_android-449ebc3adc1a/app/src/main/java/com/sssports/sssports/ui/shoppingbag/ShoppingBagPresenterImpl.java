package com.sssports.sssports.ui.shoppingbag;

import android.text.TextUtils;

import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.custom.CartItemViewModel;
import com.sssports.sssports.models.magento.CartItem;
import com.sssports.sssports.networking.services.MagentoApi;
import com.sssports.sssports.networking.services.SSSApi;

import java.util.List;

/**
 * Created by mlukovic on 8/26/17.
 */

public class ShoppingBagPresenterImpl implements ShoppingBagMvpContract.Presenter {

    private ShoppingBagMvpContract.View view;
    private ShoppingBagMvpContract.Interactor interactor;
    private boolean isViewAttached;

    public ShoppingBagPresenterImpl(ShoppingBagMvpContract.View view, MagentoApi magentoApi, SSSApi sssApi) {
        this.view = view;
        interactor = new ShoppingCartInteractorImpl(this, magentoApi, sssApi);
        isViewAttached = true;
    }

    @Override
    public void loadCartItems() {
        String cartId = SPDataManager.INSTANCE.getProductCartId();
        view.showCheckoutButton(false);
        view.hideOverlayError();

        if (!TextUtils.isEmpty(cartId)) {
            interactor.getCartItems(cartId);
            view.showLoader(true);
        } else {
            view.showErrorEmptyMessage();
        }
    }

    @Override
    public void onCartItemsReady(List<CartItemViewModel> cartItemList) {
        if (isViewAttached) {
            view.showCartItemList(cartItemList);
            view.showCheckoutButton(true);
            view.showLoader(false);
            view.showWidgets();
        }
    }

    @Override
    public void onGetCartItemsError() {
        if (isViewAttached) {
            view.showErrorEmptyMessage();
            view.showLoader(false);
            view.showCheckoutButton(false);
        }
    }

    @Override
    public void onViewDetached() {
        isViewAttached = false;
    }

    @Override
    public void removeItemFromCart(CartItemViewModel cartItem) {
        view.showLoader(true);
        interactor.deleteItemFromCart(cartItem);
    }

    @Override
    public void onDeleteCartItemSuccess(CartItemViewModel cartItem) {
        view.showLoader(false);
        view.showCartItemDeletedMessage(cartItem);
        view.refreshSummary();
    }

    @Override
    public void onDeleteCartItemError(CartItemViewModel cartItem) {
        view.showDeleteCartItemError(cartItem);
    }

    @Override
    public void deleteOneItemToCart(CartItemViewModel cartItemViewModel) {
        interactor.deleteOneItemFromCart(cartItemViewModel);
        view.showLoader(true);
    }

    @Override
    public void addOneItemToCart(CartItem cartItem) {
        view.showLoader(true);
        interactor.addOneItemToCart(cartItem);
    }

    @Override
    public void noInternetConnection() {
        if(isViewAttached) {
            view.showInternetConnectionErrorMessage();
        }
    }

    @Override
    public void onAddItemToCartError() {
        if(isViewAttached) {
            view.showAddItemToCartError();
            view.showLoader(false);
        }
    }

    @Override
    public void onAddItemToCartSuccess(CartItem cartItem) {
        if (isViewAttached) {
            view.updateItem(cartItem);
            view.showLoader(false);
            view.refreshSummary();
        }
    }

    @Override
    public void onErrorThereIsNoItem(CartItem cartItem) {
        if (isViewAttached) {
            view.showErrorItemNotAvailable(cartItem);
            view.showLoader(false);
        }
    }

    @Override
    public void onDeleteOneItemError(CartItemViewModel cartItemViewModel) {
        if (isViewAttached) {
            view.showErrorDeletingItem();
            view.showLoader(false);
        }
    }

    @Override
    public void onDeleteOneItemSuccess(CartItemViewModel cartItemViewModel) {
        if (isViewAttached) {
            view.updateItemDelete(cartItemViewModel);
            view.showLoader(false);
            view.refreshSummary();
        }
    }

}
