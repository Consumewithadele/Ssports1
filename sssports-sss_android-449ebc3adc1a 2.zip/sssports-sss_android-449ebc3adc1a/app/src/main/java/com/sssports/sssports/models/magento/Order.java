package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by mlukovic on 9/6/17.
 */

public class Order {

    @Json(name = "increment_id")
    private String incrementId;

    public String getIncrementId() {
        return incrementId;
    }

    public void setIncrementId(String incrementId) {
        this.incrementId = incrementId;
    }
}
