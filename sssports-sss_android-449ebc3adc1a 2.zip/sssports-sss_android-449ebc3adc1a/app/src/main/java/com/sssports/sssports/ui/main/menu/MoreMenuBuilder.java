package com.sssports.sssports.ui.main.menu;

import com.sssports.sssports.R;
import com.sssports.sssports.models.custom.MenuItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mlukovic on 8/15/17.
 */

public class MoreMenuBuilder {

    public static final String ACTION_HOME = "action_home";
    public static final String ACTION_MY_ACCOUNT = "action_my_account";
    public static final String ACTION_SHOP_NOW = "action_shop_now";
    public static final String ACTION_BLOG = "action_blog";
    public static final String ACTION_OUR_STORES = "action_our_stores";
    public static final String ACTION_MY_ORDERS = "action_my_orders";
    public static final String ACTION_APP_SETTINGS = "action_app_settings";
    public static final String ACTION_ABOUT_SSS = "action_about_sss";
    public static final String ACTION_SEND_FEEDBACK = "action_send_feedback";
    public static final String ACTION_SHOPPING_BAG = "action_shopping_bag";

    public static List<MenuItem> build() {
        List<MenuItem> menuItems = new ArrayList<>();

        menuItems.add(new MenuItem(ACTION_HOME, R.drawable.ic_menu_home, R.string.menu_home));
//        menuItems.add(new MenuItem(ACTION_MY_ACCOUNT, R.drawable.ic_menu_my_account, R.string.menu_my_account));
        menuItems.add(new MenuItem(ACTION_SHOP_NOW, R.drawable.ic_menu_shop_now, R.string.menu_shop_now));
        menuItems.add(new MenuItem(ACTION_BLOG, R.drawable.ic_menu_blog, R.string.menu_blog));
        menuItems.add(new MenuItem(ACTION_SHOPPING_BAG, R.drawable.ic_bag_main, R.string.shopping_bag_title));
//        menuItems.add(new MenuItem(ACTION_OUR_STORES, R.drawable.ic_menu_our_stores, R.string.menu_stores));
//        menuItems.add(new MenuItem(ACTION_MY_ORDERS, R.drawable.ic_menu_my_orders, R.string.menu_my_orders));
//        menuItems.add(new MenuItem(ACTION_APP_SETTINGS, R.drawable.ic_menu_settings, R.string.menu_app_settings));
//        menuItems.add(new MenuItem(ACTION_ABOUT_SSS, R.drawable.ic_menu_about, R.string.menu_about_sss));
        menuItems.add(new MenuItem(ACTION_SEND_FEEDBACK, R.drawable.ic_menu_send_feedback, R.string.menu_send_feedback));

        return menuItems;
    }
}
