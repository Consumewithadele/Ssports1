package com.sssports.sssports.ui.widgets.tab;


import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.util.CommonConstants;
import com.sssports.sssports.util.UlTagHandler;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * A simple {@link Fragment} subclass.
 */
public class DetailsFragment extends Fragment {

    @BindView(R.id.tv_details_text)
    TextView tvDetailsText;

    private Product product;

    public DetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_details, container, false);
        ButterKnife.bind(this, view);

        Bundle bundle = this.getArguments();
        if (bundle != null) {
            product = (Product) bundle.getSerializable(CommonConstants.BUNDLE_PRODUCT);
        }

        if (product != null && !TextUtils.isEmpty(product.getDescription())) {

//            String str="<html><body>A dressy take on classic gingham in a soft, textured weave of stripes that resembles twill.  Take a closer look at this one.<ul><li>Trim, tailored fit for a bespoke feel</li><li>Medium spread collar, one-button mitered barrel cuffs</li><li>Applied placket with genuine mother-of-pearl buttons</li><li>;Split back yoke, rear side pleats</li><li>Made in the U.S.A. of 100% imported cotton.</li></ul></body></html>";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                tvDetailsText.setText(Html.fromHtml(Html.fromHtml(product.getDescription()).toString(), Html.FROM_HTML_MODE_COMPACT, null, new UlTagHandler()));
            } else {
                tvDetailsText.setText(Html.fromHtml(product.getDescription(), null, new UlTagHandler()));
//                tvDetailsText.setText(Html.fromHtml(Html.fromHtml(product.getDescription()).toString(), null , new UlTagHandler()));
            }
        }

        return view;
    }

}
