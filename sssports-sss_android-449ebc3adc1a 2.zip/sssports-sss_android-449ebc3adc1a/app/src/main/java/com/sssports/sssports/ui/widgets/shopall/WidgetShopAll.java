package com.sssports.sssports.ui.widgets.shopall;

import android.app.Activity;
import android.content.Intent;
import android.view.View;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.ui.main.MainActivity;
import com.sssports.sssports.ui.widgets.WidgetType;
import com.sssports.sssports.util.CommonConstants;

import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by natalijaratajac on 8/19/17.
 */

public class WidgetShopAll implements WidgetType {

    private Activity activity;
    private Product product;

    public WidgetShopAll(Activity activity, Product product) {
        this.activity = activity;
        this.product = product;
    }

    @Override
    public View buildView() {
        View productDetailsUSPView = activity.getLayoutInflater().inflate(R.layout.widget_type_shop_all, null);
        ButterKnife.bind(this, productDetailsUSPView);

        return productDetailsUSPView;
    }

    @OnClick(R.id.rl_shop_all)
    public void onShopAllClick() {
        Intent intent = new Intent(activity, MainActivity.class);
        intent.putExtra(CommonConstants.INTENT_FRAGMENT_ID, CommonConstants.FragmentId.FRAGMENT_MAIN_CATEGORY);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        activity.startActivity(intent);
//        activity.finish();
    }
}
