package com.sssports.sssports.ui.main.category;

import android.app.Activity;

import com.sssports.sssports.SSSApp;
import com.sssports.sssports.networking.services.SSSApi;

import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by mlukovic on 8/2/17.
 */

public class CategoryFragmentInteractorImpl implements CategoryFragmentMVPContract.Interactor {

    private CategoryFragmentMVPContract.Presenter mFragmentPresenter;
    private SSSApi sssApi;

    public CategoryFragmentInteractorImpl(Activity activity, CategoryFragmentMVPContract.Presenter fragmentPresenter) {
        mFragmentPresenter = fragmentPresenter;
        sssApi = ((SSSApp)activity.getApplication()).getApplicationComponent().sssService();
    }

    @Override
    public void getCategories(String categoryId) {
        sssApi.getCategory(categoryId, "children.children")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        category -> mFragmentPresenter.onCategoryDataReady(category),
                        throwable -> mFragmentPresenter.showError()
                );
    }

    @Override
    public void getWidgets(String categoryId, Integer screenId) {
        sssApi.getWidgets(categoryId, screenId,"blocks.actions,products")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        widgetDocument -> mFragmentPresenter.onWidgetsDataReady(widgetDocument.asArrayDocument()),
                        throwable -> mFragmentPresenter.showError()
                );
    }
}
