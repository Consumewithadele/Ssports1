package com.sssports.sssports.locale;

import android.content.Context;
import android.text.TextUtils;

/**
 * Created by Adeleclark on 8/16/17.
 */

public enum SPDataManager {

    INSTANCE;


    private SharedPreferenceManager sharedPreferenceManager;

    /**
     * Use this method to initialize singleton
     * This method is used in SPDataManager in onCreate() method
     *
     * @param context
     */
    public void initialize(Context context) {
        sharedPreferenceManager = new SharedPreferenceManager(context, SharedPrefConstants.PreferenceName.LOCALE_DATA);
    }

    /**
     * Returns saved language code.
     *
     * @return
     */
    public String getLanguageCode() {
        //TODO Check how to detect the default Language. Now returns English as default
        return sharedPreferenceManager.getString(SharedPrefConstants.Locale.LANGUAGE, LocaleConstants.Language.ENGLISH);
    }

    public void saveLanguage(String languageCode) {
        if (!TextUtils.isEmpty(languageCode)) {
            sharedPreferenceManager.putString(SharedPrefConstants.Locale.LANGUAGE, languageCode);
        }
    }


    public String getCountry() {
        //TODO Check how to detect the default Country. Now returns UAE as default
        return sharedPreferenceManager.getString(SharedPrefConstants.Locale.COUNTRY, LocaleConstants.Country.UAE);
    }

    public void saveCountry(String countryCode) {
        if (!TextUtils.isEmpty(countryCode)) {
            sharedPreferenceManager.putString(SharedPrefConstants.Locale.COUNTRY, countryCode);
        }
    }

    public String getLanguageAndCountry(String divider) {
        if (TextUtils.isEmpty(divider)) {
            divider = "_";
        }

        return getLanguageCode() + divider + getCountry();

    }

    public void saveCurrentCurrency(String currencyCode) {
        sharedPreferenceManager.putString(SharedPrefConstants.PreferenceKeyName.CURRENCY_CODE, currencyCode);
    }

    public String getCurrentCurrency() {
        return sharedPreferenceManager.getString(SharedPrefConstants.PreferenceKeyName.CURRENCY_CODE, LocaleConstants.Currency.UAE);
    }

    public String getProductCartId() {
        return sharedPreferenceManager.getString(getLanguageAndCountry(null) + SharedPrefConstants.PreferenceKeyName.PRODUCT_CART_ID, "");
    }

    public void saveProductCartId(String prodcutCartId) {
        sharedPreferenceManager.putString(getLanguageAndCountry(null) + SharedPrefConstants.PreferenceKeyName.PRODUCT_CART_ID, prodcutCartId);
    }

    public void deleteProductCartId() {
        sharedPreferenceManager.remove(getLanguageAndCountry(null) + SharedPrefConstants.PreferenceKeyName.PRODUCT_CART_ID);
    }

    public void setCheckboxStateSaveShippingAddress(boolean state) {
        sharedPreferenceManager.putBoolean(SharedPrefConstants.PreferenceKeyName.SAVE_SHIPPING_INFO, state);
    }

    public boolean isShippingInfoSaved() {
        return sharedPreferenceManager.getBoolean(SharedPrefConstants.PreferenceKeyName.SAVE_SHIPPING_INFO);
    }

}
