package com.sssports.sssports.ui.widgets.checkoutsummary;

import android.app.Activity;
import android.view.View;
import android.widget.ProgressBar;

import com.sssports.sssports.R;
import com.sssports.sssports.SSSApp;
import com.sssports.sssports.models.magento.TotalSegment;
import com.sssports.sssports.ui.checkoutbilling.builder.OnSummaryReadyListener;
import com.sssports.sssports.ui.customviews.ExpandableHeightListView;
import com.sssports.sssports.ui.widgets.WidgetType;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by mlukovic on 9/1/17.
 */

public class WidgetTypeOrderSummary implements WidgetType, SummaryMvpContract.View, WidgetOrderSummaryListener {

    @BindView(R.id.summary_list_view) ExpandableHeightListView mSummaryListView;
    @BindView(R.id.summary_loader) ProgressBar mSummaryLoader;

    private SummaryMvpContract.Presenter presenter;
    private Activity mActivity;
    OnSummaryReadyListener mOnSummaryReadyListener;

    public WidgetTypeOrderSummary(Activity activity, OnSummaryReadyListener onSummaryReadyListener) {
        mActivity = activity;
        mOnSummaryReadyListener = onSummaryReadyListener;
    }

    @Override
    public View buildView() {
        View view = mActivity.getLayoutInflater().inflate(R.layout.widget_checkout_summary, null);
        ButterKnife.bind(this, view);
        presenter = new OrderSummaryPresenterImpl(((SSSApp)mActivity.getApplication()).getApplicationComponent().magentoService(), this);
        presenter.loadSummary();
        return view;
    }

    @Override
    public void showSummary(List<TotalSegment> totalSegmentList, String baseCurrencyCode) {
        AdapterSummary adapterSummary = new AdapterSummary(mActivity, totalSegmentList, baseCurrencyCode);
        mSummaryListView.setExpanded(true);
        mSummaryListView.setAdapter(adapterSummary);
        if (mOnSummaryReadyListener != null) {
            mOnSummaryReadyListener.onSummaryReady(totalSegmentList);
        }
    }

    @Override
    public void showErrorSummary() {
        //TODO  showErrorSummary()
        mOnSummaryReadyListener.onSummaryError();
    }

    @Override
    public void showLoader(boolean visible) {
        mSummaryLoader.setVisibility(visible ? View.VISIBLE : View.GONE);
        mSummaryListView.setVisibility(!visible ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onRefreshSummaryRequested(OnSummaryReadyListener onSummaryReadyListener) {
        presenter.loadSummary();
        mOnSummaryReadyListener = onSummaryReadyListener;
    }
}
