package com.sssports.sssports;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by Adeleclark on 8/22/17.
 */

@GlideModule
public class SSSAppGlideModule extends AppGlideModule {
}
