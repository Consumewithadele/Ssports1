package com.sssports.sssports.ui.widgets.blog;

/**
 * Contract for implementing MVP pattern for Blog Post Widget
 */

public class WidgetBlogPostContract {

    interface WidgetBlogPostView {

        void showLoader();

        void showError();

        void showTitle(String label);

        void showDescription(String text);

        void hideTitle();

        void hideDescription();

        void hideWidget();

        void showCTA1(String text);

        void hideCTA1();

        void hideCTA2();

        void showCTA2(String text);

        void showVideo();

        void playVideo(String videoUrl);

        void showErrorLoadingContent();

        void openLink(String link);

        void showHeaderImage(String imageUrl);
    }

    interface WidgetBlogPostPresenter {

        void loadData();

        void loadVideo();

        void loadAction(int index);
    }
}
