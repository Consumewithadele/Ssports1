package com.sssports.sssports.ui.splash;

import com.sssports.sssports.di.PerActivity;
import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.networking.services.SSSApi;

import javax.inject.Inject;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Implementation of {@link SplashScreenContract.Presenter} that controls communication between
 * view and model of the presentation layer.
 */

@PerActivity
public class SplashScreenPresenterImpl implements SplashScreenContract.Presenter {

    private final SSSApi sssApi;
    private final SplashScreenContract.View mView;

    @Inject
    SplashScreenPresenterImpl(SSSApi sssApi, SplashScreenContract.View view) {
        this.sssApi = sssApi;
        mView = view;
    }

    @Override
    public void loadData() {
        sssApi.getScreens("home", /*"en_GB",*/ 1, "widgets.blocks.actions,widgets.products")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Screen>() {
                    @Override
                    public void onCompleted() {}

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error getting Screens: " + e.getMessage());
                        mView.showError();
                    }

                    @Override
                    public void onNext(Screen screen) {
                        mView.showHomeScreen(screen);
                    }
                });
    }
}
