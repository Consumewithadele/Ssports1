package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by mlukovic on 8/7/17.
 */
@JsonApi(type = "options")
public class Option extends Resource {

    @Json(name = "option_id")
    private Integer optionId;
    @Json(name = "attribute_id")
    private Integer attributeId;
    @Json(name = "sort_order")
    private Integer sortOrder;
    @Json(name = "label")
    private String label;
    @Json(name = "hex")
    private String hex;
    @Json(name = "hex_url")
    private String hexUrl;
    @Json(name = "product_count")
    private String productCount;

    private String thumbnailImage;

    private boolean selected;

    public Integer getOptionId() {
        return optionId;
    }

    public void setOptionId(Integer optionId) {
        this.optionId = optionId;
    }

    public Integer getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(Integer attributeId) {
        this.attributeId = attributeId;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public boolean isSelected() {
        return selected;
    }

    public String getHex() {
        return hex;
    }

    public void setHex(String hex) {
        this.hex = hex;
    }

    public String getHexUrl() {
        return hexUrl;
    }

    public void setHexUrl(String hesImage) {
        this.hexUrl = hesImage;
    }

    public String getProductCount() {
        return productCount;
    }

    public void setProductCount(String productCount) {
        this.productCount = productCount;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getThumbnailImage() {
        return thumbnailImage;
    }

    public void setThumbnailImage(String thumbnailImage) {
        this.thumbnailImage = thumbnailImage;
    }

    @Override
    public String toString() {
        return String.valueOf(optionId);
    }
}
