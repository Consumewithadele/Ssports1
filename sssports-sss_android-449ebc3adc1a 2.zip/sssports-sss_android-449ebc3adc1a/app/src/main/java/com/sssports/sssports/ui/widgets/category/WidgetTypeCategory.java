package com.sssports.sssports.ui.widgets.category;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Action;
import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.customviews.ExpandableHeightGridView;
import com.sssports.sssports.ui.main.MainActivity;
import com.sssports.sssports.ui.main.MainScreenListener;
import com.sssports.sssports.ui.widgets.WidgetType;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import timber.log.Timber;

/**
 * Main class responsible for building Category Widget layout and functionality
 */

public class WidgetTypeCategory implements WidgetType, CategoryWidgetContract.CategoryWidgetView {

    private Activity mActivity;
    private Widget mWidget;

    @BindView(R.id.grid_view_categories) ExpandableHeightGridView mGridViewCategories;
    @BindView(R.id.text_view_title) TextView mTextViewTitle;
    @BindView(R.id.text_view_description) TextView mTextViewDescription;
    @BindView(R.id.ll_category_widget) LinearLayout mCategoryWidgetLayout;

    public WidgetTypeCategory(Activity activity, Widget widget) {
        mActivity = activity;
        mWidget = widget;
    }

    @Override
    public View buildView() {
        View widgetCategoryView = mActivity.getLayoutInflater().inflate(R.layout.widget_type_category, null);
        ButterKnife.bind(this, widgetCategoryView);

        CategoryWidgetContract.CategoryWidgetPresenter widgetPresenter = new CategoryWidgetPresenterImpl(this, mWidget);
        widgetPresenter.loadData();

        return widgetCategoryView;
    }


    @Override
    public void showLoader() {
        //TODO showLoader WidgetTypeCategory
    }

    @Override
    public void showCategories(List<Block> blockList) {
        mGridViewCategories.setExpanded(true);
        CategoryAdapter categoryAdapter = new CategoryAdapter(blockList, mActivity, position -> {
            if (blockList.get(position).getActionList().get(0) != null) {
                String link = mWidget.getBlockList().get(position).getActionList().get(0).getLink();
                ((BaseActivity)mActivity).getNavigator().openLink(mActivity, link);
            } else {
                Toast.makeText(mActivity, "Action is unavailable", Toast.LENGTH_SHORT).show();
            }
        });
        mGridViewCategories.setAdapter(categoryAdapter);
    }

    @Override
    public void showError() {
        //TODO showError WidgetTypeCategory
//        Toast.makeText(mActivity, "Error showing WidgetTypeCategory", Toast.LENGTH_SHORT).show();
        Timber.d("Error showing WidgetTypeCategory: " + mWidget.getId());
    }

    @Override
    public void showTitle(String label) {
        mTextViewTitle.setText(label);
        mTextViewTitle.setVisibility(View.VISIBLE);
    }

    @Override
    public void showDescription(String text) {
        mTextViewDescription.setText(text);
        mTextViewDescription.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideTitle() {
        mTextViewTitle.setVisibility(View.GONE);
    }

    @Override
    public void hideDescription() {
        mTextViewDescription.setVisibility(View.GONE);
    }

    @Override
    public void hideWidget() {
        mCategoryWidgetLayout.setVisibility(View.GONE);
    }
}
