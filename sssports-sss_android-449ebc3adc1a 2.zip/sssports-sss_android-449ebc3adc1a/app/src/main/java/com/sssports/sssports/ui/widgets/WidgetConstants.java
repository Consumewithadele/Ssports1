package com.sssports.sssports.ui.widgets;

/**
 * Constants for widgets
 */

public class WidgetConstants {

    public class Type {
        public static final String WIDGET_CATEGORY                         = "Category";
        public static final String WIDGET_CATEGORY_WITH_HEADING            = "CategoryWithHeading";
        public static final String WIDGET_HERO                             = "Hero";
        public static final String WIDGET_PRODUCTS_HORIZONTAL_SCROLL       = "ProductScroll";
        public static final String WIDGET_BLOG_POST                        = "BlogPost";
        public static final String WIDGET_SALE_BANNER                      = "SaleBanner";
        public static final String WIDGET_PRODUCTS_VERTICAL_SCROLL         = "ProductScrollVertical";
        public static final String WIDGET_USP_BAR                          = "UspBar";
        public static final String WIDGET_SLIDER_CONTENT                   = "Slider";
        public static final String WIDGET_PROMOTION                        = "ImageBanner";
    }

}
