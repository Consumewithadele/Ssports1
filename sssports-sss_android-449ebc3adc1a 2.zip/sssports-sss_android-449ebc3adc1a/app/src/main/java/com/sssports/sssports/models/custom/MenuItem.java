package com.sssports.sssports.models.custom;

/**
 * Created by mlukovic on 8/15/17.
 */

public class MenuItem {

    private String code;
    private int icon;
    private int label;

    public MenuItem(String code, int icon, int label) {
        this.code = code;
        this.icon = icon;
        this.label = label;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public int getLabel() {
        return label;
    }

    public void setLabel(int label) {
        this.label = label;
    }
}
