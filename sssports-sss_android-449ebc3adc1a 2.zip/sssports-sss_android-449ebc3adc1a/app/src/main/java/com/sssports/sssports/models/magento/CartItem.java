package com.sssports.sssports.models.magento;

import android.os.Parcel;
import android.os.Parcelable;

import com.squareup.moshi.Json;

public class CartItem implements Parcelable {

    public CartItem(String sku, Integer qty, String quoteId) {
        this.sku = sku;
        this.qty = qty;
        this.quoteId = quoteId;
    }

    public CartItem() {
    }

    @Json(name = "item_id")
    private Integer itemId;
    @Json(name = "sku")
    private String sku;
    @Json(name = "qty")
    private Integer qty;
    @Json(name = "name")
    private String name;
    @Json(name = "price")
    private Double price;
    @Json(name = "product_type")
    private String productType;
    @Json(name = "quote_id")
    private String quoteId;
    public final static Parcelable.Creator<CartItem> CREATOR = new Creator<CartItem>() {


        @SuppressWarnings({
                "unchecked"
        })
        public CartItem createFromParcel(Parcel in) {
            CartItem instance = new CartItem();
            instance.itemId = ((Integer) in.readValue((Integer.class.getClassLoader())));
            instance.sku = ((String) in.readValue((String.class.getClassLoader())));
            instance.qty = ((Integer) in.readValue((Integer.class.getClassLoader())));
            instance.name = ((String) in.readValue((String.class.getClassLoader())));
            instance.price = ((Double) in.readValue((Double.class.getClassLoader())));
            instance.productType = ((String) in.readValue((String.class.getClassLoader())));
            instance.quoteId = ((String) in.readValue((String.class.getClassLoader())));
            return instance;
        }

        public CartItem[] newArray(int size) {
            return (new CartItem[size]);
        }

    };

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getQuoteId() {
        return quoteId;
    }

    public void setQuoteId(String quoteId) {
        this.quoteId = quoteId;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(itemId);
        dest.writeValue(sku);
        dest.writeValue(qty);
        dest.writeValue(name);
        dest.writeValue(price);
        dest.writeValue(productType);
        dest.writeValue(quoteId);
    }

    public int describeContents() {
        return 0;
    }


    @Override
    public String toString() {
        return sku;
    }
}