package com.sssports.sssports.models.jsonapi;

import com.sssports.sssports.models.magento.ShippingMethod;

import java.util.List;

/**
 * Created by natalijaratajac on 9/8/17.
 */

public class NewsletterAndShippingMethodsZip {

    private Newsletter newsletterResponse;
    private List<ShippingMethod> shippingMethods;

    public NewsletterAndShippingMethodsZip(Newsletter newsletterResponse, List<ShippingMethod> shippingMethodsResponse) {
        this.newsletterResponse = newsletterResponse;
        shippingMethods = shippingMethodsResponse;
    }

    public List<ShippingMethod> getShippingMethods() {
        return shippingMethods;
    }

    public void setShippingMethods(List<ShippingMethod> shippingMethods) {
        this.shippingMethods = shippingMethods;
    }
}
