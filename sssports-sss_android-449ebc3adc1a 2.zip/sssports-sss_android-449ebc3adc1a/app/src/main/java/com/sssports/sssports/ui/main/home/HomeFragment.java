package com.sssports.sssports.ui.main.home;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.main.MainScreenListener;
import com.sssports.sssports.ui.widgets.WidgetDirector;
import com.sssports.sssports.ui.widgets.WidgetDirectorImp;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by mlukovic on 7/19/17.
 */

public class HomeFragment extends Fragment {

    public static final String ARG_WIDGETS = "home-fragment-arg-screen";

    @BindView(R.id.linear_layout_widget_list_holder) LinearLayout mLinearLayoutWidgetListHolder;
    @BindView(R.id.main_scroll_view) ScrollView mScrollViewMain;

    OnShopButtonClickListener mCallback;
    MainScreenListener mOnTitleChangeListener;

    public static HomeFragment newInstance(Screen screen) {
        final HomeFragment fragment = new HomeFragment();
        final Bundle args = new Bundle();
        args.putSerializable(ARG_WIDGETS, screen);

        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home_page, container, false);
        ButterKnife.bind(this, view);
        Bundle args = getArguments();
        if (args != null) {
            Screen screen = (Screen) args.getSerializable(ARG_WIDGETS);
            if (screen != null) {
                showWidgetList(screen.getWidgets());
            } else {
                showError();
            }
        }

        return view;
    }

    private void showError() {
        Toast.makeText(getContext(), "Unavailable country", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResume() {
        super.onResume();
        //Set title
        mOnTitleChangeListener.showScreenTitle(null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
//        getActivity().setScreenTitle("Menu 1");
    }

    public void showWidgetList(List<Widget> widgets) {
        WidgetDirector widgetDirector = new WidgetDirectorImp(mLinearLayoutWidgetListHolder, widgets, getActivity(), mScrollViewMain);
        widgetDirector.construct();
    }

    @OnClick(R.id.action_button)
    public void onShopButtonClick() {
        if (mCallback != null) mCallback.onShopButtonClicked();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mCallback = (OnShopButtonClickListener) getActivity();
            mOnTitleChangeListener = (MainScreenListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString()
                    + " must implement OnHeadlineSelectedListener");
        }
    }

    public interface OnShopButtonClickListener {
        void onShopButtonClicked();
    }
}
