package com.sssports.sssports.ui.main.plp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.hannesdorfmann.mosby3.mvp.MvpFragment;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.meta.Pricing;
import com.sssports.sssports.networking.NetworkUtils;
import com.sssports.sssports.ui.main.MainScreenListener;
import com.sssports.sssports.ui.pdp.ProductDetailsActivity;
import com.sssports.sssports.util.CommonConstants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.sssports.sssports.ui.main.plp.ProductAdapter.ITEM_TYPE_LOADER;
import static com.sssports.sssports.ui.main.plp.ProductAdapter.ITEM_TYPE_PRODUCT;

/**
 * Created by mlukovic on 8/1/17.
 */

public class PLPFragment extends MvpFragment<PLPMVPContract.View, PLPMVPContract.Presenter> implements PLPMVPContract.View {

    private static final String ARG_CATEGORY = "category-object";
    private static final String ARG_CATEGORY_ID = "category-id";

    @BindView(R.id.product_list_view) RecyclerView mProductListView;
    @BindView(R.id.text_sort_latest) TextView tvSortByLatest;
    @BindView(R.id.text_sort_name) TextView tvSortByName;
    @BindView(R.id.text_sort_price) TextView tvSortByPrice;
    @BindView(R.id.iv_name_sort_icon) ImageView ivNameSortIcon;
    @BindView(R.id.iv_price_sort_icon) ImageView ivPriceSortIcon;
    @BindView(R.id.number_of_results) TextView tvNumberOfResults;
    private ProductAdapter mProductAdapter;
    private String mCategoryId;
    private MainScreenListener mOnTitleChangeListener;
    private Category mCategory;

    public static Fragment newInstance(Object categoryObject) {
        final PLPFragment fragment = new PLPFragment();
        final Bundle args = new Bundle();
        if (categoryObject instanceof Category) {
            args.putSerializable(ARG_CATEGORY, (Category) categoryObject);
        }
        if (categoryObject instanceof String) {
            String categoryId = NetworkUtils.getLastSegmentOfPath((String) categoryObject);
            args.putString(ARG_CATEGORY_ID, categoryId);
        }
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product_listing_page, container, false);
        ButterKnife.bind(this, view);
        initProductList();
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle args = getArguments();
        String categoryId = null;
        Category category = null;
        if (args != null) {
            if (args.getSerializable(ARG_CATEGORY) != null) {
                category = (Category) args.getSerializable(ARG_CATEGORY);
                categoryId = category.getId();
                mCategory = category;
            } else if (args.getSerializable(ARG_CATEGORY_ID) != null) {
                categoryId = args.getString(ARG_CATEGORY_ID);
            }
        }

        if (!TextUtils.isEmpty(categoryId)) {
            presenter.loadProducts(categoryId);
            mCategoryId = categoryId;
        }

        if (category != null) {
            mOnTitleChangeListener.showScreenTitle(category.getName());
            presenter.loadCategories(category.getParentId());
            loadFilterList(category.getId(), null);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception
        try {
            mOnTitleChangeListener = (MainScreenListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }


    @Override
    public void onDetach() {
        mOnTitleChangeListener.disableRightMenu();
        super.onDetach();
    }

    @Override
    public void showError() {
//        Toast.makeText(getContext(), R.string.error_while_loading_content, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showPriceDescending() {
        ivPriceSortIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_arrow_sort_descending));
    }

    @Override
    public void showPriceAscending() {
        ivPriceSortIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_arrow_sort_ascending));
    }

    @Override
    public void showNameDescending() {
        ivNameSortIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_arrow_sort_descending));
    }

    @Override
    public void showNameAscending() {
        ivNameSortIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_arrow_sort_ascending));
    }

    @Override
    public void resetProductList() {
        mProductAdapter.removeAllProducts();
    }

    @Override
    public void showCategoryList(List<Category> categories) {
        mOnTitleChangeListener.showDropDownTitle(categories, categories.indexOf(mCategory));
    }

    @Override
    public void hideSortingCriteria() {
        tvSortByPrice.setTextAppearance(getContext(), R.style.H4Light);
        tvSortByName.setTextAppearance(getContext(), R.style.H4Light);
        tvSortByLatest.setTextAppearance(getContext(), R.style.H4Light);
        ivPriceSortIcon.setVisibility(View.INVISIBLE);
        ivNameSortIcon.setVisibility(View.INVISIBLE);
    }

    @Override
    public void loadFilterList(String category, Pricing pricing) {
        mOnTitleChangeListener.loadFilterList(category, pricing);
    }

    @Override
    public void showNumberOfResults(int number) {
        String numberOfResultString = getResources().getString(R.string.plp_number_of_results, number);
        tvNumberOfResults.setVisibility(View.VISIBLE);
        tvNumberOfResults.setText(numberOfResultString);
    }

    @NonNull
    @Override
    public PLPMVPContract.Presenter createPresenter() {
        return new PLPPresenterImpl(getActivity());
    }

    @Override
    public void showProducts(List<Product> productList) {
        mProductAdapter.addProducts(productList);
    }

    @Override
    public void showLoader(boolean visible) {
        mProductAdapter.showLoader(visible);
    }

    @OnClick(R.id.sorting_by_price)
    public void sortProductsByPrice() {
        presenter.sortByPrice();
        tvSortByPrice.setTextAppearance(getContext(), R.style.H4);
        tvSortByName.setTextAppearance(getContext(), R.style.H4Light);
        tvSortByLatest.setTextAppearance(getContext(), R.style.H4Light);
        ivPriceSortIcon.setVisibility(View.VISIBLE);
        ivNameSortIcon.setVisibility(View.INVISIBLE);
    }

    @OnClick(R.id.ll_sorting_by_name)
    public void sortProductsByName() {
        presenter.sortByName();
        tvSortByName.setTextAppearance(getContext(), R.style.H4);
        tvSortByPrice.setTextAppearance(getContext(), R.style.H4Light);
        tvSortByLatest.setTextAppearance(getContext(), R.style.H4Light);
        ivPriceSortIcon.setVisibility(View.INVISIBLE);
        ivNameSortIcon.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.text_sort_latest)
    public void sortProductsByLatest() {
        presenter.sortByLatest();
        tvSortByLatest.setTextAppearance(getContext(), R.style.H4);
        tvSortByPrice.setTextAppearance(getContext(), R.style.H4Light);
        tvSortByName.setTextAppearance(getContext(), R.style.H4Light);
        ivPriceSortIcon.setVisibility(View.INVISIBLE);
        ivNameSortIcon.setVisibility(View.INVISIBLE);
    }

    @OnClick(R.id.action_button_filter)
    public void filterButtonClick() {
        mOnTitleChangeListener.showFilterList();
    }

    public void initProductList() {
        //init empty list
        List<Product> products = new ArrayList<>();

        int numberOfColumns = getActivity().getResources().getInteger(R.integer.product_grid_view_number_of_columns);

        // set Grid layout in 2 columns
        GridLayoutManager mLayoutManager = new GridLayoutManager(getContext(), numberOfColumns);
        mLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (mProductAdapter.getItemViewType(position)) {
                    case ITEM_TYPE_PRODUCT:
                        return 1;
                    case ITEM_TYPE_LOADER:
                        return numberOfColumns; //show loader in center
                    default:
                        return -1;
                }
            }
        });

        mProductListView.setLayoutManager(mLayoutManager);

        // Load more products if User scroll to the end
        mProductListView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            private int lastVisibleItem;
            private int totalItemCount;

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = mLayoutManager.getItemCount();
                lastVisibleItem = mLayoutManager.findLastVisibleItemPosition();
                if (totalItemCount <= lastVisibleItem + numberOfColumns) {
                    presenter.loadProducts(mCategoryId);
                }
            }
        });

        //Add spacing between product items layout
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getContext(), R.dimen.item_offset);
        mProductListView.addItemDecoration(itemDecoration);

        mProductAdapter = new ProductAdapter(products, productId -> openProductDetailScreen(productId));

        mProductListView.setAdapter(mProductAdapter);
    }

    private void openProductDetailScreen(String productId) {
        Intent intent = new Intent(getActivity(), ProductDetailsActivity.class);
        intent.putExtra(CommonConstants.INTENT_PRODUCT_ID, productId);
        startActivity(intent);
    }

    public void changeCategory(Category category) {
        mCategory = category;
        mCategoryId = category.getId();
        presenter.changeCategory(category.getId());
    }

    public void filterProductList(HashMap<Attribute, List<Option>> filterHashMap) {
        presenter.filterProductList(filterHashMap);
    }
}
