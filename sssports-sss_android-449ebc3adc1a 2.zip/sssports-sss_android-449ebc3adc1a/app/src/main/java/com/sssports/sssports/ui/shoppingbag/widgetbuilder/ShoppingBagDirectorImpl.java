package com.sssports.sssports.ui.shoppingbag.widgetbuilder;

import android.app.Activity;
import android.widget.LinearLayout;

import com.sssports.sssports.ui.checkoutbilling.builder.OnSummaryReadyListener;
import com.sssports.sssports.ui.widgets.contact.WidgetTypeContact;
import com.sssports.sssports.ui.widgets.productdetail.ProductDetailListener;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public class ShoppingBagDirectorImpl implements ShoppingBagDirector {

    private ShoppingBagBuilder productDetailsBuilder;
    private WidgetTypeContact.OnCallClickListener onCallClickListener;

    public ShoppingBagDirectorImpl(LinearLayout linearLayout, Activity activity, WidgetTypeContact.OnCallClickListener onCallClickListener) {
        this.onCallClickListener = onCallClickListener;
        productDetailsBuilder = new ShoppingBagBuilderImpl(linearLayout, activity);
    }

    @Override
    public void construct(OnSummaryReadyListener onSummaryReadyListener) {
        productDetailsBuilder.buildProductDetailsUSP();
        productDetailsBuilder.buildCustomerSupportWidget(onCallClickListener);
        productDetailsBuilder.buildSummaryDetails(onSummaryReadyListener);
    }

    @Override
    public void refreshSummary(OnSummaryReadyListener onSummaryReadyListener) {
        productDetailsBuilder.refreshCheckoutSummary(onSummaryReadyListener);
    }
}
