package com.sssports.sssports.ui.checkoutbilling;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.magento.ShippingMethod;

import java.util.List;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class AdapterShippingMethod extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<ShippingMethod> shippingMethods;
    private OnShippingMethodClick onShippingMethodClick;
    private Activity activity;

    public AdapterShippingMethod(List<ShippingMethod> shippingMethods, Activity activity) {
        this.shippingMethods = shippingMethods;
        this.activity = activity;
    }

    public void setOnShippingMethodClick(final OnShippingMethodClick onShippingMethodClick) {
        this.onShippingMethodClick = onShippingMethodClick;
    }

    class ShippingMethodHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView tvShippingMethodName;
        public ImageView ivRadioButton;
        public RelativeLayout rlShippingMethod;

        public ShippingMethodHolder(View itemView) {
            super(itemView);

            tvShippingMethodName = itemView.findViewById(R.id.tv_shipping_method_name);
            ivRadioButton = itemView.findViewById(R.id.iv_radio_button_shipping_method);
            rlShippingMethod = itemView.findViewById(R.id.rl_shipping_method);

            ivRadioButton.setOnClickListener(this);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (onShippingMethodClick != null && !shippingMethods.get(getAdapterPosition()).isSelected()) {
                onShippingMethodClick.onItemClick(v, getLayoutPosition());
            }
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        View v;

        v = LayoutInflater.from(parent.getContext()).inflate(R.layout.shipping_method_item, parent, false);
        viewHolder = new ShippingMethodHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ShippingMethod shippingMethod = shippingMethods.get(position);
        ShippingMethodHolder shippingMethodHolder = (ShippingMethodHolder) holder;

        String formattedPrice = String.format(
                activity.getResources().getString(R.string.price_formatting),
                shippingMethod.getAmount(),
                SPDataManager.INSTANCE.getCurrentCurrency());

        shippingMethodHolder.tvShippingMethodName.setText(shippingMethod.getCarrierTitle() + " " + activity.getString(R.string.shipping_cost) + " " + formattedPrice);

        if (shippingMethod.isSelected()) {
            shippingMethodHolder.ivRadioButton.setImageResource(R.drawable.ic_radio_active);
        } else {
            shippingMethodHolder.ivRadioButton.setImageResource(R.drawable.ic_radio_default);
        }
    }

    @Override
    public int getItemCount() {
        return shippingMethods.size();
    }

    public interface OnShippingMethodClick {
        void onItemClick(View view, int position);

    }
}
