package com.sssports.sssports.ui.main.plp;

import com.hannesdorfmann.mosby3.mvp.MvpPresenter;
import com.hannesdorfmann.mosby3.mvp.MvpView;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.meta.Meta;
import com.sssports.sssports.models.meta.Pricing;

import java.util.HashMap;
import java.util.List;

import moe.banana.jsonapi2.ArrayDocument;

/**
 * Created by mlukovic on 8/3/17.
 */

public class PLPMVPContract {

    interface View extends MvpView {

        void showProducts(List<Product> productList);

        void showLoader(boolean visible);

        void showError();

        void showPriceDescending();

        void showPriceAscending();

        void showNameDescending();

        void showNameAscending();

        void resetProductList();

        void showCategoryList(List<Category> categories);

        void hideSortingCriteria();

        void loadFilterList(String category, Pricing pricing);

        void showNumberOfResults(int number);
    }

    interface Presenter extends MvpPresenter<View>{

        void loadProducts(String categoryId);

        void onProductListDataReady(ArrayDocument<Product> products, Meta meta);

        void resetPaging();

        void sortByPrice();

        void sortByName();

        void sortByLatest();

        void changeCategory(String categoryId);

        void onCategoryListReady(List<Category> categories);

        void loadCategories(Integer parentId);

        void filterProductList(HashMap<Attribute, List<Option>> filterHashMap);
    }

    interface Interactor {

        void getProducts(String categoryId, int pageNumber, int pageSize, String sortingCriteria,HashMap<Attribute, List<Option>> attributeFilterList);

        void getCategories(String categoryId);
    }
}
