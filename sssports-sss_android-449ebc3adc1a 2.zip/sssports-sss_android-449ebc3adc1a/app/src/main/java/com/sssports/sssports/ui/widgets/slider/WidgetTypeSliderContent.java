package com.sssports.sssports.ui.widgets.slider;

import android.app.Activity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.widgets.WidgetType;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Main class responsible for building Slider Content Widget layout and functionality
 */

public class WidgetTypeSliderContent implements WidgetType {

    private Activity mActivity;
    private Widget mWidget;

    @BindView(R.id.list_slider_content) RecyclerView mSliderContentRecyclerView;

    public WidgetTypeSliderContent(Activity activity, Widget widget){
        mActivity = activity;
        mWidget = widget;
    }

    @Override
    public View buildView() {
        View sliderContentView = mActivity.getLayoutInflater().inflate(R.layout.widget_type_slider_content, null);
        ButterKnife.bind(this, sliderContentView);

        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.HORIZONTAL, false);
        mSliderContentRecyclerView.setLayoutManager(layoutManager);
        mSliderContentRecyclerView.setAdapter(new SliderContentAdapter(mActivity,
                mWidget.getBlockList(),
                link -> ((BaseActivity)mActivity).getNavigator().openLink(mActivity, link))
        );

        return sliderContentView;
    }
}
