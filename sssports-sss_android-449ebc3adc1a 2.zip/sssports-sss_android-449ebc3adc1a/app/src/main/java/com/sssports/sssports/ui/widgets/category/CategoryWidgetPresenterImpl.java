package com.sssports.sssports.ui.widgets.category;

import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.widgets.WidgetConstants;

/**
 * Implementation of Presenter part of MVP for Category Widget
 */

public class CategoryWidgetPresenterImpl implements CategoryWidgetContract.CategoryWidgetPresenter {

    private Widget mWidget;
    private CategoryWidgetContract.CategoryWidgetView mWidgetView;

    public CategoryWidgetPresenterImpl(CategoryWidgetContract.CategoryWidgetView widgetView, Widget widget) {
        mWidget = widget;
        mWidgetView = widgetView;

    }

    @Override
    public void loadData() {
        if (mWidget == null) mWidgetView.showError();

        if (mWidget.getKind().equalsIgnoreCase(WidgetConstants.Type.WIDGET_CATEGORY_WITH_HEADING)) {
            mWidgetView.showTitle(mWidget.getLabel());
            mWidgetView.showDescription(mWidget.getText());
        } else {
            mWidgetView.hideTitle();
            mWidgetView.hideDescription();
        }

        //TODO If the blockList is null, improve to get Block list resource from API endpoint
        if (mWidget.getBlockList().get(0) != null) {
            mWidgetView.showCategories(mWidget.getBlockList());
        } else {
            mWidgetView.hideWidget();
            mWidgetView.showError();
        }

    }
}
