package com.sssports.sssports.ui.widgets.tab;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.ui.widgets.WidgetType;
import com.sssports.sssports.util.CommonConstants;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by natalijaratajac on 8/11/17.
 */

public class WidgetTypeTab implements WidgetType {

    private Activity activity;
    private Product product;

    @BindView(R.id.tl_product_details)
    TabLayout tlProductDetails;
    @BindView(R.id.vp_product_details)
    FrameLayout vpProductDetails;

    public WidgetTypeTab(Activity activity, Product product) {
        this.activity = activity;
        this.product = product;
    }

    @Override
    public View buildView() {
        View productDetailsUSPView = activity.getLayoutInflater().inflate(R.layout.widget_type_tab, null);
        ButterKnife.bind(this, productDetailsUSPView);

        setupTabsAndFragments();

        return productDetailsUSPView;
    }

    private void setupTabsAndFragments() {

        TabLayout.Tab firstTab = tlProductDetails.newTab();
        firstTab.setText(R.string.details);
        tlProductDetails.addTab(firstTab);
        TabLayout.Tab secondTab = tlProductDetails.newTab();
        secondTab.setText(R.string.delivery_and_returns_title);
        tlProductDetails.addTab(secondTab);

        setFragment(0);

        tlProductDetails.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                setFragment(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void setFragment(int position) {
        Fragment fragment = null;
        switch (position) {
            case 0:
                DetailsFragment fragmentDetails = new DetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putSerializable(CommonConstants.BUNDLE_PRODUCT, product);
                fragmentDetails.setArguments(bundle);
                fragment = fragmentDetails;
                break;
            case 1:
                fragment = new DeliveryAndReturnsFragment();
                break;
        }
        FragmentManager fm = ((AppCompatActivity) activity).getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.vp_product_details, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }
}
