package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import moe.banana.jsonapi2.HasMany;
import moe.banana.jsonapi2.HasOne;
import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

import java.io.Serializable;
import java.util.List;

/**
 * Created by mlukovic on 7/24/17.
 */

@JsonApi(type = "blocks")
public class Block extends Resource implements Serializable {

    private final static long serialVersionUID = -1225620556491741879L;

    @Json(name = "widget_id")
    private Integer widgetId;
    @Json(name = "index")
    private Integer index;
    @Json(name = "label")
    private String label;
    @Json(name = "text")
    private String text;
    @Json(name = "video")
    private String video;
    @Json(name = "created_at")
    private String createdAt;
    @Json(name = "updated_at")
    private String updatedAt;
    @Json(name = "image_url")
    private String imageUrl;
    @Json(name = "actions_count")
    private Integer actionsCount;

    //Relationships
    @Json(name = "actions")
    private HasMany<Action> actionList;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Integer getWidgetId() {
        return widgetId;
    }

    public void setWidgetId(Integer widgetId) {
        this.widgetId = widgetId;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getLabel() {
        return label;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Integer getActionsCount() {
        return actionsCount;
    }

    public void setActionsCount(Integer actionsCount) {
        this.actionsCount = actionsCount;
    }

    public void setActionList(HasMany<Action> actionList) {
        this.actionList = actionList;
    }

    public List<Action> getActionList() {
        return actionList.get(getContext());
    }
}
