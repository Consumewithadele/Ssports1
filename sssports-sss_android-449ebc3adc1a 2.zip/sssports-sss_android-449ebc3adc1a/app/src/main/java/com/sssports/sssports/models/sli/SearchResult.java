
package com.sssports.sssports.models.sli;

import java.util.List;
import com.squareup.moshi.Json;

public class SearchResult {

    @Json(name = "status")
    private String status;
    @Json(name = "result_meta")
    private ResultMeta resultMeta;
    @Json(name = "userid")
    private String userid;
    @Json(name = "pages")
    private Pages pages;
    @Json(name = "manual_click_logging")
    private String manualClickLogging;
    @Json(name = "automatic_click_logging")
    private String automaticClickLogging;
    @Json(name = "facets")
    private List<Facet> facets = null;
    @Json(name = "suggestions")
    private List<Suggestion> suggestions = null;
    @Json(name = "merch")
    private Merch merch;
    @Json(name = "results")
    private List<Result> results = null;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ResultMeta getResultMeta() {
        return resultMeta;
    }

    public void setResultMeta(ResultMeta resultMeta) {
        this.resultMeta = resultMeta;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public Pages getPages() {
        return pages;
    }

    public void setPages(Pages pages) {
        this.pages = pages;
    }

    public String getManualClickLogging() {
        return manualClickLogging;
    }

    public void setManualClickLogging(String manualClickLogging) {
        this.manualClickLogging = manualClickLogging;
    }

    public String getAutomaticClickLogging() {
        return automaticClickLogging;
    }

    public void setAutomaticClickLogging(String automaticClickLogging) {
        this.automaticClickLogging = automaticClickLogging;
    }

    public List<Facet> getFacets() {
        return facets;
    }

    public void setFacets(List<Facet> facets) {
        this.facets = facets;
    }

    public List<Suggestion> getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(List<Suggestion> suggestions) {
        this.suggestions = suggestions;
    }

    public Merch getMerch() {
        return merch;
    }

    public void setMerch(Merch merch) {
        this.merch = merch;
    }

    public List<Result> getResults() {
        return results;
    }

    public void setResults(List<Result> results) {
        this.results = results;
    }

}
