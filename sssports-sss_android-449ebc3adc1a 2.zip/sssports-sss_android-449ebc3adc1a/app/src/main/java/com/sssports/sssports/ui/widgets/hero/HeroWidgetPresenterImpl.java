package com.sssports.sssports.ui.widgets.hero;

import com.sssports.sssports.models.jsonapi.Widget;

/**
 * Presenter part implementation of MVP for Hero Widget
 */

public class HeroWidgetPresenterImpl implements HeroWidgetContract.HeroWidgetPresenter {

    private HeroWidgetContract.HeroWidgetView mHeroWidgetView;
    private Widget mWidget;

    public HeroWidgetPresenterImpl(HeroWidgetContract.HeroWidgetView heroWidgetView, Widget widget) {
        mHeroWidgetView = heroWidgetView;
        mWidget = widget;
    }

    @Override
    public void loadData() {
        if (mWidget == null || mWidget.getBlockList() == null) {
            mHeroWidgetView.hideWidget();
            return;
        }

        mHeroWidgetView.showBlockList(mWidget.getBlockList());
    }
}
