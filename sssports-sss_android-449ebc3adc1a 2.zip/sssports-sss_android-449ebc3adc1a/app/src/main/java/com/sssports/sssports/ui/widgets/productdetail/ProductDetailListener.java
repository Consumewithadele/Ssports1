package com.sssports.sssports.ui.widgets.productdetail;

import com.sssports.sssports.models.jsonapi.ProductChild;

/**
 * Created by mlukovic on 8/24/17.
 */

public interface ProductDetailListener {

    void onProductChildSelected(ProductChild productChild);
}
