package com.sssports.sssports.ui.splash;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.ui.BaseActivity;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.zhanghai.android.materialprogressbar.MaterialProgressBar;

public class SplashScreenActivity extends BaseActivity implements SplashScreenContract.View {

    @Inject SplashScreenContract.Presenter splashScreenPresenter;

    @BindView(R.id.progress_bar) MaterialProgressBar materialProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        ButterKnife.bind(this);
        splashScreenPresenter = new SplashScreenPresenterImpl(sssApi, this);
        splashScreenPresenter.loadData();
    }

    @Override
    public void showError() {
        // TODO add real message
        Toast.makeText(getBaseContext(), R.string.error_while_loading_content, Toast.LENGTH_SHORT).show();
        materialProgressBar.setVisibility(View.INVISIBLE);
    }

    @Override
    public void showHomeScreen(Screen screen) {
        finish();
        this.navigator.navigateToHomeScreen(this, screen);
    }
}
