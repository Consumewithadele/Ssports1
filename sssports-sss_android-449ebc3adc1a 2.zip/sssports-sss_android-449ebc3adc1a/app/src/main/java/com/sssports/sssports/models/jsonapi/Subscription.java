package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;
import com.sssports.sssports.models.custom.CardDetails;
import com.sssports.sssports.models.magento.AddressInformation;
import com.sssports.sssports.models.magento.UserDetailsDto;

import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by natalijaratajac on 9/10/17.
 */
@JsonApi(type = "subscriptions")
public class Subscription extends Resource{

    @Json(name = "billing_address")
    private BillingAddress billingAddress;
    private CardDetails card;

    @Json(name = "status")
    private String status;
    @Json(name = "message")
    private String message;
    @Json(name = "subscription_id")
    private String subscriptionId;
    @Json(name = "request_token")
    private String requestToken;
    @Json(name = "currency")
    private String currency;
    @Json(name = "merchant_reference_code")
    private String merchantReferenceCode;
    @Json(name = "account_number")
    private String accountNumber;
    @Json(name = "card_type")
    private String cardType;
    @Json(name = "avs_message")
    private String avsMessage;
    @Json(name = "cvn_message")
    private String cvnMessage;
    @Json(name = "updated_at")
    private String updatedAt;
    @Json(name = "created_at")
    private String createdAt;
    @Json(name = "is_active")
    private Boolean isActive;

    public BillingAddress getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }

    public CardDetails getCard() {
        return card;
    }

    public void setCard(CardDetails card) {
        this.card = card;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(String subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public String getRequestToken() {
        return requestToken;
    }

    public void setRequestToken(String requestToken) {
        this.requestToken = requestToken;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getMerchantReferenceCode() {
        return merchantReferenceCode;
    }

    public void setMerchantReferenceCode(String merchantReferenceCode) {
        this.merchantReferenceCode = merchantReferenceCode;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getAvsMessage() {
        return avsMessage;
    }

    public void setAvsMessage(String avsMessage) {
        this.avsMessage = avsMessage;
    }

    public String getCvnMessage() {
        return cvnMessage;
    }

    public void setCvnMessage(String cvnMessage) {
        this.cvnMessage = cvnMessage;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }
}
