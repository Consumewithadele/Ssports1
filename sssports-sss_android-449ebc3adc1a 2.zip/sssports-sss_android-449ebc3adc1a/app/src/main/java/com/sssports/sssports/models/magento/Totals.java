package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

import java.util.List;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class Totals {

    @Json(name = "grand_total")
    private Double grandTotal;
    @Json(name = "base_grand_total")
    private Double baseGrandTotal;
    @Json(name = "subtotal")
    private Double subTotal;
    @Json(name = "base_subtotal")
    private Double baseSubTotal;
    @Json(name = "discount_amount")
    private double discountAmount;
    @Json(name = "base_discount_amount")
    private double baseDiscountAmount;
    @Json(name = "subtotal_with_discount")
    private double subtotalWithDiscount;
    @Json(name = "base_subtotal_with_discount")
    private double basesubtotalWithDiscount;
    @Json(name = "shipping_amount")
    private double shippintAmount;
    @Json(name = "base_shipping_amount")
    private double baseShippintAmount;
    @Json(name = "shipping_discount_amount")
    private double shippingDiscountAmount;
    @Json(name = "base_shipping_discount_amount")
    private double baseShippingDiscountAmount;
    @Json(name = "tax_amount")
    private double taxAmount;
    @Json(name = "base_tax_amount")
    private double baseTaxAmount;
    @Json(name = "weee_tax_applied_amount")
    private String weeeTaxAppliedAmount;
    @Json(name = "shipping_tax_amount")
    private double shippingTaxAmount;
    @Json(name = "base_shipping_tax_amount")
    private double baseShippingTaxAmount;
    @Json(name = "subtotal_incl_tax")
    private double subtotalInclTax;
    @Json(name = "shipping_incl_tax")
    private double shippingInclTax;
    @Json(name = "base_shipping_incl_tax")
    private double baseShippingInclTax;
    @Json(name = "base_currency_code")
    private String baseCurrencyCode;
    @Json(name = "quote_currency_code")
    private String quoteCurrencyCode;
    @Json(name = "items_qty")
    private int itemsQty;
    @Json(name = "items")
    private List<TotalCartItem> items;
    @Json(name = "total_segments")
    private List<TotalSegment> totalSegments;


    public Double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getBaseGrandTotal() {
        return baseGrandTotal;
    }

    public void setBaseGrandTotal(Double baseGrandTotal) {
        this.baseGrandTotal = baseGrandTotal;
    }

    public Double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(Double subTotal) {
        this.subTotal = subTotal;
    }

    public Double getBaseSubTotal() {
        return baseSubTotal;
    }

    public void setBaseSubTotal(Double baseSubTotal) {
        this.baseSubTotal = baseSubTotal;
    }

    public double getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public double getBaseDiscountAmount() {
        return baseDiscountAmount;
    }

    public void setBaseDiscountAmount(double baseDiscountAmount) {
        this.baseDiscountAmount = baseDiscountAmount;
    }

    public double getSubtotalWithDiscount() {
        return subtotalWithDiscount;
    }

    public void setSubtotalWithDiscount(double subtotalWithDiscount) {
        this.subtotalWithDiscount = subtotalWithDiscount;
    }

    public double getBasesubtotalWithDiscount() {
        return basesubtotalWithDiscount;
    }

    public void setBasesubtotalWithDiscount(double basesubtotalWithDiscount) {
        this.basesubtotalWithDiscount = basesubtotalWithDiscount;
    }

    public double getShippintAmount() {
        return shippintAmount;
    }

    public void setShippintAmount(double shippintAmount) {
        this.shippintAmount = shippintAmount;
    }

    public double getBaseShippintAmount() {
        return baseShippintAmount;
    }

    public void setBaseShippintAmount(double baseShippintAmount) {
        this.baseShippintAmount = baseShippintAmount;
    }

    public double getShippingDiscountAmount() {
        return shippingDiscountAmount;
    }

    public void setShippingDiscountAmount(double shippingDiscountAmount) {
        this.shippingDiscountAmount = shippingDiscountAmount;
    }

    public double getBaseShippingDiscountAmount() {
        return baseShippingDiscountAmount;
    }

    public void setBaseShippingDiscountAmount(double baseShippingDiscountAmount) {
        this.baseShippingDiscountAmount = baseShippingDiscountAmount;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public double getBaseTaxAmount() {
        return baseTaxAmount;
    }

    public void setBaseTaxAmount(double baseTaxAmount) {
        this.baseTaxAmount = baseTaxAmount;
    }

    public String getWeeeTaxAppliedAmount() {
        return weeeTaxAppliedAmount;
    }

    public void setWeeeTaxAppliedAmount(String weeeTaxAppliedAmount) {
        this.weeeTaxAppliedAmount = weeeTaxAppliedAmount;
    }

    public double getShippingTaxAmount() {
        return shippingTaxAmount;
    }

    public void setShippingTaxAmount(double shippingTaxAmount) {
        this.shippingTaxAmount = shippingTaxAmount;
    }

    public double getBaseShippingTaxAmount() {
        return baseShippingTaxAmount;
    }

    public void setBaseShippingTaxAmount(double baseShippingTaxAmount) {
        this.baseShippingTaxAmount = baseShippingTaxAmount;
    }

    public double getSubtotalInclTax() {
        return subtotalInclTax;
    }

    public void setSubtotalInclTax(double subtotalInclTax) {
        this.subtotalInclTax = subtotalInclTax;
    }

    public double getShippingInclTax() {
        return shippingInclTax;
    }

    public void setShippingInclTax(double shippingInclTax) {
        this.shippingInclTax = shippingInclTax;
    }

    public double getBaseShippingInclTax() {
        return baseShippingInclTax;
    }

    public void setBaseShippingInclTax(double baseShippingInclTax) {
        this.baseShippingInclTax = baseShippingInclTax;
    }

    public String getBaseCurrencyCode() {
        return baseCurrencyCode;
    }

    public void setBaseCurrencyCode(String baseCurrencyCode) {
        this.baseCurrencyCode = baseCurrencyCode;
    }

    public String getQuoteCurrencyCode() {
        return quoteCurrencyCode;
    }

    public void setQuoteCurrencyCode(String quoteCurrencyCode) {
        this.quoteCurrencyCode = quoteCurrencyCode;
    }

    public int getItemsQty() {
        return itemsQty;
    }

    public void setItemsQty(int itemsQty) {
        this.itemsQty = itemsQty;
    }

    public List<TotalCartItem> getItems() {
        return items;
    }

    public void setItems(List<TotalCartItem> items) {
        this.items = items;
    }

    public List<TotalSegment> getTotalSegments() {
        return totalSegments;
    }

    public void setTotalSegments(List<TotalSegment> totalSegments) {
        this.totalSegments = totalSegments;
    }
}
