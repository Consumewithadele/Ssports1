package com.sssports.sssports.ui.customviews;

import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;

import com.sssports.sssports.ui.main.MainActivity;

/**
 * Created by mlukovic on 8/16/17.
 */

public class SpinnerListener implements AdapterView.OnItemSelectedListener, View.OnTouchListener {

    boolean userSelect = false;
    private OnSpinnerSelectedListener onSpinnerSelectedListener;

    public SpinnerListener(OnSpinnerSelectedListener onSpinnerSelectedListener) {
        this.onSpinnerSelectedListener = onSpinnerSelectedListener;
    }



    @Override
    public boolean onTouch(View v, MotionEvent event) {
        userSelect = true;
        return false;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        if (userSelect) {
            onSpinnerSelectedListener.onClick(pos);
            userSelect = false;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

}
