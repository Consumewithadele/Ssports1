package com.sssports.sssports.ui.widgets.uspbar;

import android.app.Activity;
import android.view.View;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.ui.widgets.WidgetType;

import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public class WidgetTypeUspBarWithIcons implements WidgetType {

    private Activity activity;

    public WidgetTypeUspBarWithIcons(Activity activity) {
        this.activity = activity;
    }

    @Override
    public View buildView(){
        View productDetailsUSPView = activity.getLayoutInflater().inflate(R.layout.widget_type_usb_bar_with_images, null);
        ButterKnife.bind(this, productDetailsUSPView);

        return productDetailsUSPView;
    }

    @OnClick(R.id.ll_cash_on_delivery)
    public void onCashDeliveryClick() {

    }

    @OnClick(R.id.ll_free_delivery)
    public void onFreeDeliveryClick() {

    }

    @OnClick(R.id.ll_free_returns)
    public void onFreeReturnsClick() {

    }
}
