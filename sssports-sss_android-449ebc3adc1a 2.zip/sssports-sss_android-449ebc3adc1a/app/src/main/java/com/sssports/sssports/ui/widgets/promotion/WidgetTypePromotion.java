package com.sssports.sssports.ui.widgets.promotion;

import android.app.Activity;
import android.os.Build;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.widgets.WidgetType;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by mlukovic on 7/20/17.
 */

public class WidgetTypePromotion implements WidgetType {

    private Activity mActivity;
    private Widget mWidget;
    private Block mBlock;

    @BindView(R.id.text_promotion_title) TextView tvTitle;
    @BindView(R.id.text_promotion_description) TextView tvDescription;
    @BindView(R.id.promotion_widget_image) ImageView ivPromotionImage;
    @BindView(R.id.promotion_cta) Button btnPromotionCTA;

    public WidgetTypePromotion(Activity activity, Widget widget) {
        mActivity = activity;
        mWidget = widget;
    }

    @Override
    public View buildView() {
        if (isWidgetAvailable(mWidget)) {

            View promotionWidget = mActivity.getLayoutInflater().inflate(R.layout.widget_type_promotion, null);
            ButterKnife.bind(this, promotionWidget);

            mBlock = mWidget.getBlockList().get(0);

            tvTitle.setText(mBlock.getLabel());

            String description = mBlock.getText();
            if (TextUtils.isEmpty(description)) {
                tvDescription.setVisibility(View.GONE);
            }
            tvDescription.setVisibility(View.VISIBLE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                tvDescription.setText(Html.fromHtml(description, Html.FROM_HTML_MODE_COMPACT));
            } else {
                tvDescription.setText(Html.fromHtml(description));
            }

            GlideApp.with(mActivity)
                    .load(mBlock.getImageUrl())
                    .transition(withCrossFade())
                    .placeholder(R.drawable.loading_placeholder)
                    .error(R.drawable.loading_placeholder)
                    .into(ivPromotionImage);

            btnPromotionCTA.setText(mBlock.getActionList().get(0).getText());

            return promotionWidget;
        } else {
            return null;
        }
    }

    private boolean isWidgetAvailable(Widget mWidget) {
        return mWidget != null && mWidget.getBlockList() != null
                && mWidget.getBlockList().size() > 0
                && mWidget.getBlockList().get(0) != null
                && !TextUtils.isEmpty(mWidget.getBlockList().get(0).getLabel())
                && !TextUtils.isEmpty(mWidget.getBlockList().get(0).getText())
                && mWidget.getBlockList().get(0).getActionList() != null
                && mWidget.getBlockList().get(0).getActionList().size() > 0
                && mWidget.getBlockList().get(0).getActionList().get(0) != null
                && !TextUtils.isEmpty(mWidget.getBlockList().get(0).getActionList().get(0).getText());
    }

    @OnClick(R.id.promotion_cta)
    public void onShopNowButtonClick() {
        ((BaseActivity) mActivity).getNavigator().openLink(mActivity, mBlock.getActionList().get(0).getLink());
    }
}
