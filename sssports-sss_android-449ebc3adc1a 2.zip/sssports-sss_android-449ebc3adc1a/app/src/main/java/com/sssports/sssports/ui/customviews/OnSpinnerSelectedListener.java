package com.sssports.sssports.ui.customviews;

/**
 * Created by mlukovic on 8/16/17.
 */

public interface OnSpinnerSelectedListener {

    void onClick(int position);
}
