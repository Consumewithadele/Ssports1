package com.sssports.sssports.models.meta;

import android.os.Parcel;
import android.os.Parcelable;

import com.squareup.moshi.Json;

/**
 * Created by mlukovic on 8/11/17.
 */

public class Pricing implements Parcelable {

    @Json(name = "price_from")
    private Float priceFrom;
    @Json(name = "price_to")
    private Float priceTo;

    public Float getPriceFrom() {
        return priceFrom;
    }

    public void setPriceFrom(Float priceFrom) {
        this.priceFrom = priceFrom;
    }

    public Float getPriceTo() {
        return priceTo;
    }

    public void setPriceTo(Float priceTo) {
        this.priceTo = priceTo;
    }


    //Parcelable implementation

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(this.priceFrom);
        dest.writeValue(this.priceTo);
    }

    public Pricing() {
    }

    protected Pricing(Parcel in) {
        this.priceFrom = (Float) in.readValue(Float.class.getClassLoader());
        this.priceTo = (Float) in.readValue(Float.class.getClassLoader());
    }

    public static final Creator<Pricing> CREATOR = new Creator<Pricing>() {
        @Override
        public Pricing createFromParcel(Parcel source) {
            return new Pricing(source);
        }

        @Override
        public Pricing[] newArray(int size) {
            return new Pricing[size];
        }
    };
}
