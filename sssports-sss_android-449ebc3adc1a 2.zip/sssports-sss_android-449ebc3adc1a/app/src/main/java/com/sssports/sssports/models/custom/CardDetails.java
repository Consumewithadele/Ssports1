package com.sssports.sssports.models.custom;

import com.squareup.moshi.Json;

/**
 * Created by natalijaratajac on 8/27/17.
 */

public class CardDetails {

    @Json(name = "account_number")
    private String cardNumber;
    private transient String cardHolder;
    @Json(name = "expiration_month")
    private String expirationMonth;
    @Json(name = "expiration_year")
    private String expirationYear;
    @Json(name = "cv_number")
    private String cvv;
    @Json(name = "type")
    private String type;
    @Json(name = "currency_code")
    private String currencyCode;

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getExpirationMonth() {
        return expirationMonth;
    }

    public void setExpirationMonth(String expirationMonth) {
        this.expirationMonth = expirationMonth;
    }

    public String getExpirationYear() {
        return expirationYear;
    }

    public void setExpirationYear(String expirationYear) {
        this.expirationYear = expirationYear;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }
}
