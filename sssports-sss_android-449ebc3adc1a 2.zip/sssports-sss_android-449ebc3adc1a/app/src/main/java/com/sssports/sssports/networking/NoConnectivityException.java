package com.sssports.sssports.networking;

import java.io.IOException;

/**
 * Created by Adeleclark on 8/28/17.
 */

public class NoConnectivityException extends IOException {

    @Override
    public String getMessage() {
        return "No connectivity exception";
    }

}
