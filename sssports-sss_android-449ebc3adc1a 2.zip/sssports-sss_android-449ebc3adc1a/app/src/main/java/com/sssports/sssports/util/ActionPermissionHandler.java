package com.sssports.sssports.util;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import com.sssports.sssports.R;
import com.sssports.sssports.ui.customviews.CustomDialog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by natalijaratajac on 8/19/17.
 */

public class ActionPermissionHandler {

    public static final int REQUEST_PERMISSION_CALL_ID = 1;
    public static final int REQUEST_PERMISSION_CAMERA_ID = 2;
    public static final int REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE_ID = 3;

    public enum PermissionType {
        REQUEST_PERMISSION_CALL(REQUEST_PERMISSION_CALL_ID),
        REQUEST_PERMISSION_CAMERA(REQUEST_PERMISSION_CAMERA_ID),
        REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE(REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE_ID);

        private int value;

        PermissionType(int value) {
            this.value = value;
        }

        private ArrayList<String> getPermissionList() {
            ArrayList<String> permissionList = new ArrayList<>();
            switch (this) {
                case REQUEST_PERMISSION_CALL: {
                    permissionList.add(Manifest.permission.CALL_PHONE);
                    break;
                }
                case REQUEST_PERMISSION_CAMERA: {
                    permissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                    permissionList.add(Manifest.permission.CAMERA);
                    break;
                }
                case REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE: {
                    permissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                    break;
                }
            }
            return permissionList;
        }

    }


    private PermissionType mPermissionType;
    private Activity mActivity;

    public ActionPermissionHandler(PermissionType permissionType, Activity activity) {
        this.mPermissionType = permissionType;
        mActivity = activity;
    }

    public boolean handlePermissions() {

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            final List<String> permissionsNeeded = new ArrayList<>();
            for (String permission : mPermissionType.getPermissionList()) {
                if (ContextCompat.checkSelfPermission(mActivity, permission) != PackageManager.PERMISSION_GRANTED) {
                    permissionsNeeded.add(permission);
                }
            }

            if (permissionsNeeded.size() > 0) {
                boolean shouldShowRationaleDialog = false;
                for (String permission : permissionsNeeded) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity, permission))
                        shouldShowRationaleDialog = true;
                }

                if (shouldShowRationaleDialog) {
                    int resId = mapResId(mPermissionType);
                    String[] dialogResources = mActivity.getResources().getStringArray(resId);
                    final CustomDialog permissionExplanationDialog = new CustomDialog(mActivity, dialogResources[0], dialogResources[1], dialogResources[2], dialogResources[3]);
                    permissionExplanationDialog.setOnPositiveButtonClickListener(new CustomDialog.OnButtonClickListener() {
                        @Override
                        public void onClick(CustomDialog customDialog) {
                            permissionExplanationDialog.dismiss();
                            ActivityCompat.requestPermissions(mActivity, permissionsNeeded.toArray(new String[permissionsNeeded.size()]), mPermissionType.value);
                        }
                    });
                    permissionExplanationDialog.show();
                } else {
                    ActivityCompat.requestPermissions(mActivity, permissionsNeeded.toArray(new String[permissionsNeeded.size()]), mPermissionType.value);
                }
                return false;
            }
        }

        return true;
    }

    private int mapResId(PermissionType permissionType) {
        int resId = 0;
        switch (permissionType) {
            case REQUEST_PERMISSION_CALL:
                resId = R.array.dialog_call_permission;
                break;
//            case REQUEST_PERMISSION_CAMERA:
//                resId = R.array.dialog_camera_permission;
//                break;
//            case REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE:
//                resId = R.array.dialog_write_external_storage;
//                break;
        }
        return resId;
    }

}
