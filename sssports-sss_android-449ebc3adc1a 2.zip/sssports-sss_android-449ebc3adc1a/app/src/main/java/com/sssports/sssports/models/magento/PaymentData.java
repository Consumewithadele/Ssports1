package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class PaymentData {

    @Json(name = "po_number")
    String poNumber;
    @Json(name = "method")
    String method;
    @Json(name = "additional_data")
    private AdditionalData additionalData;

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public AdditionalData getAdditionalData() {
        return additionalData;
    }

    public void setAdditionalData(AdditionalData additionalData) {
        this.additionalData = additionalData;
    }
}
