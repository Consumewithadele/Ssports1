package com.sssports.sssports.ui.main.search;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.sli.Result;
import com.sssports.sssports.models.sli.Suggestion;

import java.util.List;

import timber.log.Timber;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by mlukovic on 9/3/17.
 */

public class SearchResultsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int ITEM_SUGGESTION = 0;
    private static final int ITEM_RESULT = 1;
    private List<Object> mSearchResults;
    private OnItemClickListener mOnItemClickListener;
    private Context mContext;
    private String mQuery;

    public SearchResultsAdapter(Context context, List<Object> searchResults, String keyWord, OnItemClickListener onItemClickListener) {
        mSearchResults = searchResults;
        mContext = context;
        mQuery = keyWord;
        mOnItemClickListener = onItemClickListener;
    }

    class SuggestionViewHolder extends RecyclerView.ViewHolder {

        TextView suggestionText;

        SuggestionViewHolder(View itemView) {
            super(itemView);
            suggestionText = itemView.findViewById(R.id.suggestion_label);
        }
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage;
        TextView productName;
        TextView productPrice;

        ProductViewHolder(View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.search_product_image);
            productName = itemView.findViewById(R.id.search_product_name);
            productPrice = itemView.findViewById(R.id.search_product_price);
            itemView.setOnClickListener(view -> mOnItemClickListener.onProductClicked((Result) mSearchResults.get(getAdapterPosition())));
        }
    }

    @Override
    public int getItemViewType(int position) {
        Object item = mSearchResults.get(position);
        if (item instanceof Suggestion) {
            return ITEM_SUGGESTION;
        } else if (item instanceof Result) {
            return ITEM_RESULT;
        } else {
            return ITEM_SUGGESTION;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case ITEM_SUGGESTION:
                View suggestionView = LayoutInflater.from(mContext).inflate(R.layout.adapter_search_suggestion_item, parent, false);
                return new SuggestionViewHolder(suggestionView);
            case ITEM_RESULT:
                View productView = LayoutInflater.from(mContext).inflate(R.layout.adapter_search_product_item, parent, false);
                return new ProductViewHolder(productView);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Object listItem = mSearchResults.get(position);
        switch (holder.getItemViewType()) {
            case ITEM_SUGGESTION: {
                Suggestion suggestion = (Suggestion) listItem;
                SuggestionViewHolder suggestionViewHolder = (SuggestionViewHolder) holder;
                if (suggestion != null && !TextUtils.isEmpty(suggestion.getPhrase())) {
                    String suggestionPhrase = suggestion.getPhrase().toLowerCase();
                    if (!TextUtils.isEmpty(mQuery)) {
                        String highlightedSuggestionPhrase = highlightKeywords(mQuery, suggestionPhrase);
                        suggestionViewHolder.suggestionText.setText(Html.fromHtml(highlightedSuggestionPhrase));
                    } else {
                        suggestionViewHolder.suggestionText.setText(suggestionPhrase);
                    }
                    suggestionViewHolder.suggestionText.setOnClickListener(view -> mOnItemClickListener.onSuggestionClicked(suggestionPhrase));
                }
                break;
            }
            case ITEM_RESULT: {
                Result result = (Result) listItem;
                ProductViewHolder productViewHolder = (ProductViewHolder) holder;

                //Set product image
                GlideApp.with(mContext)
                        .load(result.getImageUrl())
                        .transition(withCrossFade())
                        .placeholder(R.drawable.bg)
                        .error(R.drawable.loading_placeholder)
                        .into(productViewHolder.productImage);

                //Set product name (description)
                productViewHolder.productName.setText(result.getName());

                //Set product price
                String formattedPrice = String.format(
                        mContext.getResources().getString(R.string.price_formatting),
                        result.getFinalPrice(),
                        SPDataManager.INSTANCE.getCurrentCurrency());

                productViewHolder.productPrice.setText(formattedPrice);
                break;
            }
        }
    }

    private String highlightKeywords(String query, String suggestionPhrase) {
        String[] keywords = query.split(" ");
        String highlightedPhrase = suggestionPhrase;
        String highlightColor = Integer.toHexString(ContextCompat.getColor(mContext, R.color.dark_grey) & 0x00ffffff);
        for (String keyword : keywords) {
            highlightedPhrase = highlightedPhrase.replaceAll(keyword.toLowerCase(),
                    "<font color='#" + highlightColor + "'>" + keyword.toLowerCase() + "</font>");
        }
        return highlightedPhrase;
    }

    @Override
    public int getItemCount() {
        if (mSearchResults == null) return 0;
        return mSearchResults.size();
    }

    public interface OnItemClickListener {

        void onSuggestionClicked(String suggestion);

        void onProductClicked(Result result);
    }
}
