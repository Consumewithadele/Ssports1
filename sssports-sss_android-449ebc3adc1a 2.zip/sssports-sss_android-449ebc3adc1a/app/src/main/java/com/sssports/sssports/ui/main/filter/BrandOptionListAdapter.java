package com.sssports.sssports.ui.main.filter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Option;

import java.util.Collections;
import java.util.List;

import se.emilsjolander.stickylistheaders.StickyListHeadersAdapter;


public class BrandOptionListAdapter extends BaseAdapter implements StickyListHeadersAdapter {

    private List<Option> brandNameList;
    private BrandOptionListAdapter.OnBrandClickListener onBrandClickListener;
    private LayoutInflater inflater;
    private Context context;

    public BrandOptionListAdapter(Context context, List<Option> brandNameList) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.brandNameList = brandNameList;
    }

    public void addBrandList(List<Option> optionList) {
        Collections.sort(optionList, (option1, option2) -> option1.getLabel().compareToIgnoreCase(option2.getLabel()));
        this.brandNameList = optionList;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (brandNameList == null) return 0;
        return brandNameList.size();
    }

    @Override
    public Object getItem(int position) {
        return brandNameList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BrandOptionListAdapter.ViewHolder holder;
        Option option = brandNameList.get(position);

        if (convertView == null) {
            holder = new BrandOptionListAdapter.ViewHolder();
            convertView = inflater.inflate(R.layout.adapter_brand_item, parent, false);
            holder.text = convertView.findViewById(R.id.tv_brand_name);
            holder.checkImage = convertView.findViewById(R.id.check_image_brand);

            convertView.setTag(holder);
        } else {
            holder = (BrandOptionListAdapter.ViewHolder) convertView.getTag();
        }

        holder.text.setText(option.getLabel());

        if (option.isSelected()) {
            holder.checkImage.setVisibility(View.VISIBLE);
        } else {
            holder.checkImage.setVisibility(View.INVISIBLE);
        }

        convertView.setOnClickListener(v -> {
            boolean isSelected = option.isSelected();
            option.setSelected(!isSelected);
            onBrandClickListener.onBrandClick(brandNameList.get(position));
            notifyDataSetChanged();
        });


        return convertView;
    }

    @Override
    public View getHeaderView(int position, View convertView, ViewGroup parent) {
        BrandOptionListAdapter.HeaderViewHolder holder;
        if (convertView == null) {
            holder = new BrandOptionListAdapter.HeaderViewHolder();
            convertView = inflater.inflate(R.layout.list_item_header, parent, false);
            holder.text = convertView.findViewById(R.id.header_text);
            convertView.setTag(holder);
        } else {
            holder = (BrandOptionListAdapter.HeaderViewHolder) convertView.getTag();
        }
        //set header text as first char in name
        String headerText = "" + brandNameList.get(position).getLabel().toUpperCase().subSequence(0, 1).charAt(0);
        holder.text.setText(headerText);
        return convertView;
    }

    @Override
    public long getHeaderId(int position) {
        //return the first character of the brand name as ID because this is what headers are based upon
        return brandNameList.get(position).getLabel().toUpperCase().subSequence(0, 1).charAt(0);
    }

    public void setOnBrandItemClickListener(BrandOptionListAdapter.OnBrandClickListener onBrandClickListener) {
        this.onBrandClickListener = onBrandClickListener;
    }

    class HeaderViewHolder {
        TextView text;
    }

    class ViewHolder {
        TextView text;
        ImageView checkImage;
    }

    public interface OnBrandClickListener {
        void onBrandClick(Option option);
    }
}

