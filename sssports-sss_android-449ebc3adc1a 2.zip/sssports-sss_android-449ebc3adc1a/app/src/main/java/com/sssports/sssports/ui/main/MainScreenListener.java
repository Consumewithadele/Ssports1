package com.sssports.sssports.ui.main;


import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.meta.Pricing;

import java.util.HashMap;
import java.util.List;

/**
 * Created by mlukovic on 8/1/17.
 */

public interface MainScreenListener {

    void showScreenTitle(String title);

    void showDropDownTitle(List<Category> categoryList, int selectedPosition);

    void loadFilterList(String category, Pricing pricing);

    void closeFilterMenu();

    void showFilterList();

    void filterProductList(HashMap<Attribute, List<Option>> filterHashMap);

    void disableRightMenu();

    void openLink(String link);
}
