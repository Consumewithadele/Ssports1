package com.sssports.sssports.locale;

/**
 * Created by Adeleclark on 8/16/17.
 */

public class SharedPrefConstants {

    public class PreferenceName {
        public static final String LOCALE_DATA = "locale_data";
        public static final String USER_DATA = "user_data";
    }

    public class Locale {
        public static final String LANGUAGE = "language";
        public static final String COUNTRY = "country";
    }

    public class PreferenceKeyName {
        public static final String PINCH_TO_ZOOM = "pinch_to_zoom";
        public static final String USER_DETAILS = "user_details";
        public static final String PRODUCT_CART_ID = "add_to_bag_cart_id";
        public static final String CURRENCY_CODE = "current_currency_code";
        public static final String SAVE_SHIPPING_INFO = "is_shipping_info_saved";
    }
}
