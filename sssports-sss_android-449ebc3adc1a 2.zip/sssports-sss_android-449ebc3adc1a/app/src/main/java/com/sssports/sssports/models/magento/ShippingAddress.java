package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by natalijaratajac on 9/3/17.
 */
public class ShippingAddress {

    @Json(name = "address")
    private UserDetailsDto address;

    public UserDetailsDto getAddress() {
        return address;
    }

    public void setAddress(UserDetailsDto address) {
        this.address = address;
    }
}
