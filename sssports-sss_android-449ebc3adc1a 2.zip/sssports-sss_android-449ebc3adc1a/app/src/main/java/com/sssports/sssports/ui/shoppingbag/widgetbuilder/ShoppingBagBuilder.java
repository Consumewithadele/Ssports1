package com.sssports.sssports.ui.shoppingbag.widgetbuilder;

import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.ui.checkoutbilling.builder.OnSummaryReadyListener;
import com.sssports.sssports.ui.widgets.contact.WidgetTypeContact;
import com.sssports.sssports.ui.widgets.productdetail.ProductDetailListener;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public interface ShoppingBagBuilder {

    void buildCustomerSupportWidget(WidgetTypeContact.OnCallClickListener onCallClickListener);

    void buildProductDetailsUSP();

    void buildSummaryDetails(OnSummaryReadyListener onSummaryReadyListener);

    void refreshCheckoutSummary(OnSummaryReadyListener onSummaryReadyListener);
}
