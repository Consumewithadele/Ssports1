package com.sssports.sssports.ui.main.filter;

import android.app.Activity;
import android.text.TextUtils;

import com.hannesdorfmann.mosby3.mvp.MvpBasePresenter;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.meta.Pricing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import timber.log.Timber;

/**
 * Created by mlukovic on 8/7/17.
 */

public class FilterListPresenterImpl extends MvpBasePresenter<FilterMVPContract.View> implements FilterMVPContract.Presenter {

    private static final String FILTER_PRICE = "price_filter";
    public static final String FILTER_PRICE_TO = "price_to";
    public static final String FILTER_PRICE_FROM = "price_from";
    public static final String ATTRIBUTE_BRAND = "brands_filter";

    private FilterMVPContract.Interactor interactor;
    private List<Attribute> mListAttributes;
    private Attribute mCurrentAttribute;
    private List<Option> mCurrentOptionList = new ArrayList<>();
    private HashMap<Attribute, List<Option>> mFilterOptionHashMap = new HashMap<>();
    private Pricing mPricing;
    private float minSelectedPriceValue;
    private float maxSelectedPriceValue;

    public FilterListPresenterImpl(Activity activity) {
        interactor = new FilterListInteractorImpl(activity, this);
    }

    @Override
    public void loadFilterList(String categoryId) {
        if (categoryId == null || TextUtils.isEmpty(categoryId)) {
            getView().showError();
            return;
        }
        interactor.getFilterList(categoryId);
        getView().showLoader(true);
    }

    @Override
    public void onFilterListDataReady(List<Attribute> attributeList) {
        if (isViewAttached()) {
            //Pricing attribute is not part of response, so price range needs to be added manually
            if (mPricing != null && mPricing.getPriceFrom() != null && mPricing.getPriceTo() != null) {
                Attribute priceAttribute = new Attribute();
                priceAttribute.setAttributeCode(FILTER_PRICE);
                priceAttribute.setPricing(mPricing);
                priceAttribute.setLabel(getView().getPriceLabel());
                attributeList.add(priceAttribute);
            }
            getView().showFilterList(attributeList);
            mListAttributes = attributeList;
            getView().showLoader(false);
        }
    }

    @Override
    public void onGettingFilterListError(Throwable throwable) {
        Timber.d(throwable.getMessage());
    }

    @Override
    public void onAttributeItemClick(Attribute attribute) {
        getView().showTitle(attribute.getLabel());

        mCurrentAttribute = attribute;

        if (mFilterOptionHashMap.containsKey(mCurrentAttribute)) {
            mCurrentOptionList = mFilterOptionHashMap.get(mCurrentAttribute);
        } else {
            mCurrentOptionList = new ArrayList<>();
        }




        if (attribute.getAttributeCode().equalsIgnoreCase(FILTER_PRICE)) {
            getView().showPriceRange(attribute.getPricing());
            getView().showClearButton(false);
        } else if (attribute.getAttributeCode().equalsIgnoreCase(ATTRIBUTE_BRAND)){
            getView().showBrandList(attribute.getOptionList());
        } else {
            getView().showOptionList(attribute);
        }
    }

    @Override
    public void onBackFilterClick() {
        if (isViewAttached()) {
            getView().showFilterList(mListAttributes);
            getView().showCloseButton();
            getView().showClearButton(true);
        }
    }

    @Override
    public void onOptionClick(Option option) {
        if (mCurrentOptionList.contains(option)) {
            mCurrentOptionList.remove(option);
        } else {
            mCurrentOptionList.add(option);
        }
    }

    @Override
    public void onApplyFilterClick() {
        if (mCurrentAttribute.getAttributeCode().equalsIgnoreCase(FILTER_PRICE)) {
            setPriceFilters();
        } else {
            mFilterOptionHashMap.put(mCurrentAttribute, mCurrentOptionList);
        }
        getView().applyFilter(mFilterOptionHashMap);
        onBackFilterClick();
    }


    @Override
    public void clearAllOptions() {
        for (Option option : mCurrentAttribute.getOptionList()) {
            option.setSelected(false);
        }
        mFilterOptionHashMap.remove(mCurrentAttribute);
        onAttributeItemClick(mCurrentAttribute);
    }

    @Override
    public void clearAllAttributes() {
        for (Attribute attribute : mListAttributes) {
            if (attribute.getOptionList() != null){
                for (Option option : attribute.getOptionList()) {
                    option.setSelected(false);
                }
            }
        }
        getView().resetPriceRange(mPricing);
        mFilterOptionHashMap.clear();
        getView().applyFilter(mFilterOptionHashMap);
        getView().showFilterList(mListAttributes);
    }

    @Override
    public void setPriceRange(Pricing pricing) {
        mPricing = pricing;
    }


    //filter[price_from]=100&filter[price_to]=160
    private void setPriceFilters() {
        //Set max price filter
        Attribute maxPriceAttribute = new Attribute();
        maxPriceAttribute.setId("maxPrice1");
        maxPriceAttribute.setAttributeCode(FILTER_PRICE_TO);
        Option maxPriceOption = new Option();
        maxPriceOption.setId(String.valueOf(maxSelectedPriceValue));
        List<Option> maxOptionList = new ArrayList<>();
        maxOptionList.add(maxPriceOption);
        mFilterOptionHashMap.put(maxPriceAttribute, maxOptionList);

        //Set min price filter
        Attribute minPriceAttribute = new Attribute();
        minPriceAttribute.setId("minPrice1");
        minPriceAttribute.setAttributeCode(FILTER_PRICE_FROM);
        Option minPriceOption = new Option();
        minPriceOption.setId(String.valueOf(minSelectedPriceValue));
        List<Option> minOptionList = new ArrayList<>();
        minOptionList.add(minPriceOption);
        mFilterOptionHashMap.put(minPriceAttribute, minOptionList);

    }

    @Override
    public void setMinMaxPriceValue(Number minValue, Number maxValue) {
        if (minValue != null && maxValue != null) {
            minSelectedPriceValue = minValue.floatValue();
            maxSelectedPriceValue = maxValue.floatValue();

        }

    }

    @Override
    public void onCancelButtonClick() {
//        clearAllOptions();
        //TODO remove all current
        onBackFilterClick();
    }


}
