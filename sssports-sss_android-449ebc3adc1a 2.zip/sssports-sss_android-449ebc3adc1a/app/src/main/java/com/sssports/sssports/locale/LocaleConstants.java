package com.sssports.sssports.locale;

/**
 * Created by Adeleclark
 on 8/16/17.
 */

public class LocaleConstants {

    public class Language {
        public static final String ENGLISH = "en";
        public static final String ARABIC = "ar";
    }

    public class Country {
        public static final String UAE = "AE";
        public static final String SAUDI_ARABIA = "SA";
        public static final String QATAR = "QA";
        public static final String KUWAIT = "KW";
        public static final String OMAN = "OM";
        public static final String BAHRAIN = "BH";
        public static final String INTERNATIONAL = "int";
        public static final String DEFAULT = "default";
    }

    public class Currency {
        public static final String UAE = "AED";
        public static final String SAUDI_ARABIA = "SAR";
        public static final String QATAR = "QAR";
        public static final String KUWAIT = "KWD";
        public static final String INTERNATIONAL = "USD";
    }
}
