package com.sssports.sssports.models.custom;

import com.sssports.sssports.models.jsonapi.*;
import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.magento.PaymentMethodsAndTotals;

import java.util.List;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class PaymentMethodsAndTotalsAndCoutriesWithRegionsZip {

    private PaymentMethodsAndTotals paymentMethodsAndTotals;
    private List<com.sssports.sssports.models.jsonapi.Country> countries;

    public PaymentMethodsAndTotalsAndCoutriesWithRegionsZip(PaymentMethodsAndTotals paymentMethodsAndTotals, List<Country> countries) {
        this.paymentMethodsAndTotals = paymentMethodsAndTotals;
        this.countries = countries;
    }

    public PaymentMethodsAndTotals getPaymentMethodsAndTotals() {
        return paymentMethodsAndTotals;
    }

    public void setPaymentMethodsAndTotals(PaymentMethodsAndTotals paymentMethodsAndTotals) {
        this.paymentMethodsAndTotals = paymentMethodsAndTotals;
    }

    public List<Country> getCountries() {
        return countries;
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }
}
