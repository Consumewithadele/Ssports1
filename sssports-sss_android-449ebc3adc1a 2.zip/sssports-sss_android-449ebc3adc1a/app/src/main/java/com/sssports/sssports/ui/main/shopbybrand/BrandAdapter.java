package com.sssports.sssports.ui.main.shopbybrand;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Brand;

import java.util.List;

import se.emilsjolander.stickylistheaders.StickyListHeadersAdapter;

/**
 * Created by natalijaratajac on 7/30/17.
 */

public class BrandAdapter extends BaseAdapter implements StickyListHeadersAdapter {

    private List<Brand> brandNameList;
    private OnBrandClickListener onBrandClickListener;
    private LayoutInflater inflater;
    private Context context;

    public BrandAdapter(Context context, List<Brand> brandNameList) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.brandNameList = brandNameList;
    }

    @Override
    public int getCount() {
        return brandNameList.size();
    }

    @Override
    public Object getItem(int position) {
        return brandNameList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.adapter_brand_item, parent, false);
            holder.text = convertView.findViewById(R.id.tv_brand_name);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.text.setText(brandNameList.get(position).getName());

        convertView.setOnClickListener(v -> onBrandClickListener.onBrandClick(v, position));

        return convertView;
    }

    @Override
    public View getHeaderView(int position, View convertView, ViewGroup parent) {
        HeaderViewHolder holder;
        if (convertView == null) {
            holder = new HeaderViewHolder();
            convertView = inflater.inflate(R.layout.list_item_header, parent, false);
            holder.text = convertView.findViewById(R.id.header_text);
            convertView.setTag(holder);
        } else {
            holder = (HeaderViewHolder) convertView.getTag();
        }
        //set header text as first char in name
        String headerText = "" + brandNameList.get(position).getName().toUpperCase().subSequence(0, 1).charAt(0);
        holder.text.setText(headerText);
        return convertView;
    }

    @Override
    public long getHeaderId(int position) {
        //return the first character of the brand name as ID because this is what headers are based upon
        return brandNameList.get(position).getName().toUpperCase().subSequence(0, 1).charAt(0);
    }

    public void setOnInsuranceCompanyClickListener(OnBrandClickListener onBrandClickListener) {
        this.onBrandClickListener = onBrandClickListener;
    }

    class HeaderViewHolder {
        TextView text;
    }

    class ViewHolder {
        TextView text;
    }

    public interface OnBrandClickListener {
        void onBrandClick(View view, int position);
    }
}
