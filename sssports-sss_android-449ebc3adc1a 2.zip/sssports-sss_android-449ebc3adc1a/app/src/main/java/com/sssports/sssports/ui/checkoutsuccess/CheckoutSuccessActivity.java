package com.sssports.sssports.ui.checkoutsuccess;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.main.MainActivity;
import com.sssports.sssports.util.CommonConstants;

import butterknife.BindView;
import butterknife.ButterKnife;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;

/**
 * Created by mlukovic on 9/6/17.
 */

public class CheckoutSuccessActivity extends BaseActivity implements SuccessMvpContract.View {

    @BindView(R.id.ll_thank_you) LinearLayout llThankYou;
    @BindView(R.id.thank_you_loader) ProgressBar progressBarLoader;
    @BindView(R.id.text_view_order_number) TextView tvOrderNumer;

    private SuccessMvpContract.Presenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_thank_you);
        ButterKnife.bind(this);

        String orderId = getIntent().getStringExtra(CommonConstants.INTENT_ORDER_ID);

        presenter = new CheckoutSuccessPresenterImpl(this, magentoApi);
        presenter.loadOrderDetails(orderId);
    }

    public static Intent getCallingIntent(Context context, String orderId) {
        Intent intent = new Intent(context, CheckoutSuccessActivity.class);
        intent.putExtra(CommonConstants.INTENT_ORDER_ID, orderId);
        return intent;
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    public void showThankYouMessageWithOrderNumber(String order) {
        llThankYou.setVisibility(View.VISIBLE);
        String orderTextMessage = String.format(getResources().getString(R.string.your_order_number_is), order);
        orderTextMessage = highlightTheOrderNumber(orderTextMessage, order);
        tvOrderNumer.setText(Html.fromHtml(orderTextMessage));
    }

    private String highlightTheOrderNumber(String orderTextMessage, String incrementId) {
        String highlightColor = Integer.toHexString(ContextCompat.getColor(this, R.color.meat_brown) & 0x00ffffff);
        return orderTextMessage.replaceAll(incrementId.toLowerCase(),
                "<font color='#" + highlightColor + "'>" + incrementId.toLowerCase() + "</font>");

    }

    @Override
    public void showThankYouWithoutOrderNumber() {
        llThankYou.setVisibility(View.VISIBLE);
        tvOrderNumer.setVisibility(View.GONE);
    }

    @Override
    public void showLoader(boolean visible) {
        progressBarLoader.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    @Override
    public void hideThankYouText() {
        llThankYou.setVisibility(View.GONE);
    }
}
