package com.sssports.sssports.di.modules;

import android.content.Context;

import com.readystatesoftware.chuck.ChuckInterceptor;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.sssports.sssports.BuildConfig;
import com.sssports.sssports.locale.LocaleConstants;
import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.jsonapi.Action;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Config;
import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.jsonapi.DataField;
import com.sssports.sssports.models.jsonapi.Gallery;
import com.sssports.sssports.models.jsonapi.Brand;
import com.sssports.sssports.models.jsonapi.Image;
import com.sssports.sssports.models.jsonapi.Newsletter;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Order;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.ProductCategory;
import com.sssports.sssports.models.jsonapi.ProductChild;
import com.sssports.sssports.models.jsonapi.ProductImage;
import com.sssports.sssports.models.jsonapi.Region;
import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.models.jsonapi.Selection;
import com.sssports.sssports.models.jsonapi.Subscription;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.networking.ConnectivityInterceptor;
import com.sssports.sssports.networking.JsonApiConverterFactory;
import com.sssports.sssports.networking.services.MagentoApi;
import com.sssports.sssports.networking.services.SSSApi;
import com.sssports.sssports.networking.services.SSSApiNotJson;
import com.sssports.sssports.networking.services.SliApi;

import java.util.concurrent.TimeUnit;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import moe.banana.jsonapi2.ResourceAdapterFactory;
import okhttp3.Cache;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.moshi.MoshiConverterFactory;

/**
 * Main Networking Module for Application
 */

@Module
public class NetModule {

    private static final String SSS_API_BASE_URL = BuildConfig.SSS_API_BASE_URL;
    private static final String MAGENTO_API_BASE_URL = BuildConfig.MAGENTO_API_BASE_URL;
    private static final String SLI_API_BASE_URL = BuildConfig.SLI_API_BASE_URL;

    @Provides
    @Singleton
    Cache provideHttpCache(Context context) {
        int cacheSize = 10 * 1024 * 1024;
        return new Cache(context.getCacheDir(), cacheSize);
    }

    @Provides
    @Singleton
    JsonAdapter.Factory provideJsonApiAdapterFactory() {
        return ResourceAdapterFactory.builder()
                .add(Widget.class)
                .add(Screen.class)
                .add(Block.class)
                .add(Image.class)
                .add(Action.class)
                .add(Product.class)
                .add(ProductCategory.class)
                .add(Gallery.class)
                .add(Category.class)
                .add(Brand.class)
                .add(Attribute.class)
                .add(Option.class)
                .add(ProductImage.class)
                .add(Selection.class)
                .add(ProductChild.class)
                .add(Country.class)
                .add(Region.class)
                .add(Config.class)
                .add(DataField.class)
                .add(Newsletter.class)
                .add(Subscription.class)
                .add(Order.class)
                // ... Every Resource of JSON API standard object needs to be declared here
                .build();
    }

    @Provides
    @Singleton
    Moshi provideMoshi(JsonAdapter.Factory jsonApiAdapterFactory) {

        return new Moshi.Builder()
                .add(jsonApiAdapterFactory)
                .build();
    }

    @Provides
    @Singleton
    HttpLoggingInterceptor provideHttpLoggingInterceptor() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        return interceptor;
    }

    @Provides
    @Singleton
    ChuckInterceptor provideChuckInterceptor(Context context) {
        return new ChuckInterceptor(context);
    }

    @Provides
    @Singleton
    Interceptor provideLocaleParamInterceptor() {

        return chain -> {
            Request original = chain.request();
            HttpUrl originalHttpUrl = original.url();

            String language = SPDataManager.INSTANCE.getLanguageCode();
            String country = SPDataManager.INSTANCE.getCountry();
            String locale;

            if (country.equalsIgnoreCase(LocaleConstants.Country.INTERNATIONAL)) {
                locale = LocaleConstants.Country.INTERNATIONAL;
            } else {
                locale = language + "_" + country;
            }

            HttpUrl url = originalHttpUrl.newBuilder()
                    .addQueryParameter(SSSApi.FILTER_LOCALE, locale)
                    .build();

            Request.Builder requestBuilder = original.newBuilder().url(url);
            Request request = requestBuilder.build();
            return chain.proceed(request);
        };
    }

    @Provides
    @Singleton
    @Named("baseLocaleInterceptor")
    Interceptor provideBaseLocalePlaceholderInterceptor() {

        return chain -> {
            Request original = chain.request();
            HttpUrl originalHttpUrl = original.url();

            String baseUrl = originalHttpUrl.host();

            String language = SPDataManager.INSTANCE.getLanguageCode();
            String country = SPDataManager.INSTANCE.getCountry();
            String locale = "";

            if (!country.equalsIgnoreCase(LocaleConstants.Country.INTERNATIONAL)) {
                locale = language + "-" + country;
            }

            baseUrl = baseUrl.replace("{locale}", locale);

            HttpUrl url = originalHttpUrl.newBuilder().host(baseUrl)
                    .build();

            Request.Builder requestBuilder = original.newBuilder().url(url);
            Request request = requestBuilder.build();
            return chain.proceed(request);
        };
    }

    @Provides
    @Singleton
    @Named("baseLocaleSliInterceptor")
    Interceptor provideSliInterceptor() {

        return chain -> {
            Request original = chain.request();
            HttpUrl originalHttpUrl = original.url();

            String baseUrl = originalHttpUrl.host();
            String currentLang = SPDataManager.INSTANCE.getLanguageCode();

            switch (currentLang) {
                case LocaleConstants.Language.ARABIC:
                    baseUrl = baseUrl.replace("{language}", "-" + currentLang);
                    break;
                default:
                    baseUrl = baseUrl.replace("{language}", "");
            }

            HttpUrl url = originalHttpUrl.newBuilder().host(baseUrl).build();

            Request.Builder requestBuilder = original.newBuilder().url(url);
            Request request = requestBuilder.build();
            return chain.proceed(request);
        };
    }

    @Provides
    @Singleton
    ConnectivityInterceptor provideConnectivityInterceptor(Context context) {
        return new ConnectivityInterceptor(context);
    }

    @Provides
    @Singleton
    @Named("okHttpLocale")
    OkHttpClient provideOkHttpClientWithLocale(
            Cache cache,
            HttpLoggingInterceptor httpLoggingInterceptor,
            ChuckInterceptor chuckInterceptor,
            Interceptor localeParamInterceptor,
            ConnectivityInterceptor connectivityInterceptor) {

        OkHttpClient.Builder client = new OkHttpClient.Builder();
        if (BuildConfig.DEBUG) {
            client.addInterceptor(httpLoggingInterceptor);
            client.addInterceptor(chuckInterceptor);
        }
        client.addInterceptor(localeParamInterceptor);
        client.addInterceptor(connectivityInterceptor);
//        client.cache(cache);
        client.connectTimeout(60, TimeUnit.SECONDS);
        client.writeTimeout(60, TimeUnit.SECONDS);
        client.readTimeout(60, TimeUnit.SECONDS);
        return client.build();
    }

    @Provides
    @Singleton
    @Named("okHttp")
    OkHttpClient provideOkHttpClient(
            Cache cache,
            HttpLoggingInterceptor httpLoggingInterceptor,
            ChuckInterceptor chuckInterceptor,
            ConnectivityInterceptor connectivityInterceptor,
            Interceptor localeInterceptor) {

        OkHttpClient.Builder client = new OkHttpClient.Builder();
        if (BuildConfig.DEBUG) {
            client.addInterceptor(httpLoggingInterceptor);
            client.addInterceptor(chuckInterceptor);
        }
        client.addInterceptor(connectivityInterceptor);
        client.addInterceptor(localeInterceptor);
//        client.cache(cache);
        client.connectTimeout(60, TimeUnit.SECONDS);
        client.writeTimeout(60, TimeUnit.SECONDS);
        client.readTimeout(60, TimeUnit.SECONDS);
        return client.build();
    }

    @Provides
    @Singleton
    @Named("okHttpSli")
    OkHttpClient provideOkHttpSliClient(
            Cache cache,
            HttpLoggingInterceptor httpLoggingInterceptor,
            ChuckInterceptor chuckInterceptor,
            ConnectivityInterceptor connectivityInterceptor,
            @Named("baseLocaleSliInterceptor") Interceptor localeInterceptor) {

        OkHttpClient.Builder client = new OkHttpClient.Builder();
        if (BuildConfig.DEBUG) {
            client.addInterceptor(httpLoggingInterceptor);
            client.addInterceptor(chuckInterceptor);
        }
        client.addInterceptor(connectivityInterceptor);
        client.addInterceptor(localeInterceptor);
//        client.cache(cache);
        client.connectTimeout(60, TimeUnit.SECONDS);
        client.writeTimeout(60, TimeUnit.SECONDS);
        client.readTimeout(60, TimeUnit.SECONDS);
        return client.build();
    }

    @Provides
    @Singleton
    @Named("okHttpBaseLocale")
    OkHttpClient provideOkHttpClientWithBaseLocale(
            Cache cache,
            HttpLoggingInterceptor httpLoggingInterceptor,
            ChuckInterceptor chuckInterceptor,
            ConnectivityInterceptor connectivityInterceptor,
            @Named("baseLocaleInterceptor") Interceptor localeInterceptor) {

        OkHttpClient.Builder client = new OkHttpClient.Builder();
        if (BuildConfig.DEBUG) {
            client.addInterceptor(httpLoggingInterceptor);
            client.addInterceptor(chuckInterceptor);
        }
        client.addInterceptor(connectivityInterceptor);
        client.addInterceptor(localeInterceptor);
//        client.cache(cache);
        client.connectTimeout(60, TimeUnit.SECONDS);
        client.writeTimeout(60, TimeUnit.SECONDS);
        client.readTimeout(60, TimeUnit.SECONDS);
        return client.build();
    }

    @Provides
    @Singleton
    @Named("sssRetrofit")
    Retrofit provideRetrofitSSSApi(Moshi moshi, @Named("okHttpLocale") OkHttpClient okHttpClient) {
        return new Retrofit.Builder()
                .addConverterFactory(JsonApiConverterFactory.create(moshi))
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .baseUrl(SSS_API_BASE_URL)
                .client(okHttpClient)
                .build();
    }

    @Provides
    @Singleton
    @Named("sssRetrofitNotJsonApi")
    Retrofit provideNotJsonRetrofitSSSApi(Moshi moshi, @Named("okHttpLocale") OkHttpClient okHttpClient) {
        return new Retrofit.Builder()
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .baseUrl(SSS_API_BASE_URL)
                .client(okHttpClient)
                .build();
    }

    @Provides
    @Singleton
    @Named("magentoRetrofit")
    Retrofit provideRetrofit(Moshi moshi, @Named("okHttpBaseLocale") OkHttpClient okHttpClient) {
        return new Retrofit.Builder()
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .baseUrl(MAGENTO_API_BASE_URL)
                .client(okHttpClient)
                .build();
    }

    @Provides
    @Singleton
    @Named("sliRetrofit")
    Retrofit provideSliRetrofit(Moshi moshi, @Named("okHttpSli") OkHttpClient okHttpClient) {
        return new Retrofit.Builder()
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .baseUrl(SLI_API_BASE_URL)
                .client(okHttpClient)
                .build();
    }

    @Provides
    @Singleton
    SSSApi apiService(@Named("sssRetrofit") Retrofit retrofit) {
        return retrofit.create(SSSApi.class);
    }

    @Provides
    @Singleton
    SSSApiNotJson apiServiceNotJson(@Named("sssRetrofitNotJsonApi") Retrofit retrofit) {
        return retrofit.create(SSSApiNotJson.class);
    }

    @Provides
    @Singleton
    MagentoApi magentoApi(@Named("magentoRetrofit") Retrofit retrofit) {
        return retrofit.create(MagentoApi.class);
    }

    @Provides
    @Singleton
    SliApi sliApi(@Named("sliRetrofit") Retrofit retrofit) {
        return retrofit.create(SliApi.class);
    }
}
