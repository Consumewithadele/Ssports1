package com.sssports.sssports.util;

import android.app.Activity;
import android.util.Log;

import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.jsonapi.Region;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by natalijaratajac on 9/12/17.
 */

public class ReadFromJsonFIle {


    private static String loadJSONFromAsset(String fileName, Activity activity) {
        String json = null;
        try {
            InputStream is = activity.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public static ArrayList<Country> getCountriesFromJsonFile(String fileName, Activity activity) {

        ArrayList<Country> countryList = new ArrayList<>();
        try {
            String  jsonString = loadJSONFromAsset(fileName, activity);
            JSONArray jsonArray = new JSONArray(jsonString);
            Country country;

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jo_inside = jsonArray.getJSONObject(i);
                String name_value = jo_inside.getString("name");
                String code_value = jo_inside.getString("code");

                //Add your values in your `ArrayList` as below:
                country = new Country(code_value);
                country.setName(name_value);

                countryList.add(country);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return countryList;
    }

    public static ArrayList<Region> getRegionListFromJson(String fileName, Activity activity) {

        ArrayList<Region> regionArrayList = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(loadJSONFromAsset(fileName, activity));
            Region region;

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jo_inside = jsonArray.getJSONObject(i);
                String region_value = jo_inside.getString("region");
                String country_value = jo_inside.getString("country");

                //Add your values in your `ArrayList` as below:
                region = new Region();
                region.setName(region_value);
                region.setCountryId(country_value);

                regionArrayList.add(region);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return regionArrayList;
    }
}
