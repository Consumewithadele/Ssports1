package com.sssports.sssports.networking.services;

import com.sssports.sssports.models.custom.Token;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.models.jsonapi.Brand;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.jsonapi.Newsletter;
import com.sssports.sssports.models.jsonapi.Order;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.models.jsonapi.Subscription;
import com.sssports.sssports.models.jsonapi.Widget;

import java.util.Map;

import moe.banana.jsonapi2.Document;
import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;
import rx.Observable;

/**
 * Created by mlukovic on 7/23/17.
 */

public interface SSSApi {

    String FILTER_CATEGORY_ID = "filter[category_id]";
    String FILTER_LOCALE = "filter[locale]";
    String PAGE_NUMBER = "page[number]";
    String PAGE_SIZE = "page[size]";
    String SORT = "sort";

    @GET("/v1/screens")
    Observable<Screen> getScreens(@Query("filter[kind]") String filterKind,
                                  @Query("filter[first]") int filterFirst,
                                  @Query("include") String include);

    @GET("/v1/blocks")
    Observable<Document<Block>> getBlocks(@Query("filter[widget_id]") String widgetId,
                                          @Query("page[number]") int pageNumber,
                                          @Query("page[size]") int pageSize,
                                          @Query("include") String include);

    @GET("/v1/categories/{categoryId}")
    Observable<Category> getCategory(@Path("categoryId") String categoryId,
                                     @Query("include") String include);

    @GET("/v1/widgets")
    Observable<Document<Widget>> getWidgets(@Query("filter[category_id]") String categoryId,
                                            @Query("filter[screen_id]") int screenId,
                                            @Query("include") String include);

    @GET("/v1/brands")
    Observable<Document<Brand>> getBrands();

    @GET("/v1/widgets/{widget_id}/products/")
    Observable<Document<Product>> getProducts(@Path("widget_id") String widgetId,
                                              @Query("page[number]") int pageNumber,
                                              @Query("page[size]") int pageSize);

    @GET("/v1/products/")
    Observable<Document<Product>> getProductsByCategory(@QueryMap Map<String, String> attributeFilters);

    @GET("/v1/products/{id}")
    Observable<Product> getProductDetails(
            @Path("id") String id,
            @Query("include") String include);

    @GET("/v1/products/")
    Observable<Document<Product>> getProductListDetailsBySku(@Query("filter[sku]") String skuList, @Query("include") String include);

    @GET("/v1/widgets")
    Observable<Document<Widget>> getRelatedProductsAndWidgets(
            @Query("filter[screen_id]") String screenId,
            @Query("filter[product_id]") String productId,
            @Query("include") String include);

    @GET("/v1/screens")
    Observable<Screen> getScreenIdForRelatedProductsAndWidgets(
            @Query("filter[kind]") String kind,
            @Query("filter[first]") int first);

    @GET("/v1/attributes")
    Observable<Document<Attribute>> getFilterAttributes(@Query(FILTER_CATEGORY_ID) String categoryId,
                                                        @Query("include") String include);

    @GET("/v1/countries")
    Observable<Document<Country>> getCountriesAndRegions(@Query("include") String include);

    @POST("/v1/newsletter")
    Observable<Newsletter> subscribeToNewsletter(@Body Newsletter newsletter);

    @POST("/v1/payments/subscriptions")
    Observable<Subscription> createSubscription(@Header("Authorization") String authorization, @Body Subscription subscription);

    @POST("/v1/orders")
    Observable<Order> placeOrder(@Body Order order, @Header("Authorization") String authorization);
}
