package com.sssports.sssports.ui.widgets.productverticalscroll;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.sssports.sssports.SSSApp;
import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.meta.Meta;
import com.sssports.sssports.models.meta.Page;
import com.sssports.sssports.networking.services.SSSApi;
import com.sssports.sssports.ui.BaseActivity;

import javax.inject.Inject;

import moe.banana.jsonapi2.Document;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Interactor for Product Vertical Scroll List Widget
 */

public class ProductVerticalInteractorImpl implements ProductVerticalContract.ProductVerticalInteractor {

    @Inject
    protected SSSApi sssApi;

    private ProductVerticalContract.ProductVerticalPresenter mProductVerticalPresenter;

    public ProductVerticalInteractorImpl(ProductVerticalContract.ProductVerticalPresenter productVerticalPresenter, BaseActivity activity) {
        mProductVerticalPresenter = productVerticalPresenter;
        sssApi = ((SSSApp)activity.getApplication()).getApplicationComponent().sssService();
    }

    @Override
    public void getProductListData(String widgetId, int pageNumber, int pageSize) {

        sssApi.getProducts(widgetId, pageNumber, pageSize)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Document<Product>>() {
                    @Override
                    public void onCompleted() {}

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error getting blockssssssssssssssssssssssss");
                    }

                    @Override
                    public void onNext(Document<Product> productDocument) {

                        Moshi moshi = new Moshi.Builder().build();
                        JsonAdapter<Meta> pageJsonAdapter = moshi.adapter(Meta.class);
                        Meta metaData = (Meta) productDocument.getMeta().get(pageJsonAdapter);

                        mProductVerticalPresenter.onProductListDataReady(productDocument.asArrayDocument(), metaData.getPage());
                    }
                });
    }
}
