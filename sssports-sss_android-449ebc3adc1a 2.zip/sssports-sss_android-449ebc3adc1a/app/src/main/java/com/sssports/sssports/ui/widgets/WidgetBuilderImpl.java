package com.sssports.sssports.ui.widgets;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.widgets.blog.WidgetTypeBlogPost;
import com.sssports.sssports.ui.widgets.category.WidgetTypeCategory;
import com.sssports.sssports.ui.widgets.hero.WidgetTypeHero;
import com.sssports.sssports.ui.widgets.producthorizontalscroll.WidgetTypeProductHorizontalScroll;
import com.sssports.sssports.ui.widgets.productverticalscroll.WidgetTypeProductVerticalScroll;
import com.sssports.sssports.ui.widgets.promotion.WidgetTypePromotion;
import com.sssports.sssports.ui.widgets.salebanner.WidgetTypeSaleBanner;
import com.sssports.sssports.ui.widgets.slider.WidgetTypeSliderContent;
import com.sssports.sssports.ui.widgets.uspbar.WidgetTypeUspBar;

/**
 * Implementation of the {@link WidgetBuilder} which can build all Widget Views and import in
 * the Layout holder
 */

public class WidgetBuilderImpl implements WidgetBuilder {

    private LinearLayout mListOfWidgetsLayout;
    private Activity mActivity;

    /**
     * Constructor of the Widget Builder
     *
     * @param layout   Layout in which widget will be inflated
     * @param activity Activity holder
     */
    public WidgetBuilderImpl(LinearLayout layout, Activity activity) {
        mListOfWidgetsLayout = layout;
        mActivity = activity;
    }

    /**
     * Builds Category type of the Widget
     *
     * @param widget A widget that will be build
     */
    @Override
    public void buildCategoryWidget(Widget widget) {
        WidgetTypeCategory widgetTypeCategory = new WidgetTypeCategory(mActivity, widget);
        View view = widgetTypeCategory.buildView();
        mListOfWidgetsLayout.addView(view);
    }

    /**
     * Builds USP Bar type of the Widget
     */
    @Override
    public void buildUspBarWidget() {
        WidgetTypeUspBar widgetTypeUspBar = new WidgetTypeUspBar(mActivity);
        View view = widgetTypeUspBar.buildView();
        mListOfWidgetsLayout.addView(view);
    }

    /**
     * Builds Hero type of the Widget
     *
     * @param widget Widget that should be build
     * @param autoScrollEnabled If it's enabled it will start auto scroll of the widget and vice verse
     */
    @Override
    public void buildHeroWidget(Widget widget, boolean autoScrollEnabled) {
        WidgetTypeHero widgetTypeHero = new WidgetTypeHero(mActivity, widget, autoScrollEnabled);
        View view = widgetTypeHero.buildView();
        mListOfWidgetsLayout.addView(view);
    }

    /**
     * Builds Products Horizontal Widget view
     *
     * @param widget Widget that should be build
     */
    @Override
    public void buildProductsHorizontalScrollWidget(Widget widget) {
        WidgetTypeProductHorizontalScroll widgetProductsHorizontalScroll = new WidgetTypeProductHorizontalScroll(mActivity, widget);
        View view = widgetProductsHorizontalScroll.buildView();
        mListOfWidgetsLayout.addView(view);
    }

    /**
     * Builds Blog Post Widget view
     *
     * @param widget Widget Widget that should be build
     */
    @Override
    public void buildBlogPostWidget(Widget widget) {
        WidgetTypeBlogPost widgetTypeBlogPost = new WidgetTypeBlogPost(mActivity, widget);
        View view = widgetTypeBlogPost.buildView();
        mListOfWidgetsLayout.addView(view);
    }

    /**
     * Builds Sale Banner Widget view
     * @param widget Sale Banner widget
     */
    @Override
    public void buildSaleBannerWidget(Widget widget) {
        WidgetType widgetTypeSaleBanner = new WidgetTypeSaleBanner(mActivity, widget);
        View view = widgetTypeSaleBanner.buildView();
        mListOfWidgetsLayout.addView(view);
    }

    /**
     * Builds Product Vertical Scroll Widget View
     * @param widget Widget to be displayed
     */
    @Override
    public void buildProductVerticalScrollWidget(Widget widget, ScrollView scrollView) {
        WidgetType widgetTypeProduct = new WidgetTypeProductVerticalScroll(mActivity, widget, scrollView);
        View view = widgetTypeProduct.buildView();
        mListOfWidgetsLayout.addView(view);
    }

    /**
     * Builds Slider Content Widget view
     * @param widget Widget to be displayed
     */
    @Override
    public void buildSliderContentWidget(Widget widget) {
        WidgetTypeSliderContent widgetTypeSliderContent = new WidgetTypeSliderContent(mActivity, widget);
        View view = widgetTypeSliderContent.buildView();
        mListOfWidgetsLayout.addView(view);
    }

    /**
     * Builds Promotion Widget view
     * @param widget Widget to be displayed
     */
    @Override
    public void buildPromotionWidget(Widget widget) {
        WidgetTypePromotion widgetTypePromotion = new WidgetTypePromotion(mActivity, widget);
        View view = widgetTypePromotion.buildView();
        mListOfWidgetsLayout.addView(view);
    }
}
