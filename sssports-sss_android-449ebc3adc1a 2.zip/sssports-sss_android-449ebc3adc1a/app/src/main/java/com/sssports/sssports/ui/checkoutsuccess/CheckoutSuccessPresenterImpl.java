package com.sssports.sssports.ui.checkoutsuccess;

import com.sssports.sssports.networking.NetworkConstants;
import com.sssports.sssports.networking.services.MagentoApi;

import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by mlukovic on 9/6/17.
 */

public class CheckoutSuccessPresenterImpl implements SuccessMvpContract.Presenter {

    private MagentoApi magentoApi;
    private SuccessMvpContract.View view;

    public CheckoutSuccessPresenterImpl(SuccessMvpContract.View view, MagentoApi magentoApi) {
        this.view = view;
        this.magentoApi = magentoApi;
    }

    @Override
    public void loadOrderDetails(String orderId) {
        view.showThankYouMessageWithOrderNumber(orderId);
//        view.showLoader(true);
//        view.hideThankYouText();
//        magentoApi.getOrderDetails(NetworkConstants.MAGENTO_AUTH, orderId)
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .unsubscribeOn(Schedulers.io())
//                .subscribe(
//                        orderResponse -> {
//                            view.showLoader(false);
//                            if (orderResponse.isSuccessful()) {
//                                view.showThankYouMessageWithOrderNumber(orderResponse.body());
//                            } else {
//                                view.showThankYouWithoutOrderNumber();
//                            }
//                        },
//                        throwable -> {
//                            view.showThankYouWithoutOrderNumber();
//                            view.showLoader(false);
//                        });
    }
}
