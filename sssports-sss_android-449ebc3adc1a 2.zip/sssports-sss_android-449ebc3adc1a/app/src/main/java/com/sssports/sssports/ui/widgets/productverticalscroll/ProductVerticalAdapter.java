package com.sssports.sssports.ui.widgets.productverticalscroll;

import android.animation.Animator;
import android.content.Context;
import android.graphics.Paint;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;

import java.util.List;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by mlukovic on 7/3/17.
 */

public class ProductVerticalAdapter extends BaseAdapter {

    private List<Product> mBlockList;
    private Context mContext;
    private ProductClickListener mProductClickListener;

    public ProductVerticalAdapter(Context context, List<Product> productList, ProductClickListener productClickListener) {
        mBlockList = productList;
        mContext = context;
        mProductClickListener = productClickListener;
    }

    @Override
    public int getCount() {
        if (mBlockList == null) return 0;
        return mBlockList.size();
    }

    @Override
    public Object getItem(int i) {
        return mBlockList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        convertView = inflater.inflate(R.layout.adapter_sale_product, parent, false);

        ImageView imageViewProduct = convertView.findViewById(R.id.image_view_product);
        TextView tvProductName = convertView.findViewById(R.id.text_view_product_name);
        TextView textViewColors = convertView.findViewById(R.id.text_view_num_colors);
        TextView tvPrice = convertView.findViewById(R.id.old_price);
        TextView tvNewPrice = convertView.findViewById(R.id.new_price);
        LottieAnimationView wishListAnimation = convertView.findViewById(R.id.icon_wish_list_anim);
        ImageView ivWishListIcon = convertView.findViewById(R.id.icon_wish_list);
        LinearLayout linearLayout = convertView.findViewById(R.id.ll_product);
        TextView badgeText = convertView.findViewById(R.id.sale_text);

        Product product = mBlockList.get(position);

        GlideApp.with(mContext)
                .load(product.getThumbnailUrl())
                .transition(withCrossFade())
                .placeholder(R.drawable.loading_placeholder)
                .error(R.drawable.loading_placeholder)
                .into(imageViewProduct);


        tvProductName.setText(product.getName());

        String numberOfColorsLabel = mContext.getResources().getQuantityString(R.plurals.number_of_colors, product.getColorCount(), product.getColorCount());
        textViewColors.setText(numberOfColorsLabel);
        tvPrice.setText(product.getFormattedPrice());

        if (product.isOnSale()) {
            if (!TextUtils.isEmpty(product.getFormattedFinalPrice())) {
                tvNewPrice.setText(product.getFormattedFinalPrice());
                tvNewPrice.setVisibility(View.VISIBLE);
            } else {
                tvNewPrice.setVisibility(View.INVISIBLE);
            }
//            badgeText.setVisibility(View.VISIBLE);
            tvPrice.setPaintFlags(tvPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
//            badgeText.setVisibility(View.GONE);
            tvNewPrice.setVisibility(View.GONE);
            tvPrice.setPaintFlags(tvPrice.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
        }

        if (!TextUtils.isEmpty(product.getBadgeBar())) {
            badgeText.setVisibility(View.VISIBLE);
            badgeText.setText(product.getBadgeBar());
        } else {
            badgeText.setVisibility(View.GONE);
        }

        if (product.isInWishList()) {
            ivWishListIcon.setSelected(true);
        } else {
            ivWishListIcon.setSelected(false);
        }

        wishListAnimation.addAnimatorListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation, boolean isReverse) {
            }

            @Override
            public void onAnimationEnd(Animator animation, boolean isReverse) {
                wishListAnimation.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationStart(Animator animator) {
            }

            @Override
            public void onAnimationEnd(Animator animator) {
                wishListAnimation.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationCancel(Animator animator) {
            }

            @Override
            public void onAnimationRepeat(Animator animator) {
            }
        });

        ivWishListIcon.setOnClickListener(view -> {

            if (product.isInWishList()) {
                ivWishListIcon.setSelected(false);
            } else {
                wishListAnimation.setVisibility(View.VISIBLE);
                wishListAnimation.playAnimation();
                ivWishListIcon.setSelected(true);
            }
            product.setInWishList(!product.isInWishList());
        });

        linearLayout.setOnClickListener(view -> mProductClickListener.onClick(product.getAppLink()));

        return convertView;
    }

    public void addProducts(List<Product> blockList) {
        mBlockList.addAll(blockList);
        notifyDataSetChanged();
    }

    public interface ProductClickListener {
        void onClick(String link);
    }
}
