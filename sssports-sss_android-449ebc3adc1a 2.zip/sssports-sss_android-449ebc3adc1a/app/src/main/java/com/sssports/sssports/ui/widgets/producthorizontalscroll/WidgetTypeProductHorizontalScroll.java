package com.sssports.sssports.ui.widgets.producthorizontalscroll;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.duolingo.open.rtlviewpager.RtlViewPager;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.main.MainScreenListener;
import com.sssports.sssports.ui.widgets.WidgetType;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.relex.circleindicator.CircleIndicator;

/**
 * Main class responsible for building Product Horizontal Scroll Widget layout and functionality
 */

public class WidgetTypeProductHorizontalScroll implements WidgetType {

    private Activity mActivity;
    private Widget mWidget;

    @BindView(R.id.view_pager_horizontal_products) RtlViewPager viewPagerHorizontalProducts;
    @BindView(R.id.indicator_horizontal_products) CircleIndicator circleIndicator;
    @BindView(R.id.text_view_product_horizontal_widget_title) TextView mWidgetTitle;
    @BindView(R.id.text_view_product_horizontal_widget_description) TextView mWidgetDescriptionText;

    public WidgetTypeProductHorizontalScroll(Activity activity, Widget widget) {
        mActivity = activity;
        mWidget = widget;
    }

    @Override
    public View buildView() {
        View widgetHorizontalProductsView = mActivity.getLayoutInflater().inflate(R.layout.widget_type_product_horizontal_scroll, null);
        ButterKnife.bind(this, widgetHorizontalProductsView);

        // Set title
        if (mWidget != null && !TextUtils.isEmpty(mWidget.getLabel())) {
            mWidgetTitle.setText(mWidget.getLabel());
        } else {
            mWidgetTitle.setVisibility(View.GONE);
        }

        // Set description
        if (mWidget != null && !TextUtils.isEmpty(mWidget.getText())) {
            mWidgetDescriptionText.setText(mWidget.getText());
        } else {
            mWidgetDescriptionText.setVisibility(View.GONE);
        }

        ProductAdapter adapter = new ProductAdapter(mActivity,
                mWidget.getProductList(),
                link -> ((BaseActivity)mActivity).getNavigator().openLink(mActivity, link));
        viewPagerHorizontalProducts.setAdapter(adapter);
        circleIndicator.setViewPager(viewPagerHorizontalProducts);

        return widgetHorizontalProductsView;
    }
}
