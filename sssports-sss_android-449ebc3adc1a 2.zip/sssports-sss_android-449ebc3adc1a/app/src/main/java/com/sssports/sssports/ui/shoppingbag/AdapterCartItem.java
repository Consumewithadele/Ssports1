package com.sssports.sssports.ui.shoppingbag;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.custom.CartItemViewModel;
import com.sssports.sssports.models.magento.CartItem;

import java.util.List;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by mlukovic on 8/26/17.
 */

public class AdapterCartItem extends BaseAdapter {

    private Context mContext;
    private List<CartItemViewModel> mCartItemList;
    private CartItemListener mCartItemListener;
    private boolean isClickable;

    public AdapterCartItem(Context context, List<CartItemViewModel> cartItemList) {
        mCartItemList = cartItemList;
        mContext = context;
    }

    public void addCartItemListener(CartItemListener cartItemListener) {
        mCartItemListener = cartItemListener;
    }

    @Override
    public int getCount() {
        if (mCartItemList == null) return 0;
        return mCartItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return mCartItemList.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder = null;

        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.adapter_product_cart_item, parent, false);

            viewHolder = new ViewHolder();

            viewHolder.productQuantity = convertView.findViewById(R.id.tv_quantity);
            viewHolder.productName = convertView.findViewById(R.id.product_title);
            viewHolder.productImage = convertView.findViewById(R.id.product_image);
            viewHolder.productPrice = convertView.findViewById(R.id.price);
            viewHolder.productColour = convertView.findViewById(R.id.tv_colour);
            viewHolder.productSize = convertView.findViewById(R.id.tv_size);
            viewHolder.btnRemoveOneItem = convertView.findViewById(R.id.btn_remove_one_item);
            viewHolder.btnAddItem = convertView.findViewById(R.id.btn_add_one_item);
            viewHolder.tvRemove = convertView.findViewById(R.id.tv_remove);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        CartItemViewModel cartItem = mCartItemList.get(position);

        GlideApp.with(mContext)
                .load(cartItem.getThumbnailUrl())
                .transition(withCrossFade())
                .placeholder(R.drawable.bg)
                .error(R.drawable.loading_placeholder)
                .into(viewHolder.productImage);

        viewHolder.productPrice.setText(cartItem.getFormattedFinalPrice());
        viewHolder.productColour.setText(cartItem.getColor());
        viewHolder.productQuantity.setText(cartItem.getQuantity().toString());
        viewHolder.productName.setText(cartItem.getName());

        // Disable removing one item if quantity is 1
        viewHolder.btnRemoveOneItem.setSelected(cartItem.getQuantity() != 1);
        viewHolder.btnAddItem.setSelected(cartItem.getQuantity() < cartItem.getAvailableQuantity());

        ViewHolder finalViewHolder = viewHolder;
        viewHolder.btnRemoveOneItem.setOnClickListener(view -> {
            if (!isClickable) return;
            if (finalViewHolder.btnRemoveOneItem.isSelected()) {
                finalViewHolder.productQuantity.setText(String.valueOf(cartItem.getQuantity() - 1));
                if (mCartItemListener != null) {
                    mCartItemListener.onRemoveOneItemClick(cartItem);
                }
                notifyDataSetChanged();
            } else {
                if (mCartItemListener != null) {
                    mCartItemListener.unableToRemoveItemEvent();
                }
            }
        });
        viewHolder.btnAddItem.setOnClickListener(view -> {
            if (!isClickable) return;
            if (finalViewHolder.btnAddItem.isSelected()) {
                finalViewHolder.productQuantity.setText(String.valueOf(cartItem.getQuantity() + 1));
                notifyDataSetChanged();
                if (mCartItemListener != null) {
                    mCartItemListener.onAddOneItemClick(new CartItem(cartItem.getSku(), 1, cartItem.getQuoteId()));
                }
            } else {
                if (mCartItemListener != null) {
                    mCartItemListener.unableToAddItemEvent(cartItem.getName());
                }
            }
        });

        viewHolder.tvRemove.setOnClickListener(view -> {
            if (!isClickable) return;
            if (mCartItemListener != null) {
                mCartItemListener.removeItemFromCart(cartItem);
            }

        });

        viewHolder.productSize.setText(cartItem.getSize());
        return convertView;
    }

    public void addItem(CartItemViewModel cartItemViewModel) {
        mCartItemList.add(cartItemViewModel);
        notifyDataSetChanged();
    }

    public void removeCartItem(CartItemViewModel cartItem) {
        mCartItemList.remove(cartItem);
        notifyDataSetChanged();
    }

    public void setClickable(boolean clickable) {
        this.isClickable = clickable;
    }

    public void updateCartItemQuantity(CartItem cartItem) {
        for (CartItemViewModel cartItemViewModel : mCartItemList) {
            if (cartItem.getSku().equalsIgnoreCase(cartItemViewModel.getSku())) {
                cartItemViewModel.setQuantity(cartItemViewModel.getQuantity() + 1);
            }
        }
        notifyDataSetChanged();
    }

    public void onOneItemRemoved(CartItem cartItem) {
        for (CartItemViewModel cartItemViewModel : mCartItemList) {
            if (cartItem.getSku().equalsIgnoreCase(cartItemViewModel.getSku())) {
                cartItemViewModel.setQuantity(cartItemViewModel.getQuantity() - 1);
            }
        }
        notifyDataSetChanged();
    }

    class ViewHolder {
        TextView productName;
        ImageView productImage;
        TextView productPrice;
        TextView productColour;
        TextView productSize;
        TextView productQuantity;
        ImageButton btnRemoveOneItem;
        ImageButton btnAddItem;
        TextView tvRemove;
    }

    interface CartItemListener {

        void onRemoveOneItemClick(CartItemViewModel cartItem);

        void onAddOneItemClick(CartItem cartItem);

        void unableToAddItemEvent(String name);

        void unableToRemoveItemEvent();

        void removeItemFromCart(CartItemViewModel cartItem);
    }
}
