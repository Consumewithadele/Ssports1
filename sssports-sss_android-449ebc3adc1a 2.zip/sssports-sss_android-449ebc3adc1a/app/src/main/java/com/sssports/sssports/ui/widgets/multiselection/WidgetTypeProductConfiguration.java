package com.sssports.sssports.ui.widgets.multiselection;

import android.app.Activity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.Selection;
import com.sssports.sssports.ui.widgets.WidgetType;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by natalijaratajac on 8/9/17.
 */

public class WidgetTypeProductConfiguration implements WidgetType {

    @BindView(R.id.rv_colour_products) RecyclerView rvColourProducts;
    @BindView(R.id.tv_product_code) TextView tvProductCode;

    private Activity mActivity;
    private Product product;
    private LinearLayoutManager layoutManager;

    public WidgetTypeProductConfiguration(Activity activity, Product product) {
        this.mActivity = activity;
        this.product = product;
    }

    @Override
    public View buildView() {
        View widgetColourwayView = mActivity.getLayoutInflater().inflate(R.layout.widget_type_colourway, null);
        ButterKnife.bind(this, widgetColourwayView);

        layoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.HORIZONTAL, false);
        rvColourProducts.setLayoutManager(layoutManager);

        List<Option> colourOptions = new ArrayList<>();
        for (Selection selections : product.getSelections()) {
            if (selections.getLabel().equalsIgnoreCase("Colour"))
                colourOptions = selections.getOptions();
        }
        String productCode = mActivity.getResources().getString(R.string.product_code, product.getSku());
        tvProductCode.setText(productCode);

//        ColourwayAdapter adapter = new ColourwayAdapter(mActivity, colourOptions);
//        rvColourProducts.setAdapter(adapter);
//        adapter.setOnColourClickListener(id -> Toast.makeText(mActivity, id, Toast.LENGTH_SHORT).show());

        return widgetColourwayView;
    }
}
