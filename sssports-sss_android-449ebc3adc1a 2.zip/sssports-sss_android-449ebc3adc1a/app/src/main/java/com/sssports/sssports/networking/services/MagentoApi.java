package com.sssports.sssports.networking.services;

import com.sssports.sssports.models.magento.Order;
import com.sssports.sssports.models.magento.PaymentInformation;
import com.sssports.sssports.models.magento.PaymentMethodData;
import com.sssports.sssports.models.magento.ShippingInformation;
import com.sssports.sssports.models.magento.PaymentMethodsAndTotals;
import com.sssports.sssports.models.magento.ShippingAddress;
import com.sssports.sssports.models.magento.ShippingMethod;
import com.sssports.sssports.models.magento.CartItem;
import com.sssports.sssports.models.magento.CartItemRequest;
import com.sssports.sssports.models.magento.CartTotalSummary;

import java.util.List;

import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import rx.Observable;

/**
 * Created by Adeleclark on 8/25/17.
 */

public interface MagentoApi {

    @POST("/rest/V1/guest-carts")
    Observable<Response<String>> createCart();

    @POST("/rest/V1/guest-carts/{cart_id}/items")
    Observable<Response<CartItem>> addToCart(@Path("cart_id") String cartId, @Body CartItemRequest cartItem);

    @GET("rest/V1/guest-carts/{cart_id}/items")
    Observable<List<CartItem>> getCartDetails(@Path("cart_id") String cartId);

    @DELETE("/rest/V1/guest-carts/{cart_id}/items/{item_id}")
    Observable<Response<Boolean>> deleteCartItem(@Path("cart_id") String cartId, @Path("item_id") Integer itemId);

    @PUT("/rest/V1/guest-carts/{cart_id}/items/{item_id}")
    Observable<Response<CartItem>> updateCart(@Path("cart_id") String cartId, @Path("item_id") Integer itemId, @Body CartItemRequest cartItemRequest);

    @GET("/rest/V1/guest-carts/{cart_id}/totals")
    Observable<Response<CartTotalSummary>> getSummaryTotals(@Path("cart_id") String cartId);

    @POST("/rest/V1/guest-carts/{cart_id}/estimate-shipping-methods")
    Observable<List<ShippingMethod>> sendShippingAddress(@Path("cart_id") String cartId, @Body ShippingAddress address);

    @POST("/rest/V1/guest-carts/{cart_id}/shipping-information")
    Observable<PaymentMethodsAndTotals> getPaymentMethodsAndTotals(@Path("cart_id") String cartId, @Body ShippingInformation addressInformation);
    
    @PUT("/rest/V1/guest-carts/{cart_id}/selected-payment-method")
    Observable<Response<String>> sendSelectedPaymentMethod(@Path("cart_id") String cartId, @Body PaymentMethodData method);

    @POST("/rest/V1/guest-carts/{cart_id}/payment-information")
    Observable<Response<String>> sendPaymentInformation(@Path("cart_id") String cartId, @Body PaymentInformation paymentInformation);

    @GET("/rest/V1/orders/{order_id}")
    Observable<Response<Order>> getOrderDetails(@Header("Authorization") String authorization, @Path("order_id") String orderId);

    @POST("/rest/V1/guest-carts/{cart_id}/set-payment-information")
    Observable<Response<String>> setPaymentInformation(@Path("cart_id") String cartId, @Body PaymentInformation paymentInformation);
}
