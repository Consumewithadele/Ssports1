package com.sssports.sssports.ui.main.category;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

import com.hannesdorfmann.mosby3.mvp.MvpFragment;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Category;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.networking.NetworkUtils;
import com.sssports.sssports.ui.main.MainScreenListener;
import com.sssports.sssports.ui.widgets.WidgetDirector;
import com.sssports.sssports.ui.widgets.WidgetDirectorImp;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by mlukovic on 7/31/17.
 */

public class CategoryFragment extends
        MvpFragment<CategoryFragmentMVPContract.View, CategoryFragmentMVPContract.Presenter>
        implements CategoryFragmentMVPContract.View {

    private static final String ARG_CATEGORY_L1 = "category-id-level1";

    MainScreenListener mMainScreenListener;
    OnCategorySelectedListener mOnCategorySelectedListener;

    @BindView(R.id.expandable_category_list_view) ExpandableListView mExpandableCategoryListView;
    @BindView(R.id.header_category_image) ImageView ivHeaderImage;
    @BindView(R.id.tv_category_description) TextView tvCategoryDescription;
    @BindView(R.id.loader_category) ProgressBar mPageLoader;
    @BindView(R.id.category_fragment_holder) LinearLayout categoryFragmentHolder;
    @BindView(R.id.category_scroll_view) ScrollView categoryScrollView;

    public static CategoryFragment newInstance(String link) {
        final CategoryFragment fragment = new CategoryFragment();
        final Bundle args = new Bundle();
        String categoryId = NetworkUtils.getLastSegmentOfPath(link);
        args.putSerializable(ARG_CATEGORY_L1, categoryId);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public android.view.View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        android.view.View view = inflater.inflate(R.layout.fragment_category, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public CategoryFragmentMVPContract.Presenter createPresenter() {
        return new CategoryFragmentPresenterImpl(this, getActivity());
    }

    @Override
    public void onViewCreated(android.view.View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadData();
    }

    private void loadData() {
        Bundle args = getArguments();
        if (args != null) {
            String categoryId = (String) args.getSerializable(ARG_CATEGORY_L1);
            presenter.loadData(categoryId);
        } else {
            showError();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception
        try {
            mMainScreenListener = (MainScreenListener) getActivity();
            mOnCategorySelectedListener = (OnCategorySelectedListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @Override
    public void showCategoryList(List<Category> categoryList) {
        mExpandableCategoryListView.setVisibility(android.view.View.VISIBLE);
        CategoryExpandableListAdapter expandableListAdapter = new CategoryExpandableListAdapter(getContext(), categoryList, category -> {
//            Toast.makeText(getContext(), category.getId(), Toast.LENGTH_SHORT).show();
            if (mOnCategorySelectedListener != null)
                mOnCategorySelectedListener.onCategoryClick(category);
        });
        mExpandableCategoryListView.setAdapter(expandableListAdapter);
        mExpandableCategoryListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previousGroup = -1;

            @Override
            public void onGroupExpand(int groupPosition) {
                if (groupPosition != previousGroup) {
                    mExpandableCategoryListView.collapseGroup(previousGroup);
                }
                previousGroup = groupPosition;
            }
        });

        mExpandableCategoryListView.setOnGroupClickListener((parent, v, groupPosition, id) -> {
            setListViewHeight(parent, groupPosition);
            return false;
        });

        //Hack to expand the list view
        setListViewHeight(mExpandableCategoryListView, -1);
    }

    @Override
    public void showLoader(boolean visible) {
        mPageLoader.setVisibility(visible ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    @Override
    public void showError() {
        //TODO showError()
        Toast.makeText(getContext(), R.string.error_while_loading_content, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showHeaderImage(String imageUrl) {
        if (getContext() == null) return;

        GlideApp.with(getContext())
                .load(imageUrl)
                .transition(withCrossFade())
                .placeholder(R.drawable.loading_placeholder)
                .error(R.drawable.loading_placeholder)
                .into(ivHeaderImage);
    }

    @Override
    public void showDescription(String description) {
        if (TextUtils.isEmpty(description)) {
            tvCategoryDescription.setVisibility(android.view.View.GONE);
            return;
        }
        tvCategoryDescription.setVisibility(android.view.View.VISIBLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            tvCategoryDescription.setText(Html.fromHtml(description, Html.FROM_HTML_MODE_COMPACT));
        } else {
            tvCategoryDescription.setText(Html.fromHtml(description));
        }
    }

    @Override
    public void setTitle(String name) {
        mMainScreenListener.showScreenTitle(name);
    }

    @Override
    public void showWidgets(List<Widget> widgetList) {
        WidgetDirector widgetDirector = new WidgetDirectorImp(categoryFragmentHolder, widgetList, getActivity(), categoryScrollView);
        widgetDirector.construct();
    }

    private void setListViewHeight(ExpandableListView listView, int group) {
        ExpandableListAdapter listAdapter = listView.getExpandableListAdapter();
        int totalHeight = 0;
        int desiredWidth = android.view.View.MeasureSpec.makeMeasureSpec(listView.getWidth(),
                android.view.View.MeasureSpec.EXACTLY);
        for (int i = 0; i < listAdapter.getGroupCount(); i++) {
            android.view.View groupItem = listAdapter.getGroupView(i, false, null, listView);
            groupItem.measure(desiredWidth, android.view.View.MeasureSpec.UNSPECIFIED);

            totalHeight += groupItem.getMeasuredHeight();

            if (((listView.isGroupExpanded(i)) && (i != group))
                    || ((!listView.isGroupExpanded(i)) && (i == group))) {
                for (int j = 0; j < listAdapter.getChildrenCount(i); j++) {
                    android.view.View listItem = listAdapter.getChildView(i, j, false, null,
                            listView);
                    listItem.measure(desiredWidth, android.view.View.MeasureSpec.UNSPECIFIED);

                    totalHeight += listItem.getMeasuredHeight();

                }
            }
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        int height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getGroupCount() - 1));
        if (height < 10)
            height = 200;
        params.height = height;
        listView.setLayoutParams(params);
        listView.requestLayout();

    }

    public interface OnCategorySelectedListener {
        void onCategoryClick(Category category);
    }
}
