package com.sssports.sssports.ui.widgets;

import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.ScrollView;


import com.sssports.sssports.models.jsonapi.Widget;

import java.util.List;

/**
 * Created by Adeleclark on 7/3/17.
 */

public class WidgetDirectorImp implements WidgetDirector {

    private List<Widget> mWidgetList;
    private WidgetBuilder mWidgetBuilder;
    private Activity mActivity;
    private ScrollView mScrollView;

    public WidgetDirectorImp(LinearLayout linearLayoutWidgetList, List<Widget> widgetList, Activity activity, ScrollView scrollView) {
        mWidgetList = widgetList;
        mActivity = activity;
        mWidgetBuilder = new WidgetBuilderImpl(linearLayoutWidgetList, activity);
        mScrollView = scrollView;
    }

    @Override
    public void construct() {
        for (Widget widget : mWidgetList) {
            switch (widget.getKind()){
                case WidgetConstants.Type.WIDGET_CATEGORY:
                case WidgetConstants.Type.WIDGET_CATEGORY_WITH_HEADING:
                    mWidgetBuilder.buildCategoryWidget(widget);
                    break;
                case WidgetConstants.Type.WIDGET_HERO:
                    mWidgetBuilder.buildHeroWidget(widget, true);
                    break;
                case WidgetConstants.Type.WIDGET_USP_BAR:
                    mWidgetBuilder.buildUspBarWidget();
                    break;
                case WidgetConstants.Type.WIDGET_PRODUCTS_HORIZONTAL_SCROLL:
                    mWidgetBuilder.buildProductsHorizontalScrollWidget(widget);
                    break;
                case WidgetConstants.Type.WIDGET_BLOG_POST:
                    mWidgetBuilder.buildBlogPostWidget(widget);
                    break;
                case WidgetConstants.Type.WIDGET_SALE_BANNER:
                    mWidgetBuilder.buildSaleBannerWidget(widget);
                    break;
                case WidgetConstants.Type.WIDGET_PRODUCTS_VERTICAL_SCROLL:
                    mWidgetBuilder.buildProductVerticalScrollWidget(widget, mScrollView);
                    break;
                case WidgetConstants.Type.WIDGET_SLIDER_CONTENT:
                    mWidgetBuilder.buildSliderContentWidget(widget);
                    break;
                case WidgetConstants.Type.WIDGET_PROMOTION:
                    mWidgetBuilder.buildPromotionWidget(widget);
                    break;
            }

        }
    }
}
