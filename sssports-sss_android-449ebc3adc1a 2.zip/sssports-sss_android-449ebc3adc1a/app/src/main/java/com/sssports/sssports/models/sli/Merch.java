
package com.sssports.sssports.models.sli;

import com.squareup.moshi.Json;

public class Merch {

    @Json(name = "jumpurl")
    private String jumpurl;

    public String getJumpurl() {
        return jumpurl;
    }

    public void setJumpurl(String jumpurl) {
        this.jumpurl = jumpurl;
    }

}
