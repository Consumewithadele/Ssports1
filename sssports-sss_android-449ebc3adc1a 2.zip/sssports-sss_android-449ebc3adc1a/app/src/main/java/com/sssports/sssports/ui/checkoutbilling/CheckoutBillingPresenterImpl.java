package com.sssports.sssports.ui.checkoutbilling;

import android.app.Activity;
import android.text.TextUtils;
import android.util.Base64;

import com.sssports.sssports.SSSApp;
import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.locale.SharedPrefConstants;
import com.sssports.sssports.locale.SharedPreferenceManager;
import com.sssports.sssports.models.custom.CardDetails;
import com.sssports.sssports.models.custom.CardType;
import com.sssports.sssports.models.custom.Token;
import com.sssports.sssports.models.custom.UserDetailsDb;
import com.sssports.sssports.models.jsonapi.BillingAddress;
import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.jsonapi.Order;
import com.sssports.sssports.models.jsonapi.Subscription;
import com.sssports.sssports.models.magento.AdditionalData;
import com.sssports.sssports.models.magento.AddressInformation;
import com.sssports.sssports.models.magento.PaymentData;
import com.sssports.sssports.models.magento.PaymentInformation;
import com.sssports.sssports.models.magento.PaymentMethod;
import com.sssports.sssports.models.magento.PaymentMethodData;
import com.sssports.sssports.models.magento.PaymentMethodsAndTotals;
import com.sssports.sssports.models.magento.ShippingInformation;
import com.sssports.sssports.models.magento.ShippingMethod;
import com.sssports.sssports.models.magento.TotalSegment;
import com.sssports.sssports.models.magento.UserDetailsDto;
import com.sssports.sssports.networking.services.MagentoApi;
import com.sssports.sssports.networking.services.SSSApi;
import com.sssports.sssports.networking.services.SSSApiNotJson;
import com.sssports.sssports.util.CommonConstants;
import com.sssports.sssports.util.ReadFromJsonFIle;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import retrofit2.Response;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Created by natalijaratajac on 8/26/17.
 */

public class CheckoutBillingPresenterImpl implements CheckoutBillingContract.CheckoutBillingPresenter {

    private CheckoutBillingContract.CheckoutBillingView checkoutBillingView;
    private Activity activity;
    private SharedPreferenceManager sharedPreferenceManager;
    private boolean sameAsShippingAddressSelected;
    private CardDetails cardDetails;
    private SSSApi sssApi;
    private MagentoApi magentoApi;
    private SSSApiNotJson sssApiNotJson;

    private List<Country> countries;
    private UserDetailsDb userDetailsDbShippingAddress;
    private UserDetailsDto userDetailsDtoBillingAddress;
    private ArrayList<ShippingMethod> shippingMethods;
    private List<PaymentMethod> paymentMethods;
    private PaymentMethod selectedPaymentMethod;
    private boolean saveData;
    private List<TotalSegment> mTotalSegmentList;

    public CheckoutBillingPresenterImpl(CheckoutBillingContract.CheckoutBillingView checkoutBillingView, Activity activity, ArrayList<ShippingMethod> shippingMethods, boolean saveData) {
        this.checkoutBillingView = checkoutBillingView;
        this.activity = activity;
        this.shippingMethods = shippingMethods;
        this.saveData = saveData;
        sssApi = ((SSSApp) activity.getApplication()).getApplicationComponent().sssService();
        magentoApi = ((SSSApp) activity.getApplication()).getApplicationComponent().magentoService();
        sssApiNotJson = ((SSSApp) activity.getApplication()).getApplicationComponent().sssServiceNotJson();
        sharedPreferenceManager = new SharedPreferenceManager(activity, SharedPrefConstants.PreferenceName.USER_DATA);
        cardDetails = new CardDetails();
        userDetailsDtoBillingAddress = new UserDetailsDto();
    }

    @Override
    public void loadData() {
        checkoutBillingView.showLoading();
        checkoutBillingView.hideScreen();

        String cartId = SPDataManager.INSTANCE.getProductCartId();
        AddressInformation addressInformation = new AddressInformation();
        ShippingInformation shippingInformation = new ShippingInformation();
        shippingInformation.setAddressInformation(addressInformation);
        userDetailsDbShippingAddress = (UserDetailsDb) sharedPreferenceManager.getObject(SharedPrefConstants.PreferenceKeyName.USER_DETAILS, UserDetailsDb.class);
        addressInformation.setShippingAddress(userDetailsDbShippingAddress);
        addressInformation.setBillingAddress(userDetailsDbShippingAddress);
        addressInformation.setShippingCarrierCode(shippingMethods.get(0).getCarrierCode());
        addressInformation.setShippingMethodCode(shippingMethods.get(0).getMethodCode());

        magentoApi.getPaymentMethodsAndTotals(cartId, shippingInformation)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<PaymentMethodsAndTotals>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error sending shipping address");
                        checkoutBillingView.hideLoading();
                    }

                    @Override
                    public void onNext(PaymentMethodsAndTotals paymentMethodsAndTotals) {

                        getCountriesFromJsonFile();
                        paymentMethods = paymentMethodsAndTotals.getPaymentMethods();
                        checkoutBillingView.showScreen();
                        checkoutBillingView.hideLoading();
                        initializeScreen();
                    }
                });
    }

    private void getCountriesFromJsonFile() {
        countries = ReadFromJsonFIle.getCountriesFromJsonFile("countries.json", activity);
        for (Country country : countries) {
            country.setRegionList(ReadFromJsonFIle.getRegionListFromJson(country.getCode() + ".json", activity));
        }
    }

    @Override
    public void initializeScreen() {
        sameAsShippingAddressSelected = true;
        checkoutBillingView.setupCountryDropDownList(countries);
        prefillShippingAddressFromSharedPefs();
        checkoutBillingView.initializeShippingMethodAdapter();
        checkoutBillingView.initializePaymentMethodAdapter();
        checkoutBillingView.initializeWidgetForSummary();
    }

    @Override
    public List<PaymentMethod> getPaymentMethods() {
        return paymentMethods;
    }

    private void prefillShippingAddressFromSharedPefs() {
        userDetailsDbShippingAddress = (UserDetailsDb) sharedPreferenceManager.getObject(SharedPrefConstants.PreferenceKeyName.USER_DETAILS, UserDetailsDb.class);
        if (TextUtils.isEmpty(userDetailsDbShippingAddress.getRegion())) {
            checkoutBillingView.setShippingAddress(userDetailsDbShippingAddress.getAddress()[0] + " , " + userDetailsDbShippingAddress.getCountryName());
        } else {
            checkoutBillingView.setShippingAddress(userDetailsDbShippingAddress.getAddress()[0] + " , " + userDetailsDbShippingAddress.getRegion() + " , " + userDetailsDbShippingAddress.getCountryName());
        }
    }

    @Override
    public void setSameAsShippingAddressSelected(boolean flag) {
        sameAsShippingAddressSelected = flag;
    }

    @Override
    public void setCardNumber(String cardNumber) {
        cardDetails.setCardNumber(cardNumber);
    }

    @Override
    public void setCardHolder(String cardHolder) {
        cardDetails.setCardHolder(cardHolder);
    }

    @Override
    public void setExpirationDate(String expirationDate) {
        cardDetails.setExpirationMonth(expirationDate);
    }

    @Override
    public void setExpirationYear(int year) {
        cardDetails.setExpirationYear(Integer.toString(year));
    }

    @Override
    public void setExpirationMonth(int month) {
        cardDetails.setExpirationMonth(Integer.toString(month));
    }

    @Override
    public void setCvv(String cvv) {
        cardDetails.setCvv(cvv);
    }

    @Override
    public void findCardIcon(String s) {
        s += "999999";
        CardType detectedCardType = CardType.detect(s);
        switch (detectedCardType) {
            case VISA:
                checkoutBillingView.setCardIconVisa();
                setCardType("001");
                break;
            case MASTERCARD:
                checkoutBillingView.setCardIconMasterCard();
                setCardType("002");
                break;
//               for now not available by requirements
//            case AMERICAN_EXPRESS:
//                checkoutBillingView.setCardIconAmericanExpress();
//                break;
//            case DINERS_CLUB:
//                checkoutBillingView.setCardIconDinersClub();
//                break;
//            case DISCOVER:
//                checkoutBillingView.setCardIconDiscover();
//                break;
//            case JCB:
//                checkoutBillingView.setCardIconJCB();
//                break;
            case UNKNOWN:
                checkoutBillingView.setDefaultCardIcon();
                break;
        }
    }

    private void setCardType(String cardTypeCode) {
        cardDetails.setType(cardTypeCode);
    }

    @Override
    public void setPhoneNumber(String s) {
        userDetailsDtoBillingAddress.setPhoneNumber(s);
    }

    @Override
    public void setPoBox(String s) {
        userDetailsDtoBillingAddress.setPoBox(s);
    }

    @Override
    public void setRegion(String s) {
        userDetailsDtoBillingAddress.setRegion(s);
        userDetailsDtoBillingAddress.setCity(s);
    }

    @Override
    public void setCountry(String countryId, String countryName) {
        userDetailsDtoBillingAddress.setCountry(countryId);
    }

    @Override
    public void setAddress(String s) {
        String[] addressList = new String[1];
        addressList[0] = s;
        userDetailsDtoBillingAddress.setAddress(addressList);
    }

    @Override
    public void setChosenShippingMethod(ShippingMethod shippingMethod) {
//        TODO: see how to send chosen shipping method and set here
    }

    @Override
    public void setChosenPaymentMethod(PaymentMethod paymentMethod) {
        sendPaymentMethod(paymentMethod);
        selectedPaymentMethod = paymentMethod;
    }

    private BillingAddress getBillingAddressForSubscription() {

        BillingAddress billingAddress = new BillingAddress();
        billingAddress.setFirstName(getCardsHolderFirstName(cardDetails.getCardHolder()));
        billingAddress.setLastName(getCardsHolderLastName(cardDetails.getCardHolder()));
        billingAddress.setEmail(userDetailsDbShippingAddress.getEmail());

        if (sameAsShippingAddressSelected) {
            billingAddress.setCity(userDetailsDbShippingAddress.getRegion());
            billingAddress.setCountry(userDetailsDbShippingAddress.getCountry());
            billingAddress.setPhoneNumber(userDetailsDbShippingAddress.getPhoneNumber());
            billingAddress.setPostalCode(userDetailsDbShippingAddress.getPoBox());
            billingAddress.setState(userDetailsDbShippingAddress.getRegion());
            billingAddress.setStreet(userDetailsDbShippingAddress.getAddress()[0]);
        } else {
            billingAddress.setCity(userDetailsDtoBillingAddress.getRegion());
            billingAddress.setCountry(userDetailsDtoBillingAddress.getCountry());
            billingAddress.setPhoneNumber(userDetailsDtoBillingAddress.getPhoneNumber());
            billingAddress.setPostalCode(userDetailsDtoBillingAddress.getPoBox());
            billingAddress.setState(userDetailsDtoBillingAddress.getRegion());
            billingAddress.setStreet(userDetailsDtoBillingAddress.getAddress()[0]);
        }

        return billingAddress;
    }


    private String getCardsHolderFirstName(String cardsHolder) {

        String firstName = cardsHolder.split(" ")[0];
        return firstName;
    }

    private String getCardsHolderLastName(String cardsHolder) {
        String lastName = cardsHolder.split(" ")[1];
        if (cardsHolder.split(" ").length > 2) {
            for (int i = 2; i < cardsHolder.split(" ").length; i++) {
                lastName += " " + cardsHolder.split(" ")[i];
            }
        }
        return lastName;
    }

    @Override
    public void sendPaymentMethod(PaymentMethod paymentMethod) {
        checkoutBillingView.disableBuyButton();
        String cartId = SPDataManager.INSTANCE.getProductCartId();

        PaymentInformation paymentInformation = new PaymentInformation();
        paymentInformation.setEmail(userDetailsDbShippingAddress.getEmail());
        PaymentData paymentData = new PaymentData();
        paymentData.setPoNumber(userDetailsDbShippingAddress.getPoBox());
        paymentData.setMethod(paymentMethod.getCode());
        paymentInformation.setPaymentData(paymentData);
        PaymentMethodData method = new PaymentMethodData();
        method.setPaymentData(paymentData);

        magentoApi.sendSelectedPaymentMethod(cartId, method)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Response<String>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error sending shipping address");
                        checkoutBillingView.enableBuyButton();
//                        TODO: change error handling with sth better
                        checkoutBillingView.showErrorDialog();

                    }

                    @Override
                    public void onNext(Response<String> response) {
//                        checkoutBillingView.enableBuyButton();
                        checkoutBillingView.refreshSummary();
                    }
                });
    }

    @Override
    public void buyItems() {
        if (!checkIfAllDataIsEntered()) {
            checkoutBillingView.showSnackBarPleaseFillAllData();
            return;
        }

        checkoutBillingView.showLoaderDialog();
        checkoutBillingView.disableBuyButton();

//        if (selectedPaymentMethod.getCode().equalsIgnoreCase(CommonConstants.CASH_ON_DELIVERY_PAYMENT)) {
//            sendPaymentInformation(null);
//        } else {
        createAuthToken();
//        }
    }

    @Override
    public void setTotalAmountSegmentList(List<TotalSegment> totalSegmentList) {
        checkoutBillingView.enableBuyButton();
        mTotalSegmentList = totalSegmentList;
    }

    @Override
    public void onRefreshSummaryError() {
        checkoutBillingView.disableBuyButton();
        checkoutBillingView.showErrorDialog();
    }

    private void createAuthToken() {
        sssApiNotJson.getAuthToken("client_credentials", 2, "us3TATpbjusLl1r57EHDDD1SJEt5zh75bSjhXNki")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Token>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error sending payment", e.toString());
                        checkoutBillingView.hideLoaderDialog();
//                        checkoutBillingView.showPlacingOrderError();
                        checkoutBillingView.showErrorDialog();
                        checkoutBillingView.enableBuyButton();
                    }

                    @Override
                    public void onNext(Token token) {
//                        createSubscription(token.getTokenType(), token.getAccessToken());
                        placeOrder(token.getTokenType(), token.getAccessToken());
                    }
                });
    }

    private void placeOrder(String tokenType, String accessToken) {
        Order order = new Order();
        String cartId = SPDataManager.INSTANCE.getProductCartId();
        order.setCartId(cartId);

        switch (selectedPaymentMethod.getCode()) {
            case CommonConstants.CASH_ON_DELIVERY_PAYMENT:
                order.setPaymentMethod(CommonConstants.CASH_ON_DELIVERY_PAYMENT);
                break;
            default:
                order.setPaymentMethod(selectedPaymentMethod.getCode());
                order.setBillingAddress(getBillingAddressForSubscription());
                order.setCard(cardDetails);
                break;
        }

        sssApi.placeOrder(order, tokenType + " " + accessToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Order>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        checkoutBillingView.showErrorDialog();
                        checkoutBillingView.hideLoaderDialog();
                        checkoutBillingView.enableBuyButton();
                    }

                    @Override
                    public void onNext(Order order) {
                        checkoutBillingView.hideLoaderDialog();
                        checkoutBillingView.enableBuyButton();
                        SPDataManager.INSTANCE.deleteProductCartId();
                        deleteUserDataFromSharedPrefs();
                        checkoutBillingView.openNextScreen(order.getOrderNumber());
                    }
                });
    }

    private void createSubscription(String tokenType, String accessToken) {

        Subscription subscription = new Subscription();

        subscription.setBillingAddress(getBillingAddressForSubscription());
//        String encryptedCardData = null;
//        try {
//            encryptedCardData = encryptCardData();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        String encryptedCardData = "eyJpdiI6InVMU2J5SzhJaWJtcjZRcEFyU1JMOUE9PSIsInZhbHVlIjoiY3RtcU1KQlNQOXkrcnY5dDk1V3hFOVNnd3N6eFNVMXVNbTNQQzVcL05DKzI1NUZNR1M2Ymg1ZE0xUEIrME15ZXFiUG4yeitaRUkreHVZODNSM21EUzNPOVZ4bGtadU9paDROeHJTODh2d2pDb1lRaEk0VlBGdEVtQWduNFZ5S1RORHJDS1hWUmNcLzRsSlduR3Z3R3laYkNkSUJLSVY0UjFLUnpQWEFDeGo0VE4zK2t2d3JORk1qMFZ3c3hrbnI3M2giLCJtYWMiOiI3MzIxYjgyMDljNGYzNzhmOWE5MmM5ZTNlZDM0NWU4NTM3ZWU2NTZiYTdhYmQ3MjI1ZmM3MmFhZTExZGY1YjVhIn0=";
        cardDetails.setCurrencyCode(SPDataManager.INSTANCE.getCurrentCurrency());
        subscription.setCard(cardDetails);

        sssApi.createSubscription(tokenType + " " + accessToken, subscription)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Subscription>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error sending payment", e.toString());
                        checkoutBillingView.hideLoaderDialog();
//                        checkoutBillingView.showPlacingOrderError();
                        checkoutBillingView.showErrorDialog();
                    }

                    @Override
                    public void onNext(Subscription subscriptionResponse) {
                        sendPaymentInformation(subscriptionResponse.getSubscriptionId());
                    }
                });
    }

    private UserDetailsDto getBillingAddress() {
        if (selectedPaymentMethod.getCode().equalsIgnoreCase(CommonConstants.CASH_ON_DELIVERY_PAYMENT)) {
            return null;
        }

        if (sameAsShippingAddressSelected) {
            userDetailsDbShippingAddress.setFirstName(getCardsHolderFirstName(cardDetails.getCardHolder()));
            userDetailsDbShippingAddress.setLastName(getCardsHolderLastName(cardDetails.getCardHolder()));
            return userDetailsDbShippingAddress;
        } else {
            userDetailsDtoBillingAddress.setFirstName(getCardsHolderFirstName(cardDetails.getCardHolder()));
            userDetailsDtoBillingAddress.setLastName(getCardsHolderLastName(cardDetails.getCardHolder()));
            userDetailsDtoBillingAddress.setEmail(userDetailsDbShippingAddress.getEmail());
            return userDetailsDtoBillingAddress;
        }
    }

    private void sendPaymentInformation(String paymentToken) {

        String cartId = SPDataManager.INSTANCE.getProductCartId();
        PaymentInformation paymentInformation = new PaymentInformation();
        paymentInformation.setEmail(userDetailsDbShippingAddress.getEmail());
        PaymentData paymentData = new PaymentData();
        paymentData.setPoNumber(userDetailsDbShippingAddress.getPoBox());
        paymentData.setMethod(selectedPaymentMethod.getCode());
        AdditionalData additionalData = new AdditionalData();
        additionalData.setPaymentToken(paymentToken);
        paymentData.setAdditionalData(additionalData);
        paymentInformation.setPaymentData(paymentData);
        paymentInformation.setBillingAddress(getBillingAddress());

        magentoApi.sendPaymentInformation(cartId, paymentInformation)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Response<String>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error sending payment", e.toString());
                        checkoutBillingView.hideLoaderDialog();
//                        checkoutBillingView.showPlacingOrderError();
                        checkoutBillingView.showErrorDialog();
                    }

                    @Override
                    public void onNext(Response<String> response) {
                        checkoutBillingView.hideLoaderDialog();
                        if (response.isSuccessful()) {
                            SPDataManager.INSTANCE.deleteProductCartId();
                            deleteUserDataFromSharedPrefs();
                            checkoutBillingView.openNextScreen(response.body());
                        } else {
//                            checkoutBillingView.showPlacingOrderError();
                            checkoutBillingView.showErrorDialog();
                        }
                    }
                });
    }

    private void deleteUserDataFromSharedPrefs() {
        if (!saveData) {
            sharedPreferenceManager.remove(SharedPrefConstants.PreferenceKeyName.USER_DETAILS);
        }
    }

    private String encryptCardData() throws Exception {
//        TODO encrypt card data
        CardDetails cardDetails = this.cardDetails;
        String plainText = "{ \"account_number\": \"4111111111111111\",\"expiration_month\": \"12\",\"expiration_year\": \"2020\",\"cv_number\": \"123\",\"type\": \"001\"}";
        String key = "base64:K+ApNsTvRTZUJRyOkM/NVp3VnQsYFXQKpfQS+8YMO4c=";

        byte[] clean = plainText.getBytes();

        // Generating IV.
        int ivSize = 16;
        byte[] iv = new byte[ivSize];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

        // Hashing key.
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update(key.getBytes("UTF-8"));
        byte[] keyBytes = new byte[16];
        System.arraycopy(digest.digest(), 0, keyBytes, 0, keyBytes.length);
        SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "AES");

        // Encrypt.
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
        byte[] encrypted = cipher.doFinal(clean);

        // Combine IV and encrypted part.
        byte[] encryptedIVAndText = new byte[ivSize + encrypted.length];
        System.arraycopy(iv, 0, encryptedIVAndText, 0, ivSize);
        System.arraycopy(encrypted, 0, encryptedIVAndText, ivSize, encrypted.length);

        return Base64.encodeToString(encryptedIVAndText, 0);

    }

    private boolean checkIfAllDataIsEntered() {
        if (selectedPaymentMethod.getCode().equalsIgnoreCase(CommonConstants.CASH_ON_DELIVERY_PAYMENT))
            return true;

        if (TextUtils.isEmpty(cardDetails.getCardNumber()) || TextUtils.isEmpty(cardDetails.getCardHolder())
                || TextUtils.isEmpty(cardDetails.getExpirationMonth()) || TextUtils.isEmpty(cardDetails.getExpirationYear()) || TextUtils.isEmpty(cardDetails.getCvv()))
            return false;

        if (cardDetails.getCardHolder().split(" ").length < 2) {
            checkoutBillingView.showCardHolderError();
            return false;
        }

        if (!validateCardNumber(cardDetails.getCardNumber())) {
            checkoutBillingView.showCardNumberErrorMessage();
            return false;
        }

        if (sameAsShippingAddressSelected)
            return true;

        if (userDetailsDtoBillingAddress.getAddress() == null || TextUtils.isEmpty(userDetailsDtoBillingAddress.getAddress()[0]) || TextUtils.isEmpty(userDetailsDtoBillingAddress.getCountry())
                || TextUtils.isEmpty(userDetailsDtoBillingAddress.getPoBox()) || TextUtils.isEmpty(userDetailsDtoBillingAddress.getPhoneNumber()))
            return false;

        if (!validatePhoneNumber(userDetailsDtoBillingAddress.getPhoneNumber())) {
            checkoutBillingView.showPhoneNumberErrorMessage();
            return false;
        }


        return true;
    }

    private boolean validatePhoneNumber(String phoneNumber) {

        String regex = "^\\+?(\\d[.\\- ]*){9,14}$";
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(phoneNumber).matches();
    }

    private boolean validateCardNumber(String cardNumber) {
        CardType detectedCardType = CardType.detect(cardNumber);
        switch (detectedCardType) {
            case VISA:
                return true;
            case MASTERCARD:
                return true;
            case UNKNOWN:
                checkoutBillingView.showCardNumberErrorMessage();
                return false;
        }
        return false;
    }
}
