package com.sssports.sssports.ui.checkoutbilling.builder;

import android.app.Activity;
import android.widget.LinearLayout;

import com.sssports.sssports.ui.checkoutbilling.CheckoutBillingListener;

/**
 * Created by mlukovic on 9/1/17.
 */

public class CheckoutBillingDirectorImpl implements CheckoutBillingDirector {


    private LinearLayout mHostLayout;
    private CheckoutBillingBuilder mCheckoutBillingBuilder;

    public CheckoutBillingDirectorImpl(LinearLayout hostLayout, Activity activity) {
        mHostLayout = hostLayout;
        mCheckoutBillingBuilder = new CheckoutBillingBuilderImpl(activity, hostLayout);
    }

    @Override
    public void construct(OnSummaryReadyListener onSummaryReadyListener) {
        mCheckoutBillingBuilder.buildCheckoutSummary(onSummaryReadyListener);
    }

    @Override
    public void refreshSummary(OnSummaryReadyListener onSummaryReadyListener) {
        mCheckoutBillingBuilder.refreshCheckoutSummary(onSummaryReadyListener);
    }

}
