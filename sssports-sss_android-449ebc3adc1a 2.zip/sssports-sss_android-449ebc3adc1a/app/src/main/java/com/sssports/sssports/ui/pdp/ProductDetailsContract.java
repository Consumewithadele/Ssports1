package com.sssports.sssports.ui.pdp;

import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.ProductChild;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.models.magento.CartItem;

import java.util.ArrayList;
import java.util.List;

import moe.banana.jsonapi2.Document;

/**
 * Created by Adeleclark on 8/8/17.
 */

public interface ProductDetailsContract {

    interface ProductDetailsView {

        void showProductDetails(Product product);

        void showLoading();

        void hideLoading();

        void showError();

        void showRelatedProductsAndWidgets(List<Widget> widgets);

        void enableAddToBagButton(boolean enabled);

        void showEnableToAddToBagMessage();

        void showAddToBagSuccessDialog();

        void showAddToBagError();

        void showAddToBagLoader(boolean visible);
    }

    interface ProductDetailsPresenter {

        void loadDataByProductId(String productId);

        void loadDataBySku(String productSku);

        void onProductChildChanged(ProductChild productChild);

        void onAddToBagClick();

        void onCartCreated(String cartId);

        void onAddToCartSuccess();

        void addToBagError();
    }

    interface ProductDetailsInteractor {

        void createCart();

        void addToCart(String cartId, ProductChild productChild);
    }
}
