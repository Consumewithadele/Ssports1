package com.sssports.sssports.ui.widgets.productdetail;

import android.text.TextUtils;

import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.ProductChild;
import com.sssports.sssports.models.jsonapi.Selection;
import com.sssports.sssports.util.CommonConstants;

import java.util.Collections;
import java.util.List;

import rx.Observable;

/**
 * Created by mlukovic on 8/18/17.
 */

public class ProductDetailsPresenterImpl implements ProductDetailsMvpContract.Presenter {

    private static final String TYPE_ID_SIMPLE = "simple";
    private static final String TYPE_ID_CONFIG = "configurable";

    private ProductDetailsMvpContract.View view;
    private Product mProduct;
    private String mCurrentColorOptionId;
    private List<Option> mColorOptionList;
    private List<Option> mSizeOptionList;
    private List<ProductChild> mProductChildrenList;
    private ProductChild mProductChildSelected;
    private ProductDetailListener mProductDetailListener;

    public ProductDetailsPresenterImpl(ProductDetailsMvpContract.View view, ProductDetailListener productDetailListener) {
        this.view = view;
        mProductDetailListener = productDetailListener;
    }

    @Override
    public void loadLoadData(Product product) {
        if (product == null) {
            //TODO Show error for Product Pager
//            view.showErrorEmptyData();
            return;
        }

        mProduct = product;
        mProductChildrenList = mProduct.getProductChildren();

        if (!TextUtils.isEmpty(product.getColor())) {
            view.showProductColor(product.getColor());
        } else {
            view.hideProductColor();
        }

        switch (product.getTypeId()) {
            case TYPE_ID_CONFIG:
                setOptionLists(mProduct);
                if (product.getColorId() != null) {
                    mCurrentColorOptionId = product.getColorId().toString();
                } else {
                    mCurrentColorOptionId = product.getProductChildren().get(0).getColor().toString();
                }
                populateProductListSizeLabel();
                populateColorList();
                ProductChild productChild;
                if (mColorOptionList != null && mColorOptionList.size() > 0) {
                    productChild = getProductByOptionColor(mProductChildrenList, mCurrentColorOptionId);

                    if (productChild == null) {
                        mCurrentColorOptionId = product.getProductChildren().get(0).getColor().toString();
                        productChild =  product.getProductChildren().get(0);
                    }

                    view.showColorWayList(mColorOptionList);
                    view.showProductImages(productChild.getImages());
                } else {
                    if (mProductChildrenList.size() > 0) {
                        productChild = mProductChildrenList.get(0);
                        view.showProductImages(productChild.getImages());
                    } else {
                        view.disableProductSizeList();
                        view.disableColorWayList();
                        mProductDetailListener.onProductChildSelected(new ProductChild(product));
                        view.showProductImages(product.getImages());
                    }
                }
                break;
            case TYPE_ID_SIMPLE:
                view.disableProductSizeList();
                view.disableColorWayList();
                mProductDetailListener.onProductChildSelected(new ProductChild(product));
                view.showProductImages(product.getImages());
                break;
        }

        view.showProductName(product.getSku());
        view.showPrice(mProduct);
    }


    private void populateColorList() {
        if (mColorOptionList == null || mColorOptionList.size() == 0) {
            view.disableColorWayList();
            return;
        }


        for (Option option : mColorOptionList) {

            ProductChild productChild = getProductByOptionColor(mProductChildrenList, option.getId());
            // set thumbnail image
            if (productChild != null) {
                option.setThumbnailImage(productChild.getThumbnailUrl());
            }

            //Set selected color
            if (option.getId().equalsIgnoreCase(mCurrentColorOptionId)) {
                option.setSelected(true);
            }
        }
    }

    private ProductChild getProductByOptionColor(List<ProductChild> mProductChildrenList, String optionId) {
        ProductChild productChildReturn = null;
        for (ProductChild productChild : mProductChildrenList) {
            if (productChild.getColor() != null && productChild.getColor().toString().equalsIgnoreCase(optionId)) {
                productChildReturn = productChild;
                break;
            }
        }
        return productChildReturn;
    }

    private void setCurrentProductConiguration(Product mProduct) {
//        for (Config config : mProduct.getConfigList()) {
//            if (config.getType().equalsIgnoreCase(CommonConstants.COLOR) ) {
//                mCurrentColorOptionId = config.getId();
//            } else if (config.getType().equalsIgnoreCase(CommonConstants.SIZE)) {
//                mCurrentSizeOptionId = config.getId();
//            }
//        }
    }

    private void populateProductListSizeLabel() {
        if (mProductChildrenList == null) return;
        // populate the size
        Observable.just(mProductChildrenList)
                .flatMapIterable(productChildren -> productChildren)
                .subscribe(this::setSizeAndColorLabel);
    }

    private void setSizeAndColorLabel(ProductChild productChild) {

        if (productChild == null) return;

        if (mSizeOptionList == null || mSizeOptionList.size() == 0) {
            view.disableProductSizeList();
            return;
        }

        Observable.just(mSizeOptionList)
                .flatMapIterable(mSizeOptionList -> mSizeOptionList)
                .filter(option -> {
                    if (productChild.getSize() != null) {
                        return option.getId().equalsIgnoreCase(productChild.getSize().toString());
                    } else {
                        return null;
                    }
                })
                .subscribe(option -> {
                    if (option != null)
                        productChild.setSizeLabel(option.getLabel());
                });
    }

    private void setOptionLists(Product product) {
        for (Selection selection : product.getSelections()) {
            if (selection.getAttributeCode().contains(CommonConstants.SIZE)) {
                mSizeOptionList = selection.getOptions();
            } else if (selection.getAttributeCode().contains(CommonConstants.COLOR)) {
                mColorOptionList = selection.getOptions();
            }
        }


    }

    @Override
    public void getSizeList() {
        if (mColorOptionList != null && mColorOptionList.size() > 0) {
            if (mCurrentColorOptionId != null && mProductChildrenList != null && mProductChildrenList.size() > 0) {
                Observable.just(mProductChildrenList)
                        .flatMapIterable(productChildren -> {
                            //sort size list based on sort_order attribute
                            Collections.sort(productChildren, (productChild1, productChild2) -> getOption(productChild1.getSize()).getSortOrder() - getOption(productChild2.getSize()).getSortOrder());
                            return productChildren;
                        })
                        .filter(productChild -> {
                            if (productChild.getColor() != null) {
                                return productChild.getColor().toString().equalsIgnoreCase(mCurrentColorOptionId);
                            } else {
                                return null;
                            }
                        })
                        .toList()
                        .subscribe(filteredProductsBySize -> view.showSizeList(filteredProductsBySize));

            } else {
                view.showErrorGettingSizeList();
            }
        } else if (mSizeOptionList != null && mSizeOptionList.size() > 0) {
            view.showSizeList(mProductChildrenList);
        } else {
            view.disableColorWayList();
            view.disableProductSizeList();
        }


    }

    private Option getOption(Integer size) {

        Option returnOption = null;
        for (Option option : mSizeOptionList) {
            if (option.getId().equalsIgnoreCase(size.toString())) {
                returnOption = option;
                break;
            }
        }
        return returnOption;
    }


    @Override
    public void onSizeChange(ProductChild productChild) {
        view.showSelectedSize(productChild);
        mProductChildSelected = productChild;
        view.showPrice(productChild);
        mProductDetailListener.onProductChildSelected(productChild);
    }

    @Override
    public void onColorChange(Option option) {
        mProductChildSelected = null;
        view.showProductColor(option.getLabel());
        view.resetSizeLabel();
        mCurrentColorOptionId = option.getId();
        ProductChild productChild = getProductByOptionColor(mProductChildrenList, mCurrentColorOptionId);
        view.showProductImages(productChild.getImages());
        mProductDetailListener.onProductChildSelected(mProductChildSelected);
    }

}
