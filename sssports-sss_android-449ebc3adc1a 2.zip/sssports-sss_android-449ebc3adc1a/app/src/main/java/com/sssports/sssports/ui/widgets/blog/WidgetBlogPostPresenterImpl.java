package com.sssports.sssports.ui.widgets.blog;

import android.text.TextUtils;

import com.sssports.sssports.models.jsonapi.Action;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.ui.widgets.WidgetConstants;

import java.util.List;

/**
 * Implementation of Presenter part of MVP for Blog Post Widget
 */

public class WidgetBlogPostPresenterImpl implements WidgetBlogPostContract.WidgetBlogPostPresenter {

    private Widget mWidget;
    private WidgetBlogPostContract.WidgetBlogPostView mBlogPostView;

    public WidgetBlogPostPresenterImpl(WidgetBlogPostContract.WidgetBlogPostView blogPostView, Widget widget) {
        mWidget = widget;
        mBlogPostView = blogPostView;
    }

    @Override
    public void loadData() {

        if (mWidget == null || mWidget.getBlockList() == null || mWidget.getBlockList().get(0) == null) {
            mBlogPostView.hideWidget();
            return;
        }

        initTitle(mWidget.getBlockList().get(0).getLabel());
        initDescription(mWidget.getBlockList().get(0).getText());
        initHeaderImage(mWidget.getBlockList().get(0).getImageUrl());

        if (mWidget.getBlockList().get(0).getVideo() == null) {
            // Show normal widget
            switch (mWidget.getBlockList().get(0).getActionList().size()) {
                case 1:
                case 2:
                    showCTAButtons(mWidget.getBlockList().get(0).getActionList());
                    break;
                default: {
                    mBlogPostView.hideWidget();
                }
            }
        } else {
            //Show video
            mBlogPostView.showVideo();
            mBlogPostView.hideCTA1();
            mBlogPostView.hideCTA2();
        }

    }

    @Override
    public void loadVideo() {
        if (mWidget.getBlockList() != null &&
                mWidget.getBlockList().get(0) != null &&
                !TextUtils.isEmpty(mWidget.getBlockList().get(0).getVideo())) {
            mBlogPostView.playVideo(mWidget.getBlockList().get(0).getVideo());
        } else {
            mBlogPostView.showErrorLoadingContent();
        }
    }

    @Override
    public void loadAction(int index) {
        if (isActionAvailable(index)) {
            mBlogPostView.openLink(mWidget.getBlockList().get(0).getActionList().get(index).getLink());
        } else {
            mBlogPostView.showErrorLoadingContent();
        }
    }

    private void showCTAButtons(List<Action> actionList) {

        if (actionList == null || actionList.size() == 0) {
            mBlogPostView.hideWidget();
            return;
        }

        switch (actionList.size()) {
            case 1: {
                mBlogPostView.showCTA1(mWidget.getBlockList().get(0).getActionList().get(0).getText());
                mBlogPostView.hideCTA2();
                break;
            }
            case 2: {
                mBlogPostView.showCTA2(mWidget.getBlockList().get(0).getActionList().get(1).getText());
                mBlogPostView.showCTA1(mWidget.getBlockList().get(0).getActionList().get(0).getText());
                break;
            }
            default: {
                mBlogPostView.hideWidget();
                return;
            }
        }
    }

    private void initHeaderImage(String imageUrl) {
        if (!TextUtils.isEmpty(imageUrl)) {
            mBlogPostView.showHeaderImage(mWidget.getBlockList().get(0).getImageUrl());
        }
    }

    private void initDescription(String text) {
        if (!TextUtils.isEmpty(text)) {
            mBlogPostView.showDescription(mWidget.getBlockList().get(0).getText());
        } else {
            mBlogPostView.hideDescription();
        }
    }

    private void initTitle(String label) {
        if (!TextUtils.isEmpty(label)) {
            mBlogPostView.showTitle(mWidget.getBlockList().get(0).getLabel());
        } else {
            mBlogPostView.hideTitle();
        }
    }

    private boolean isActionAvailable(int index) {
        return mWidget.getBlockList() != null &&
                mWidget.getBlockList().get(0) != null &&
                mWidget.getBlockList().get(0).getActionList() != null &&
                index < mWidget.getBlockList().get(0).getActionList().size() &&
                mWidget.getBlockList().get(0).getActionList().get(index).getLink() != null &&
                !TextUtils.isEmpty(mWidget.getBlockList().get(0).getActionList().get(index).getLink());
    }
}
