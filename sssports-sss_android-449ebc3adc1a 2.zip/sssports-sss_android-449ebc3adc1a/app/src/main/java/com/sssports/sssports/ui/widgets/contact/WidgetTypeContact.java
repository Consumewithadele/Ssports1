package com.sssports.sssports.ui.widgets.contact;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.ui.pdp.ProductDetailsActivity;
import com.sssports.sssports.ui.widgets.WidgetType;
import com.sssports.sssports.util.CommonConstants;

import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by natalijaratajac on 8/19/17.
 */

public class WidgetTypeContact implements WidgetType {

    private Activity activity;
    private OnCallClickListener onCallClickListener;

    public WidgetTypeContact(Activity activity) {
        this.activity = activity;
    }

    @Override
    public View buildView() {
        View productDetailsContactView = activity.getLayoutInflater().inflate(R.layout.widget_type_contact, null);
        ButterKnife.bind(this, productDetailsContactView);

        return productDetailsContactView;
    }

    @OnClick(R.id.ll_email)
    public void onEmailClick() {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"customercare@sssports.com"});
        if (intent.resolveActivity(activity.getPackageManager()) != null) {
            activity.startActivity(intent);
        }
    }

    @OnClick(R.id.ll_call)
    public void onCallClick() {
//        ((ProductDetailsActivity) activity).showCallDialog();
        onCallClickListener.onCallClick();
    }

    public void setOnCallClickListener(OnCallClickListener onCallClickListener) {
        this.onCallClickListener = onCallClickListener;
    }

    public interface OnCallClickListener {
        void onCallClick();
    }
}
