package com.sssports.sssports.ui.shoppingbag;

import com.sssports.sssports.models.custom.CartItemViewModel;
import com.sssports.sssports.models.magento.CartItem;

import java.util.List;

/**
 * Created by mlukovic on 8/26/17.
 */

public class ShoppingBagMvpContract {

    public interface View {

        void showCartItemList(List<CartItemViewModel> cartItemList);

        void showCheckoutButton(boolean visible);

        void showLoader(boolean visible);

        void showDeleteCartItemError(CartItemViewModel cartItem);

        void showErrorEmptyMessage();

        void showInternetConnectionErrorMessage();

        void hideOverlayError();

        void showCartItemDeletedMessage(CartItemViewModel cartItem);

        void showAddItemToCartError();

        void updateItem(CartItem cartItem);

        void showWidgets();

        void showErrorItemNotAvailable(CartItem cartItem);

        void showErrorDeletingItem();

        void updateItemDelete(CartItemViewModel cartItemViewModel);

        void refreshSummary();
    }

    public interface Presenter {

        void loadCartItems();

        void onCartItemsReady(List<CartItemViewModel> cartItemList);

        void onGetCartItemsError();

        void onViewDetached();

        void removeItemFromCart(CartItemViewModel cartItem);

        void onDeleteCartItemSuccess(CartItemViewModel cartItem);

        void onDeleteCartItemError(CartItemViewModel cartItem);

        void deleteOneItemToCart(CartItemViewModel cartItemId);

        void addOneItemToCart(CartItem cartItem);

        void noInternetConnection();

        void onAddItemToCartError();

        void onAddItemToCartSuccess(CartItem cartItem);

        void onErrorThereIsNoItem(CartItem cartItem);

        void onDeleteOneItemError(CartItemViewModel cartItemViewModel);

        void onDeleteOneItemSuccess(CartItemViewModel cartItemViewModel);
    }

    public interface Interactor {

        void getCartItems(String cartId);

        void deleteItemFromCart(CartItemViewModel cartItem);

        void addOneItemToCart(CartItem cartItem);

        void deleteOneItemFromCart(CartItemViewModel cartItemViewModel);
    }
}
