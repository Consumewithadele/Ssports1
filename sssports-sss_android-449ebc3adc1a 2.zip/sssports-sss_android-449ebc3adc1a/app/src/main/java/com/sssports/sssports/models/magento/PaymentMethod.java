package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class PaymentMethod {

    @Json(name = "code")
    private String code;
    @Json(name = "title")
    private String title;

    private transient boolean selected;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
