package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

import java.util.List;

/**
 * Created by mlukovic on 9/1/17.
 */

public class CartTotalSummary {

    @Json(name = "grand_total")
    private Double grandTotal;
    @Json(name = "base_grand_total")
    private Double baseGrandTotal;
    @Json(name = "subtotal")
    private Double subtotal;
    @Json(name = "base_subtotal")
    private Double baseSubtotal;
    @Json(name = "discount_amount")
    private Double discountAmount;
    @Json(name = "base_discount_amount")
    private Double baseDiscountAmount;
    @Json(name = "subtotal_with_discount")
    private Double subtotalWithDiscount;
    @Json(name = "base_subtotal_with_discount")
    private Double baseSubtotalWithDiscount;
    @Json(name = "shipping_amount")
    private Double shippingAmount;
    @Json(name = "base_shipping_amount")
    private Double baseShippingAmount;
    @Json(name = "shipping_discount_amount")
    private Double shippingDiscountAmount;
    @Json(name = "base_shipping_discount_amount")
    private Double baseShippingDiscountAmount;
    @Json(name = "tax_amount")
    private Double taxAmount;
    @Json(name = "base_tax_amount")
    private Double baseTaxAmount;
    @Json(name = "shipping_tax_amount")
    private Double shippingTaxAmount;
    @Json(name = "base_shipping_tax_amount")
    private Double baseShippingTaxAmount;
    @Json(name = "subtotal_incl_tax")
    private Double subtotalInclTax;
    @Json(name = "shipping_incl_tax")
    private Double shippingInclTax;
    @Json(name = "base_shipping_incl_tax")
    private Double baseShippingInclTax;
    @Json(name = "base_currency_code")
    private String baseCurrencyCode;
    @Json(name = "quote_currency_code")
    private String quoteCurrencyCode;
    @Json(name = "items_qty")
    private Integer itemsQty;
    @Json(name = "items")
    private List<TotalCartItem> items = null;
    @Json(name = "total_segments")
    private List<TotalSegment> totalSegments = null;

    public Double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getBaseGrandTotal() {
        return baseGrandTotal;
    }

    public void setBaseGrandTotal(Double baseGrandTotal) {
        this.baseGrandTotal = baseGrandTotal;
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(Double subtotal) {
        this.subtotal = subtotal;
    }

    public Double getBaseSubtotal() {
        return baseSubtotal;
    }

    public void setBaseSubtotal(Double baseSubtotal) {
        this.baseSubtotal = baseSubtotal;
    }

    public Double getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(Double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public Double getBaseDiscountAmount() {
        return baseDiscountAmount;
    }

    public void setBaseDiscountAmount(Double baseDiscountAmount) {
        this.baseDiscountAmount = baseDiscountAmount;
    }

    public Double getSubtotalWithDiscount() {
        return subtotalWithDiscount;
    }

    public void setSubtotalWithDiscount(Double subtotalWithDiscount) {
        this.subtotalWithDiscount = subtotalWithDiscount;
    }

    public Double getBaseSubtotalWithDiscount() {
        return baseSubtotalWithDiscount;
    }

    public void setBaseSubtotalWithDiscount(Double baseSubtotalWithDiscount) {
        this.baseSubtotalWithDiscount = baseSubtotalWithDiscount;
    }

    public Double getShippingAmount() {
        return shippingAmount;
    }

    public void setShippingAmount(Double shippingAmount) {
        this.shippingAmount = shippingAmount;
    }

    public Double getBaseShippingAmount() {
        return baseShippingAmount;
    }

    public void setBaseShippingAmount(Double baseShippingAmount) {
        this.baseShippingAmount = baseShippingAmount;
    }

    public Double getShippingDiscountAmount() {
        return shippingDiscountAmount;
    }

    public void setShippingDiscountAmount(Double shippingDiscountAmount) {
        this.shippingDiscountAmount = shippingDiscountAmount;
    }

    public Double getBaseShippingDiscountAmount() {
        return baseShippingDiscountAmount;
    }

    public void setBaseShippingDiscountAmount(Double baseShippingDiscountAmount) {
        this.baseShippingDiscountAmount = baseShippingDiscountAmount;
    }

    public Double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(Double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public Double getBaseTaxAmount() {
        return baseTaxAmount;
    }

    public void setBaseTaxAmount(Double baseTaxAmount) {
        this.baseTaxAmount = baseTaxAmount;
    }

    public Double getShippingTaxAmount() {
        return shippingTaxAmount;
    }

    public void setShippingTaxAmount(Double shippingTaxAmount) {
        this.shippingTaxAmount = shippingTaxAmount;
    }

    public Double getBaseShippingTaxAmount() {
        return baseShippingTaxAmount;
    }

    public void setBaseShippingTaxAmount(Double baseShippingTaxAmount) {
        this.baseShippingTaxAmount = baseShippingTaxAmount;
    }

    public Double getSubtotalInclTax() {
        return subtotalInclTax;
    }

    public void setSubtotalInclTax(Double subtotalInclTax) {
        this.subtotalInclTax = subtotalInclTax;
    }

    public Double getShippingInclTax() {
        return shippingInclTax;
    }

    public void setShippingInclTax(Double shippingInclTax) {
        this.shippingInclTax = shippingInclTax;
    }

    public Double getBaseShippingInclTax() {
        return baseShippingInclTax;
    }

    public void setBaseShippingInclTax(Double baseShippingInclTax) {
        this.baseShippingInclTax = baseShippingInclTax;
    }

    public String getBaseCurrencyCode() {
        return baseCurrencyCode;
    }

    public void setBaseCurrencyCode(String baseCurrencyCode) {
        this.baseCurrencyCode = baseCurrencyCode;
    }

    public String getQuoteCurrencyCode() {
        return quoteCurrencyCode;
    }

    public void setQuoteCurrencyCode(String quoteCurrencyCode) {
        this.quoteCurrencyCode = quoteCurrencyCode;
    }

    public Integer getItemsQty() {
        return itemsQty;
    }

    public void setItemsQty(Integer itemsQty) {
        this.itemsQty = itemsQty;
    }

    public List<TotalCartItem> getItems() {
        return items;
    }

    public void setItems(List<TotalCartItem> items) {
        this.items = items;
    }

    public List<TotalSegment> getTotalSegments() {
        return totalSegments;
    }

    public void setTotalSegments(List<TotalSegment> totalSegments) {
        this.totalSegments = totalSegments;
    }

}

