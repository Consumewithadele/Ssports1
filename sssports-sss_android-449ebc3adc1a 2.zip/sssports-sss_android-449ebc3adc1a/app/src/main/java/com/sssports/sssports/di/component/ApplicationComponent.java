package com.sssports.sssports.di.component;

import android.content.Context;

import com.sssports.sssports.di.modules.AppModule;
import com.sssports.sssports.di.modules.NetModule;
import com.sssports.sssports.locale.SharedPreferenceManager;
import com.sssports.sssports.networking.services.MagentoApi;
import com.sssports.sssports.networking.services.SSSApi;
import com.sssports.sssports.networking.services.SSSApiNotJson;
import com.sssports.sssports.ui.BaseActivity;

import javax.inject.Singleton;

import dagger.Component;
/**
 *  Constraints this component to one-per-application or unscoped bindings.
 */

@Singleton
@Component(modules = {AppModule.class, NetModule.class})
public interface ApplicationComponent {

    void inject(BaseActivity activity);

    //Exposed to sub-graphs.
    Context context();
    SharedPreferenceManager sharedPreferenceManager();
    SSSApi sssService();
    SSSApiNotJson sssServiceNotJson();
    MagentoApi magentoService();
}
