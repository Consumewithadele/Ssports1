package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import moe.banana.jsonapi2.HasMany;
import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

import java.io.Serializable;
import java.util.List;

/**
 * Created by mlukovic on 7/30/17.
 */
@JsonApi(type = "products")
public class Product extends Resource implements Serializable {

    @Json(name = "type_id")
    private String typeId;
    @Json(name = "sku")
    private String sku;
    @Json(name = "created_at")
    private String createdAt;
    @Json(name = "updated_at")
    private String updatedAt;
    @Json(name = "price")
    private Double price;
    @Json(name = "final_price")
    private Double finalPrice;
    @Json(name = "parent_id")
    private String parentId;
    @Json(name = "name")
    private String name;
    @Json(name = "slug")
    private String slug;
    @Json(name = "thumbnail_url")
    private String thumbnailUrl;
    @Json(name = "quantity")
    private Integer quantity;
    @Json(name = "is_available")
    private Boolean isAvailable;
    @Json(name = "currency_code")
    private String currencyCode;
    @Json(name = "formatted_price")
    private String formattedPrice;
    @Json(name = "formatted_final_price")
    private String formattedFinalPrice;
//    @Json(name = "config")
//    private Config config;
    @Json(name = "video_url")
    private String videoUrl;
    @Json(name = "description")
    private String description;
    @Json(name = "on_sale")
    private Boolean onSale;
    @Json(name = "selection_count")
    private Integer selectionCount;
    @Json(name = "color_count")
    private Integer colorCount;
    @Json(name = "top_category_id")
    private Integer topCategoryId;
    @Json(name = "category_name")
    private String categoryName;
    @Json(name = "color_id")
    private Integer colorId;
    @Json(name = "color")
    private String color;
    @Json(name = "is_salable")
    private Boolean isSalable;
    @Json(name = "app_link")
    private String appLink;
    @Json(name = "site_url")
    private String siteUrl;
    @Json(name = "badge_bar")
    private String badgeBar;

    private boolean inWishList;

    //Relationship

    @Json(name = "images")
    private HasMany<ProductImage> images = null;
    @Json(name = "selections")
    private HasMany<Selection> selections = null;
    @Json(name = "children")
    private HasMany<ProductChild> productChildren;
    @Json(name = "config")
    private HasMany<Config> configList;

    public List<ProductImage> getImages() {
        return images.get(getContext());
    }

    public List<Selection> getSelections() {
        return selections.get(getContext());
    }


    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(Double finalPrice) {
        this.finalPrice = finalPrice;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFormattedPrice() {
        return formattedPrice;
    }

    public void setFormattedPrice(String formattedPrice) {
        this.formattedPrice = formattedPrice;
    }

    public String getFormattedFinalPrice() {
        return formattedFinalPrice;
    }

    public void setFormattedFinalPrice(String formattedFinalPrice) {
        this.formattedFinalPrice = formattedFinalPrice;
    }

    public Boolean isOnSale() {
        return onSale;
    }

    public void setOnSale(Boolean onSale) {
        this.onSale = onSale;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getColorCount() {
        return colorCount;
    }

    public void setColorCount(Integer colorCount) {
        this.colorCount = colorCount;
    }

    public Integer getSelectionCount() {
        return selectionCount;
    }

    public void setSelectionCount(Integer selectionCount) {
        this.selectionCount = selectionCount;
    }

    public Boolean getSalable() {
        return isSalable;
    }

    public void setSalable(Boolean salable) {
        isSalable = salable;
    }

    public String getAppLink() {
        return appLink;
    }

    public void setAppLink(String appLink) {
        this.appLink = appLink;
    }

    public void setImages(HasMany<ProductImage> images) {
        this.images = images;
    }

    public void setSelections(HasMany<Selection> selections) {
        this.selections = selections;
    }

    public Boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(Boolean available) {
        isAvailable = available;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Boolean getAvailable() {
        return isAvailable;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public Integer getTopCategoryId() {
        return topCategoryId;
    }

    public void setTopCategoryId(Integer topCategoryId) {
        this.topCategoryId = topCategoryId;
    }

    public Integer getColorId() {
        return colorId;
    }

    public void setColorId(Integer colorId) {
        this.colorId = colorId;
    }

    public String getSiteUrl() {
        return siteUrl;
    }

    public void setSiteUrl(String siteUrl) {
        this.siteUrl = siteUrl;
    }

    public boolean isInWishList() {
        return inWishList;
    }

    public void setInWishList(boolean inWishList) {
        this.inWishList = inWishList;
    }

    public String getBadgeBar() {
        return badgeBar;
    }

    public void setBadgeBar(String badgeBar) {
        this.badgeBar = badgeBar;
    }

    public List<ProductChild> getProductChildren() {
        return productChildren.get(getContext());
    }

    public List<Config> getConfigList() {
        return configList.get(getContext());
    }
}
