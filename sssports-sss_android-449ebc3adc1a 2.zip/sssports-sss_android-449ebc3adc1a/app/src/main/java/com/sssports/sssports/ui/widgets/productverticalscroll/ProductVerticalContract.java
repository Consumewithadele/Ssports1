package com.sssports.sssports.ui.widgets.productverticalscroll;

import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.meta.Page;

import java.util.List;

/**
 * Created by mlukovic on 7/17/17.
 */

public class ProductVerticalContract {

    interface ProductVerticalPresenter {

        void loadProducts();

        void onProductListDataReady(List productList, Page page);
    }

    interface ProductVerticalView {

        void addProductList(List<Product> blockList);

        void showLoader();

        void hideLoader();

        void showTitle(String label);

        void showDescription(String text);
    }

    interface ProductVerticalInteractor {

        void getProductListData(String widgetId, int pageNumber, int pageSize);
    }
}
