package com.sssports.sssports;

import android.app.Application;

import com.crashlytics.android.Crashlytics;
import com.instabug.library.Instabug;
import com.instabug.library.invocation.InstabugInvocationEvent;
import com.sssports.sssports.di.component.ApplicationComponent;
import com.sssports.sssports.di.component.DaggerApplicationComponent;
import com.sssports.sssports.di.modules.AppModule;
import com.sssports.sssports.di.modules.NetModule;
import com.sssports.sssports.locale.SPDataManager;

import io.fabric.sdk.android.Fabric;
import timber.log.Timber;

/*c
 * Created by Adeleclark on 6/29/17.
 */

public class SSSApp extends Application {

    private ApplicationComponent applicationComponent;

    @Override
    public void onCreate() {
        super.onCreate();
        this.initializeLogger();
        this.initLocaleDataManager();
        this.initializeDependencyInjector();
        this.initFabric();
        this.initInstaBug();
    }

    private void initInstaBug() {
        new Instabug.Builder(this, "3e75ddd7b484b01504c1ee845ce94c83")
                .setInvocationEvent(InstabugInvocationEvent.SHAKE)
                .build();
    }

    private void initLocaleDataManager() {
        SPDataManager.INSTANCE.initialize(getApplicationContext());
    }

    private void initFabric() {
        Fabric.with(this, new Crashlytics());
    }

    private void initializeLogger() {
        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        }
    }

    /**
     * //Global dependencies graph is created here
     */
    private void initializeDependencyInjector() {
        this.applicationComponent = DaggerApplicationComponent.builder()
                .appModule(new AppModule(this))
                .netModule(new NetModule())
                .build();
    }

    //Just a helper to provide appComponent to local components which depend on it
    public ApplicationComponent getApplicationComponent() {
        return applicationComponent;
    }
}
