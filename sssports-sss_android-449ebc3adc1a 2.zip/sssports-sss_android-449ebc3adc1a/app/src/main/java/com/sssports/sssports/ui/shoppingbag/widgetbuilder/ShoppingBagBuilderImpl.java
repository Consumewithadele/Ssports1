package com.sssports.sssports.ui.shoppingbag.widgetbuilder;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;

import com.sssports.sssports.ui.checkoutbilling.builder.OnSummaryReadyListener;
import com.sssports.sssports.ui.widgets.checkoutsummary.WidgetTypeOrderSummary;
import com.sssports.sssports.ui.widgets.contact.WidgetTypeContact;
import com.sssports.sssports.ui.widgets.uspbar.WidgetTypeUspBarWithIcons;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public class ShoppingBagBuilderImpl implements ShoppingBagBuilder {

    private LinearLayout productDetailsLayout;
    private WidgetTypeOrderSummary mWidgetTypeOrderSummary;
    private Activity activity;

    public ShoppingBagBuilderImpl(LinearLayout productDetailsLayout, Activity activity) {
        this.productDetailsLayout = productDetailsLayout;
        this.activity = activity;
    }

    @Override
    public void buildCustomerSupportWidget(WidgetTypeContact.OnCallClickListener onCallClickListener) {

        WidgetTypeContact widgetTypeContact = new WidgetTypeContact(activity);
        View contactView = widgetTypeContact.buildView();
        widgetTypeContact.setOnCallClickListener(onCallClickListener);

        productDetailsLayout.addView(contactView);
    }

    @Override
    public void buildProductDetailsUSP() {

        WidgetTypeUspBarWithIcons widgetTypeUspBarWithIcons = new WidgetTypeUspBarWithIcons(activity);
        View uspView = widgetTypeUspBarWithIcons.buildView();

        productDetailsLayout.addView(uspView);
    }

    @Override
    public void buildSummaryDetails(OnSummaryReadyListener onSummaryReadyListener) {
        mWidgetTypeOrderSummary = new WidgetTypeOrderSummary(activity, onSummaryReadyListener);
        View summaryView = mWidgetTypeOrderSummary.buildView();

        // Add margin top programmatically
        float scale = activity.getResources().getDisplayMetrics().density;
        int padding = (int) (15 * scale + 0.5f);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        );
        params.setMargins(0, padding, 0, 0);
        summaryView.setLayoutParams(params);

        productDetailsLayout.addView(summaryView);
    }

    @Override
    public void refreshCheckoutSummary(OnSummaryReadyListener onSummaryReadyListener) {
        if (mWidgetTypeOrderSummary != null) {
            mWidgetTypeOrderSummary.onRefreshSummaryRequested(onSummaryReadyListener);
        }
    }


}
