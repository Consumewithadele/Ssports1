package com.sssports.sssports.ui.widgets.hero;

import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Action;
import com.sssports.sssports.models.jsonapi.Block;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Adapter for Hero Widget with the list of Blocks
 */

public class HeroAdapter extends PagerAdapter {

    private List<Block> mBlockList;
    private Activity mActivity;
    private ActionClickListener mActionClickListener;

    @BindView(R.id.image_view_hero_widget) ImageView imageViewHeroWidget;
    @BindView(R.id.text_view_hero_title) TextView textViewHeroTitle;
    @BindView(R.id.text_view_hero_description) TextView getTextViewHeroDescription;
    @BindView(R.id.btn_call_to_action_1) Button btnCTA1;
    @BindView(R.id.btn_call_to_action_2) Button btnCTA2;

    public HeroAdapter(List<Block> blockList, Activity activity, ActionClickListener actionClickListener) {
        mBlockList = blockList;
        mActivity = activity;
        mActionClickListener = actionClickListener;
    }

    @Override
    public int getCount() {
        if (mBlockList == null) return 0;
        return mBlockList.size();
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        LayoutInflater inflater = LayoutInflater.from(mActivity);
        ViewGroup layout = (ViewGroup) inflater.inflate(R.layout.adapter_hero_widget, container, false);
        ButterKnife.bind(this, layout);

        Block block = mBlockList.get(position);

        if (block == null) return null;

        textViewHeroTitle.setText(block.getLabel());
        getTextViewHeroDescription.setText(block.getText());

        GlideApp.with(mActivity)
                .load(block.getImageUrl())
                .transition(withCrossFade())
                .placeholder(R.drawable.loading_placeholder)
                .error(R.drawable.loading_placeholder)
                .into(imageViewHeroWidget);

        switch (block.getActionList().size()) {
            case 1: {
                Action action1 = block.getActionList().get(0);
                setUpCTAButton(btnCTA1, action1);
                break;
            }
            case 2: {
                Action action1 = block.getActionList().get(0);
                Action action2 = block.getActionList().get(1);
                setUpCTAButton(btnCTA1, action1);
                setUpCTAButton(btnCTA2, action2);
                break;
            }
            default: {
                btnCTA1.setVisibility(View.GONE);
                btnCTA2.setVisibility(View.GONE);
                break;
            }
        }

        container.addView(layout);

        return layout;
    }

    private void setUpCTAButton(Button button, Action action) {
        if (action != null && button != null) {
            button.setVisibility(View.VISIBLE);
            button.setText(action.getText());
            button.setOnClickListener(view -> mActionClickListener.onCTAClicked(action.getLink()));
        }
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void destroyItem(ViewGroup collection, int position, Object view) {
        collection.removeView((View) view);
    }

    interface ActionClickListener {
        void onCTAClicked(String link);
    }
}
