package com.sssports.sssports.ui.widgets.productdetail;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.ProductImage;
import com.sssports.sssports.ui.customviews.TouchImageView;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by natalijaratajac on 8/13/17.
 */

public class ProductDetailAdapter extends PagerAdapter {

    private List<ProductImage> mProductImages;
    private Activity mActivity;

    @BindView(R.id.iv_product_detail_image) TouchImageView ivProductImage;


    public ProductDetailAdapter(List<ProductImage> productImages, Activity activity) {
        mProductImages = productImages;
        mActivity = activity;
    }

    @Override
    public int getCount() {
        if (mProductImages == null) return 0;
        return mProductImages.size();
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        LayoutInflater inflater = LayoutInflater.from(mActivity);
        ViewGroup layout = (ViewGroup) inflater.inflate(R.layout.adapter_product_detail_widget, container, false);
        ButterKnife.bind(this, layout);


        ProductImage productImage = mProductImages.get(position);

        if (productImage == null) return null;

        ProgressBar progressBar = layout.findViewById(R.id.progress_bar_loader);

        GlideApp.with(mActivity)
                .load(productImage.getImage())
                .transition(withCrossFade())
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        progressBar.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        progressBar.setVisibility(View.GONE);
                        return false;
                    }
                })
                .format(DecodeFormat.PREFER_ARGB_8888)
                .placeholder(R.drawable.bg)
                .error(R.drawable.loading_placeholder)
                .into(ivProductImage);

        /**
         * new RequestListener<Bitmap>() {
        @Override
        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Bitmap> target, boolean isFirstResource) {
        progressBar.setVisibility(View.GONE);
        return false;
        }

        @Override
        public boolean onResourceReady(Bitmap resource, Object model, Target<Bitmap> target, DataSource dataSource, boolean isFirstResource) {
        progressBar.setVisibility(View.GONE);
        return false;
        }
        }
         */

        container.addView(layout);

        return layout;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void destroyItem(ViewGroup collection, int position, Object view) {
        collection.removeView((View) view);
    }
}
