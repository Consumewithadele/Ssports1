package com.sssports.sssports.ui.widgets.multiselection;

import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.ProductChild;

import java.util.List;

/**
 * Created by mlukovic on 8/22/17.
 */

public class ProductConfigMvpContract {

    interface View {

        void showProductSizeSelection();

        void showSizeList(List<ProductChild> filteredProductsBySize);

        void showErrorGettingSizeList();

        void showSelectedSize(ProductChild productChild);
    }

    interface Presenter {

        void loadLoadData(Product product);

        void getSizeList();

        void onSizeSelected(ProductChild productChild);
    }
}
