package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import java.io.Serializable;
import java.util.List;

import moe.banana.jsonapi2.HasMany;
import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by mlukovic on 7/23/17.
 */

@JsonApi(type = "widgets")
public class Widget extends Resource implements Serializable{

    @Json(name = "created_at")
    private String createdAt;
    @Json(name = "updated_at")
    private String updatedAt;
    @Json(name = "screen_id")
    private Integer screenId;
    @Json(name = "kind")
    private String kind;
    @Json(name = "sub_type")
    private Integer subType;
    @Json(name = "text")
    private String text;
    @Json(name = "label")
    private String label;

    // Relationship
    @Json(name = "blocks")
    private HasMany<Block> blockList;
    @Json(name = "products")
    private HasMany<Product> productList;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Integer getScreenId() {
        return screenId;
    }

    public void setScreenId(Integer screenId) {
        this.screenId = screenId;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public Integer getSubType() {
        return subType;
    }

    public void setSubType(Integer subType) {
        this.subType = subType;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<Block> getBlockList() {
        return blockList.get(getContext());
    }

    public List<Product> getProductList() {
        return productList.get(getContext());
    }
}
