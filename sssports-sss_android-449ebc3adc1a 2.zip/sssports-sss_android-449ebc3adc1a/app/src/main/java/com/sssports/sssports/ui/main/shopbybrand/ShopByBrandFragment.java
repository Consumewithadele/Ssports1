package com.sssports.sssports.ui.main.shopbybrand;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.hannesdorfmann.mosby3.mvp.MvpFragment;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Brand;
import com.sssports.sssports.ui.customviews.ExpandableHeightGridView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import se.emilsjolander.stickylistheaders.StickyListHeadersListView;

/**
 * A simple {@link Fragment} subclass.
 */
public class ShopByBrandFragment extends MvpFragment<ShopByBrandContract.ShopByBrandFragmentView, ShopByBrandContract.ShopByBrandFragmentPresenter>
        implements ShopByBrandContract.ShopByBrandFragmentView {

    @BindView(R.id.list_view_brandList)
    StickyListHeadersListView brandListListView;

    ExpandableHeightGridView brandLogosGridView;
    @BindView(R.id.loader_shop_by_brand)
    ProgressBar loaderShopByBrand;

    private ShopByBrandContract.ShopByBrandFragmentPresenter shopByBrandFragmentPresenter;

    public static ShopByBrandFragment newInstance() {
        return new ShopByBrandFragment();
    }

    public ShopByBrandFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_shop_by_brand, container, false);


        ButterKnife.bind(this, view);
        DisplayMetrics metrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(metrics);

        addGridViewAsListViewHeader();

        shopByBrandFragmentPresenter = createPresenter();
        shopByBrandFragmentPresenter.loadData();

        return view;
    }

    @Override
    public ShopByBrandContract.ShopByBrandFragmentPresenter createPresenter() {
        return new ShopByBrandPresenterImpl(this, getActivity());
    }

    private void addGridViewAsListViewHeader() {
        View header = getLayoutInflater().inflate(R.layout.layout_gridview, null);
        brandListListView.addHeaderView(header);

        brandLogosGridView = header.findViewById(R.id.grid_view_brand_logos);

        // set expand to show all gridview rows
        brandLogosGridView.setExpanded(true);
    }

    @Override
    public void showBrandList(List<Brand> brandList) {

        BrandAdapter brandAdapter = new BrandAdapter(getActivity(), brandList);
        brandListListView.setAdapter(brandAdapter);

        brandAdapter.setOnInsuranceCompanyClickListener((view, position) -> Toast.makeText(getActivity(), "" + position, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void showBrandLogos(List<Brand> brandList) {

        List<Brand> brandLogoList = new ArrayList<>();

        for (Brand brandItem : brandList) {
            if (!TextUtils.isEmpty(brandItem.getImageUrl())) {
                brandLogoList.add(brandItem);
            }
        }

        brandLogosGridView.setExpanded(true);
        BrandLogoAdapter brandLogoAdapter = new BrandLogoAdapter(brandLogoList, getActivity(), position -> {
            Toast.makeText(getActivity(), "Action click on brand logo" + position, Toast.LENGTH_SHORT).show();
        });
        brandLogosGridView.setAdapter(brandLogoAdapter);
    }

    @Override
    public void showLoading() {
        loaderShopByBrand.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loaderShopByBrand.setVisibility(View.GONE);
    }

    @Override
    public void showError() {

    }
}
