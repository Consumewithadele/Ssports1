package com.sssports.sssports.ui.checkoutbilling;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.jsonapi.Region;
import com.sssports.sssports.models.magento.PaymentMethod;
import com.sssports.sssports.models.magento.ShippingMethod;
import com.sssports.sssports.models.magento.TotalSegment;
import com.sssports.sssports.ui.BaseActivity;
import com.sssports.sssports.ui.checkoutbilling.builder.CheckoutBillingDirector;
import com.sssports.sssports.ui.checkoutbilling.builder.CheckoutBillingDirectorImpl;
import com.sssports.sssports.ui.checkoutbilling.builder.OnSummaryReadyListener;
import com.sssports.sssports.ui.customviews.CustomDialog;
import com.sssports.sssports.ui.customviews.ExpirationDatePickerDialog;
import com.sssports.sssports.ui.customviews.MovableButton;
import com.sssports.sssports.util.CommonConstants;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class CheckoutBillingActivity extends BaseActivity implements CheckoutBillingContract.CheckoutBillingView, DatePickerDialog.OnDateSetListener, OnSummaryReadyListener{

    @BindView(R.id.checkout_billing_toolbar) Toolbar toolbar;
    @BindView(R.id.loader_checkout_billing) ProgressBar loader;
    @BindView(R.id.ll_checkout_billing) LinearLayout llCheckoutBilling;
    @BindView(R.id.tv_buy) MovableButton tvBuy;
    @BindView(R.id.tv_edit_shipping_address) TextView tvEditShippingAddress;
//    @BindView(R.id.rl_cash_on_delivery) RelativeLayout rlCashOnDelivery;
//    @BindView(R.id.iv_check_mark_cash_on_delivery) ImageView ivCashOnDeliveryCheckmark;
//    @BindView(R.id.rl_credit_card) RelativeLayout rlCreditCard;
//    @BindView(R.id.iv_check_mark_credit_card) ImageView ivCreditCardCheckmark;
    @BindView(R.id.ll_card_details) LinearLayout llCardDetails;
    @BindView(R.id.et_card_number) EditText etCardNumber;
    @BindView(R.id.ti_card_number) TextInputLayout tiCardNumber;
    @BindView(R.id.et_card_holder) EditText etCardHolder;
    @BindView(R.id.ti_card_holder) TextInputLayout tiCardHolder;
    @BindView(R.id.et_expiration_date) TextView etExpirationDate;
    @BindView(R.id.et_cvv) EditText etCvv;
    @BindView(R.id.rl_same_as_shipping_address) RelativeLayout rlSameAsShippingAddress;
    @BindView(R.id.rl_use_different_billing_address) RelativeLayout rlUseDifferentBillingAddress;
    @BindView(R.id.iv_same_as_shipping) ImageView ivUseTheSame;
    @BindView(R.id.iv_use_different) ImageView ivUseDifferent;
    @BindView(R.id.ll_billing_and_shipping_address) LinearLayout llBillingAddress;
    @BindView(R.id.et_address) EditText etAddress;
    @BindView(R.id.et_po_box) EditText etPoBox;
    @BindView(R.id.et_phone_number) EditText etPhoneNumber;
    @BindView(R.id.ti_phone_number) TextInputLayout tiPhoneNumber;
    @BindView(R.id.spinner_country) Spinner spinnerCountry;
    @BindView(R.id.spinner_city) Spinner spinnerCity;
    @BindView(R.id.rv_shipping_methods) RecyclerView rvShippingMethods;
    @BindView(R.id.rv_payment_methods) RecyclerView rvPaymentMethods;

    private CheckoutBillingContract.CheckoutBillingPresenter presenter;
    private int mExpirationYear;
    private int mExpirationMonth;
    private boolean saveData;
    private ArrayList<ShippingMethod> shippingMethods;
    private AdapterShippingMethod adapterShippingMethod;
    private AdapterPaymentMethod adapterPaymentMethod;
    private CustomDialog mLoaderDialog;
    private CheckoutBillingDirector mCheckoutBillingDirector;
    // Change this to what you want... ' ', '-' etc..
    private static final char space = ' ';


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_billing);

        ButterKnife.bind(this);

        shippingMethods = (ArrayList<ShippingMethod>) getIntent().getSerializableExtra(CommonConstants.INTENT_AVAILABLE_SHIPPING_METHODS);
        saveData = getIntent().getBooleanExtra(CommonConstants.INTENT_SAVE_DATA, false);

        presenter = new CheckoutBillingPresenterImpl(this, CheckoutBillingActivity.this, shippingMethods, saveData);

        setupEtCardNumber();
        setupEtCardHolder();
        setupEtCvv();
        setBillingAddressUseSame();
        setupEtAddress();
        setupEtPoBox();
        setupEtPhoneNumber();

        setToolbar();

        presenter.loadData();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void setToolbar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    private void setupEtCardNumber() {
        etCardNumber.setCompoundDrawablesRelativeWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_creditcard), null, null, null);
        etCardNumber.setCompoundDrawablePadding(30);
        etCardNumber.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setCardNumber(s.toString().replace(" ", ""));
                presenter.findCardIcon(s.toString().replace(" ", ""));
                hideCardNumberErrorMessage();
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Remove spacing char
                if (s.length() > 0 && (s.length() % 5) == 0) {
                    final char c = s.charAt(s.length() - 1);
                    if (space == c) {
                        s.delete(s.length() - 1, s.length());
                    }
                }
                // Insert char where needed.
                if (s.length() > 0 && (s.length() % 5) == 0) {
                    char c = s.charAt(s.length() - 1);
                    // Only if its a digit where there should be a space we insert a space
                    if (Character.isDigit(c) && TextUtils.split(s.toString(), String.valueOf(space)).length <= 3) {
                        s.insert(s.length() - 1, String.valueOf(space));
                    }
                }
            }
        });
    }

    private void setupEtCardHolder() {
        etCardHolder.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setCardHolder(s.toString());
                hideCardHolderNameError();
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void hideCardHolderNameError() {
        if (tiCardHolder.isErrorEnabled()) {
            tiCardHolder.setError(null);
        }
    }

    private void setupEtCvv() {
        etCvv.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setCvv(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupCityDropDownList(List<Region> regions) {
        if (regions == null || regions.isEmpty()) {
            hideRegionDropDown();
            return;
        }

        showRegionDropDown();
        ArrayAdapter<Region> cityAdapter = new ArrayAdapter<>(this, R.layout.spinner_shipping_adress_item, regions);
        cityAdapter.setDropDownViewResource(R.layout.spinner_category_dropdown_item);
        spinnerCity.setAdapter(cityAdapter);
        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                presenter.setRegion(regions.get(i).getName());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @Override
    public void initializeShippingMethodAdapter() {
        if (shippingMethods != null && !shippingMethods.isEmpty()) {
            shippingMethods.get(0).setSelected(true);
        }

//        TODO delete
//        shippingMethods.add(new ShippingMethod());
//        shippingMethods.add(new ShippingMethod());

        adapterShippingMethod = new AdapterShippingMethod(shippingMethods, CheckoutBillingActivity.this);

        adapterShippingMethod.setOnShippingMethodClick((view, position) -> {
            for(ShippingMethod sm: shippingMethods) {
                sm.setSelected(false);
            }
            shippingMethods.get(position).setSelected(true);
            adapterShippingMethod.notifyDataSetChanged();
            presenter.setChosenShippingMethod(shippingMethods.get(position));
            //TODO See how to send shipping method
//            mCheckoutBillingDirector.refreshSummary(this);
        });

        LinearLayoutManager llManager = new LinearLayoutManager(CheckoutBillingActivity.this, LinearLayoutManager.VERTICAL, false);

        rvShippingMethods.setLayoutManager(llManager);
        rvShippingMethods.setAdapter(adapterShippingMethod);
    }

    @Override
    public void initializePaymentMethodAdapter() {
        List<PaymentMethod> paymentMethods = presenter.getPaymentMethods();
        if (paymentMethods != null && !paymentMethods.isEmpty()) {
            setPaymentMethod(paymentMethods.get(0));
        }

        adapterPaymentMethod = new AdapterPaymentMethod(paymentMethods, CheckoutBillingActivity.this);

        adapterPaymentMethod.setOnPaymentMethodClick((view, position) -> {
            for(PaymentMethod pm: paymentMethods) {
                pm.setSelected(false);
            }
            setPaymentMethod(paymentMethods.get(position));
            adapterPaymentMethod.notifyDataSetChanged();
            presenter.sendPaymentMethod(paymentMethods.get(position));
        });

        LinearLayoutManager llManager = new LinearLayoutManager(CheckoutBillingActivity.this, LinearLayoutManager.VERTICAL, false);

        rvPaymentMethods.setLayoutManager(llManager);
        rvPaymentMethods.setAdapter(adapterPaymentMethod);
    }

    @Override
    public void initializeWidgetForSummary() {
        mCheckoutBillingDirector = new CheckoutBillingDirectorImpl(llCheckoutBilling, this);
        mCheckoutBillingDirector.construct(this);
    }

    private void setPaymentMethod(PaymentMethod paymentMethod) {
        paymentMethod.setSelected(true);
        presenter.setChosenPaymentMethod(paymentMethod);
        if (paymentMethod.getCode().equalsIgnoreCase(CommonConstants.CASH_ON_DELIVERY_PAYMENT)) {
            hideCardDetails();
        } else {
            showCardDetails();
        }
    }

    @Override
    public void setupCountryDropDownList(List<Country> countryList) {
        if (countryList == null || countryList.isEmpty()) {
            hideCountryDropDown();
            return;
        }

        showCountryDropDown();
        ArrayAdapter<Country> countryAdapter = new ArrayAdapter<>(this, R.layout.spinner_shipping_adress_item, countryList);
        countryAdapter.setDropDownViewResource(R.layout.spinner_category_dropdown_item);
        spinnerCountry.setAdapter(countryAdapter);
        spinnerCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                presenter.setCountry(countryList.get(i).getCode().toUpperCase(), countryList.get(i).getName());
                setupCityDropDownList(countryList.get(i).getRegionList());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        int positionCountry = countryList.indexOf(new Country(SPDataManager.INSTANCE.getCountry()));
        spinnerCountry.setSelection(positionCountry);
    }

    private void setupEtPhoneNumber() {
        etPhoneNumber.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setPhoneNumber(s.toString());
                hidePhoneNumberErrorMessage();
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupEtPoBox() {
        etPoBox.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setPoBox(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupEtAddress() {
        etAddress.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.setAddress(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    @Override
    public void setShippingAddress(String shippingAddress) {
        tvEditShippingAddress.setText(shippingAddress);
    }

//    @Override
//    public void setCashOnDeliveryPaymentMethod() {
//        rlCashOnDelivery.setBackground(getResources().getDrawable(R.drawable.rectangle_vd));
//        showCashOnDeliveryCheckmark();
//        rlCreditCard.setBackgroundColor(getResources().getColor(R.color.munsell));
//        hideCardCheckmark();
//        hideCardDetails();
//    }
//
//    @Override
//    public void setCadsPaymentMethod() {
//        rlCashOnDelivery.setBackgroundColor(getResources().getColor(R.color.munsell));
//        hideCashOnDeliveryCheckmark();
//        rlCreditCard.setBackground(getResources().getDrawable(R.drawable.rectangle_vd));
//        showCardCheckmark();
//        showCardDetails();
//    }

    @Override
    public void setCardIconVisa() {
        etCardNumber.setCompoundDrawablesRelativeWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_visa), null, null, null);
    }

    @Override
    public void setCardIconMasterCard() {
        etCardNumber.setCompoundDrawablesRelativeWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_master), null, null, null);
//        ivCardIcon.setImageResource(R.drawable.ic_master);
    }

    @Override
    public void setCardIconAmericanExpress() {
//        ivCardIcon.setImageResource(R.drawable.ic_american);
    }

    @Override
    public void setCardIconDinersClub() {
//        ivCardIcon.setImageResource(R.drawable.ic_dinnersclub);
    }

    @Override
    public void setCardIconDiscover() {
//        ivCardIcon.setImageResource(R.drawable.ic_discover);
    }

    @Override
    public void setCardIconJCB() {
//        ivCardIcon.setImageResource(R.drawable.ic_jcb);
    }

    @Override
    public void setDefaultCardIcon() {
        etCardNumber.setCompoundDrawablesRelativeWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_creditcard), null, null, null);
//        ivCardIcon.setImageResource(R.drawable.ic_cc);
    }

//    private void showCashOnDeliveryCheckmark() {
//        ivCashOnDeliveryCheckmark.setVisibility(View.VISIBLE);
//    }
//
//    private void hideCashOnDeliveryCheckmark() {
//        ivCashOnDeliveryCheckmark.setVisibility(View.INVISIBLE);
//    }
//
//    private void showCardCheckmark() {
//        ivCreditCardCheckmark.setVisibility(View.VISIBLE);
//    }
//
//    private void hideCardCheckmark() {
//        ivCreditCardCheckmark.setVisibility(View.INVISIBLE);
//    }

    @Override
    public void showCardDetails() {
        llCardDetails.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideCardDetails() {
        llCardDetails.setVisibility(View.GONE);
    }

    private void setBillingAddressUseSame() {
        ivUseTheSame.setImageResource(R.drawable.ic_radio_active);
        ivUseDifferent.setImageResource(R.drawable.ic_radio_default);
        hideBillingAddressFields();
//        presenter.setBillingAddressSameAsShipping();
    }

    private void setBillingAddressUseDifferent() {
        ivUseTheSame.setImageResource(R.drawable.ic_radio_default);
        ivUseDifferent.setImageResource(R.drawable.ic_radio_active);
        showBillingAddressFields();
    }

    private void showBillingAddressFields () {
        llBillingAddress.setVisibility(View.VISIBLE);
    }

    private void hideBillingAddressFields() {
        llBillingAddress.setVisibility(View.GONE);
    }

    public void showCountryDropDown() {
        spinnerCountry.setVisibility(View.VISIBLE);
    }

    public void hideCountryDropDown() {
        spinnerCountry.setVisibility(View.GONE);
    }

    public void showRegionDropDown() {
        spinnerCity.setVisibility(View.VISIBLE);
    }

    public void hideRegionDropDown() {
        spinnerCity.setVisibility(View.GONE);
    }

    @Override
    public void showScreen() {
        llCheckoutBilling.setVisibility(View.VISIBLE);
        tvBuy.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideScreen() {
        llCheckoutBilling.setVisibility(View.GONE);
        tvBuy.setVisibility(View.GONE);
    }

    @Override
    public void showCardNumberErrorMessage() {
        tiCardNumber.setErrorEnabled(true);
        tiCardNumber.setError(getResources().getString(R.string.error_invalid_credit_card_type));
    }

    @Override
    public void hideCardNumberErrorMessage() {
        if (tiCardNumber.isErrorEnabled()) {
            tiCardNumber.setError(null);
        }
    }

    @Override
    public void showPhoneNumberErrorMessage() {
        tiPhoneNumber.setErrorEnabled(true);
        tiPhoneNumber.setError(getResources().getString(R.string.error_invalid_phone_number));
    }

    @Override
    public void hidePhoneNumberErrorMessage() {
        if (tiPhoneNumber.isErrorEnabled()) {
            tiPhoneNumber.setError(null);
        }
    }

    @Override
    public void showLoading() {
        loader.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loader.setVisibility(View.GONE);
    }

    @Override
    public void disableBuyButton() {
        tvBuy.setClickable(false);
        tvBuy.setBackgroundColor(getResources().getColor(R.color.medium_grey));
    }

    @Override
    public void enableBuyButton() {
        tvBuy.setClickable(true);
        tvBuy.setBackgroundColor(getResources().getColor(R.color.orange));
    }

    @Override
    public void showSnackBarPleaseFillAllData() {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.checkout_billing_scroll_view), getResources().getString(R.string.please_fill_all_data), Snackbar.LENGTH_SHORT);
        View view = snackbar.getView();
        view.setBackgroundColor(ContextCompat.getColor(CheckoutBillingActivity.this, R.color.dark_grey));
        snackbar.show();
    }

    @Override
    public void showLoaderDialog() {
        mLoaderDialog = new CustomDialog(CheckoutBillingActivity.this, CommonConstants.DIALOG_LOADER);
        mLoaderDialog.setTitle(getResources().getString(R.string.checkout_submiting_order_text));
        mLoaderDialog.show();
    }

    @Override
    public void hideLoaderDialog() {
        if (mLoaderDialog != null)
            mLoaderDialog.cancel();
    }

    @Override
    public void openNextScreen(String orderNumber) {
        navigator.navigateToThankYouScreen(this, orderNumber);
    }

    @Override
    public void showPlacingOrderError() {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.checkout_billing_scroll_view), getResources().getString(R.string.error_placing_order), Snackbar.LENGTH_SHORT);
        View view = snackbar.getView();
        view.setBackgroundColor(ContextCompat.getColor(CheckoutBillingActivity.this, R.color.dark_grey));
        snackbar.show();
    }

    @Override
    public void showErrorDialog() {
        new CustomDialog(CheckoutBillingActivity.this, CommonConstants.DIALOG_ONE_BUTTON)
                .setTitle(getString(R.string.error))
                .setContentText(getString(R.string.error_placing_order))
                .show();
    }

    @Override
    public void refreshSummary() {
        mCheckoutBillingDirector.refreshSummary(this);
    }

    @Override
    public void showCardHolderError() {
        tiCardHolder.setErrorEnabled(true);
        tiCardHolder.setError("Please enter a full name");
    }

    @OnClick(R.id.rl_edit_shipping_address)
    public void editShippingAddressClick() {
        finish();
    }

    @OnClick(R.id.rl_same_as_shipping_address)
    public void onSameAsShippingAddressClick() {
        setBillingAddressUseSame();
        presenter.setSameAsShippingAddressSelected(true);
    }

    @OnClick(R.id.rl_use_different_billing_address)
    public void onUseDifferentBillingAddressClick() {
        setBillingAddressUseDifferent();
        presenter.setSameAsShippingAddressSelected(false);
    }

    @OnClick(R.id.tv_buy)
    public void onBuyClick() {
        presenter.buyItems();
    }

    @OnClick(R.id.et_expiration_date)
    public void onExpirationDateClick() {
        ExpirationDatePickerDialog expirationDatePickerDialog  = new ExpirationDatePickerDialog(this, this, mExpirationYear, mExpirationMonth, 0);
        expirationDatePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        mExpirationYear = year;
        mExpirationMonth = month + 1;

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.MONTH, month);
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.DAY_OF_MONTH, day);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(getResources().getString(R.string.cart_expiration_date_pattern),  Locale.ENGLISH);

        String formattedDate = simpleDateFormat.format(cal.getTime());

        etExpirationDate.setText(formattedDate);
        presenter.setExpirationMonth(month + 1);
        presenter.setExpirationYear(year);
    }

    @Override
    public void onSummaryReady(List<TotalSegment> totalSegmentList) {
        presenter.setTotalAmountSegmentList(totalSegmentList);
    }

    @Override
    public void onSummaryError() {
        presenter.onRefreshSummaryError();
    }
}
