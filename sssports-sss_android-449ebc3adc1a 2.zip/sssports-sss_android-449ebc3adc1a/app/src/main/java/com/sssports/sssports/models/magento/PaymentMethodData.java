package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by natalijaratajac on 9/4/17.
 */

public class PaymentMethodData {

    @Json(name = "method")
    private PaymentData paymentData;

    public PaymentData getPaymentData() {
        return paymentData;
    }

    public void setPaymentData(PaymentData paymentData) {
        this.paymentData = paymentData;
    }
}
