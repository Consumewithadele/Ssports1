package com.sssports.sssports.ui.checkoutbilling.builder;

import com.sssports.sssports.models.magento.TotalSegment;

import java.util.List;

/**
 * Created by mlukovic on 9/17/17.
 */

public interface OnSummaryReadyListener {
    void onSummaryReady(List<TotalSegment> totalSegmentList);

    void onSummaryError();
}
