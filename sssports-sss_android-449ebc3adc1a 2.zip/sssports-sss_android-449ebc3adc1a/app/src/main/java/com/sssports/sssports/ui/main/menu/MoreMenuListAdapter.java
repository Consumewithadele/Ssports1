package com.sssports.sssports.ui.main.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.custom.MenuItem;

import java.util.List;

/**
 * Created by mlukovic on 8/15/17.
 */

public class MoreMenuListAdapter extends BaseAdapter {

    private List<MenuItem> mMenuItemList;
    private Context mContext;
    private OnMenuItemClickListener mOnMenuItemClickListener;

    public MoreMenuListAdapter(Context context, List<MenuItem> menuItemHashMap, OnMenuItemClickListener onMenuItemClickListener) {
        mMenuItemList = menuItemHashMap;
        mContext = context;
        mOnMenuItemClickListener = onMenuItemClickListener;
    }

    @Override
    public int getCount() {
        return mMenuItemList.size();
    }

    @Override
    public Object getItem(int i) {
        return mMenuItemList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {

            convertView = inflater.inflate(R.layout.adapter_more_menu_item, parent, false);

            ImageView iconImage = convertView.findViewById(R.id.iv_menu_icon);
            TextView menuItemLabel = convertView.findViewById(R.id.tv_menu_item_label);

            MenuItem menuItem = mMenuItemList.get(position);

            iconImage.setImageResource(menuItem.getIcon());
            menuItemLabel.setText(menuItem.getLabel());

            convertView.setOnClickListener(view -> mOnMenuItemClickListener.onClick(mMenuItemList.get(position).getCode()));

        }
        return convertView;
    }

    public interface OnMenuItemClickListener {
        void onClick(String menuItemCode);
    }
}
