package com.sssports.sssports.ui.pdp.builder;

import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.ui.widgets.contact.WidgetTypeContact;
import com.sssports.sssports.ui.widgets.productdetail.ProductDetailListener;

/**
 * Created by Adeleclark on 8/8/17.
 */

public interface ProductDetailsBuilder {

    void buildProductDetail(Product product, ProductDetailListener productDetailListener);

    void buildProductDetailsContact(Product product, WidgetTypeContact.OnCallClickListener onCallClickListener);

    void buildProductDetailsUSP();

    void buildProductDetailsTwoTabs(Product product);

    void buildProductDetailsShopAll(Product product);
}
