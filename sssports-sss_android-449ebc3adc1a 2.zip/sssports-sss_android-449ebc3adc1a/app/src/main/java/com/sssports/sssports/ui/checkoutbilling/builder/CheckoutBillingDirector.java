package com.sssports.sssports.ui.checkoutbilling.builder;

/**
 * Created by mlukovic on 9/1/17.
 */

public interface CheckoutBillingDirector {

    void construct(OnSummaryReadyListener onSummaryReadyListener);

    void refreshSummary(OnSummaryReadyListener onSummaryReadyListener);
}
