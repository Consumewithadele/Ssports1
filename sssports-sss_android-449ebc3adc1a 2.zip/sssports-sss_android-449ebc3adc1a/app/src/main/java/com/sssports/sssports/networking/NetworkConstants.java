package com.sssports.sssports.networking;

import com.sssports.sssports.BuildConfig;

/**
 * Created by Adeleclark on 8/29/17.
 */

public class NetworkConstants {

    public static final String SEARCH_FORMAT_RESPONSE_JSON_FULL = "json-full";
    public static final String MAGENTO_AUTH = BuildConfig.MAGENTO_AUTH;

    public static class HttpCode {
        public static final int HTTP_400 = 400;
        public static final int HTTP_404 = 404;
    }
}
