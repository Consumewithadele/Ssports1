package com.sssports.sssports.ui.checkoutbilling;

/**
 * Created by mlukovic on 9/5/17.
 */

public interface CheckoutBillingListener {

    void onSummaryChanged();

}
