package com.sssports.sssports.di.modules;

import android.app.Activity;

import com.sssports.sssports.di.PerActivity;

import dagger.Module;
import dagger.Provides;

/**
 * This module exposes the activity to dependents in the graph.
 * The reason behind this is basically to use the activity context in a fragment, for example.
 */
@Module
public class ActivityModule {

    private final Activity activity;

    public ActivityModule(Activity activity) {
        this.activity = activity;
    }

    @Provides
    @PerActivity
    Activity activity() {
        return this.activity;
    }
}
