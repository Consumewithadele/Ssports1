package com.sssports.sssports.models.view;

import com.sssports.sssports.models.jsonapi.Product;

/**
 * Created by mlukovic on 8/24/17.
 */

public class SizeOptionViewModel {

    private int optionId;
    private int sortOrder;
    private String label;
    private Product product;

    public int getOptionId() {
        return optionId;
    }

    public void setOptionId(int optionId) {
        this.optionId = optionId;
    }

    public int getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(int sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
