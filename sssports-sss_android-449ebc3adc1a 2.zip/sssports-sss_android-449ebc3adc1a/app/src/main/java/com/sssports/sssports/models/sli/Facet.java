
package com.sssports.sssports.models.sli;

import java.util.List;
import com.squareup.moshi.Json;

public class Facet {

    @Json(name = "id")
    private String id;
    @Json(name = "name")
    private String name;
    @Json(name = "total_count")
    private Integer totalCount;
    @Json(name = "values")
    private List<Value> values = null;
    @Json(name = "parent_id")
    private String parentId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public List<Value> getValues() {
        return values;
    }

    public void setValues(List<Value> values) {
        this.values = values;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

}
