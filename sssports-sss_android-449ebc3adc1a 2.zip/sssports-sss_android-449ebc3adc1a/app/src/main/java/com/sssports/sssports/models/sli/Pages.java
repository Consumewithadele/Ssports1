
package com.sssports.sssports.models.sli;

import com.squareup.moshi.Json;

public class Pages {

    @Json(name = "total")
    private Integer total;
    @Json(name = "current")
    private Current current;
    @Json(name = "next")
    private Next next;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Current getCurrent() {
        return current;
    }

    public void setCurrent(Current current) {
        this.current = current;
    }

    public Next getNext() {
        return next;
    }

    public void setNext(Next next) {
        this.next = next;
    }

}
