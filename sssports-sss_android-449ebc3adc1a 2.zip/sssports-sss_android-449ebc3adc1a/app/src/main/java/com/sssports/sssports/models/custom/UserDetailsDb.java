package com.sssports.sssports.models.custom;

import com.sssports.sssports.models.magento.UserDetailsDto;

/**
 * Created by natalijaratajac on 9/3/17.
 */

public class UserDetailsDb extends UserDetailsDto {

    private String countryName;

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
}
