package com.sssports.sssports.ui.widgets.checkoutsummary;

import com.sssports.sssports.models.magento.CartTotalSummary;
import com.sssports.sssports.models.magento.TotalSegment;

import java.util.List;

/**
 * Created by mlukovic on 9/1/17.
 */

public class SummaryMvpContract {

    interface View {

        void showSummary(List<TotalSegment> items, String baseCurrencyCode);

        void showErrorSummary();

        void showLoader(boolean visible);
    }

    interface Presenter {

        void loadSummary();

        void onSummaryDataReady(CartTotalSummary body);

        void onViewDetached();

        void onSummaryDataError();
    }

    interface Interactor {

        void getSummaryTotalList(String cartId);
    }
}
