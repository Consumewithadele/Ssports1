package com.sssports.sssports.ui.main.filter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Option;

import java.util.List;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by mlukovic on 8/8/17.
 */

public class FilterOptionListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final String FILTER_COLOR = "color";

    private List<Option> mOptionList;
    private OnOptionClickListener mOnOptionClickListener;
    private String mAttributeCode;
    private Context mContext;

    public FilterOptionListAdapter(Context context, OnOptionClickListener onOptionClickListener) {
        mContext = context;
        mOnOptionClickListener = onOptionClickListener;

    }

    public void addAttribute(Attribute attribute) {
        if (attribute != null) {
            mOptionList = attribute.getOptionList();
            mAttributeCode = attribute.getAttributeCode();
            notifyDataSetChanged();
        }
    }


    class OptionViewHolder extends RecyclerView.ViewHolder {

        public TextView optionName;
        public ImageView checkImage;
        public ImageView colorView;

        public OptionViewHolder(View itemView) {
            super(itemView);
            this.optionName = itemView.findViewById(R.id.option_name);
            this.checkImage = itemView.findViewById(R.id.check_image);
            this.colorView = itemView.findViewById(R.id.color_view);
            itemView.setOnClickListener(view -> {
                mOnOptionClickListener.onClick(mOptionList.get(getAdapterPosition()));
                Option option = mOptionList.get(getAdapterPosition());
                boolean isSelected = option.isSelected();
                option.setSelected(!isSelected);
                notifyItemChanged(getAdapterPosition());
            });
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_filter_option_item, parent, false);
        return new FilterOptionListAdapter.OptionViewHolder(v);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        OptionViewHolder optionViewHolder = (OptionViewHolder) holder;
        Option option = mOptionList.get(position);
        optionViewHolder.optionName.setText(option.getLabel());
        optionViewHolder.checkImage.setVisibility(option.isSelected() ? View.VISIBLE : View.INVISIBLE);

        if (mAttributeCode != null && mAttributeCode.equalsIgnoreCase(FILTER_COLOR)) {
            if (!TextUtils.isEmpty(option.getHexUrl())) {

                GlideApp.with(optionViewHolder.colorView.getContext())
                        .load(option.getHexUrl())
                        .transition(withCrossFade())
                        .placeholder(R.drawable.loading_placeholder)
                        .error(R.drawable.ic_color_unavailable)
                        .into(optionViewHolder.colorView);

                optionViewHolder.colorView.setVisibility(View.VISIBLE);
            } else if (!TextUtils.isEmpty(option.getHex())) {
                optionViewHolder.colorView.setBackgroundColor(Color.parseColor(option.getHex()));
                optionViewHolder.colorView.setImageResource(0);
                optionViewHolder.colorView.setVisibility(View.VISIBLE);
            } else {
                optionViewHolder.colorView.setBackgroundColor(mContext.getResources().getColor(R.color.white));
                optionViewHolder.colorView.setImageResource(R.drawable.ic_color_unavailable);
                optionViewHolder.colorView.setVisibility(View.VISIBLE);
            }
        } else {
            optionViewHolder.colorView.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        if (mOptionList == null) return 0;
        return mOptionList.size();
    }

    interface OnOptionClickListener {
        void onClick(Option option);
    }
}
