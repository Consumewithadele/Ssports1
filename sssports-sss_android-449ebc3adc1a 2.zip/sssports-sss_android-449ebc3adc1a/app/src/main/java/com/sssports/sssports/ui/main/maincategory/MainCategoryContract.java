package com.sssports.sssports.ui.main.maincategory;

import com.sssports.sssports.models.jsonapi.Block;

import java.util.List;

/**
 * Contract for implementing MVP pattern for Main Category Screen
 */

public class MainCategoryContract {

    interface MainCategoryView {

        void showCategoryList(List<Block> blockList);

        void showLoading(boolean visible);

        void showError();
    }

    interface MainCategoryPresenter {

        void loadData();

    }

}
