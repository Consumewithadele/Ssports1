package com.sssports.sssports.ui.widgets.productdetail;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.ProductChild;

import java.util.List;

/**
 * Created by mlukovic on 8/20/17.
 */

public class SizeListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>  {


    private List<ProductChild> mProductChildren;
    private OnOptionClickListener mOnOptionClickListener;

    public SizeListAdapter(List<ProductChild> productChildren, OnOptionClickListener onOptionClickListener) {
        mProductChildren = productChildren;
        mOnOptionClickListener = onOptionClickListener;
    }

    public class SizeItemViewHolder extends RecyclerView.ViewHolder {

        TextView textSize;
        TextView textSoldOut;

        public SizeItemViewHolder(View itemView) {
            super(itemView);
            textSize = itemView.findViewById(R.id.option_label);
            textSoldOut = itemView.findViewById(R.id.out_of_stock_label);
            itemView.setOnClickListener(view -> {
                ProductChild productChild = mProductChildren.get(getAdapterPosition());
                if (productChild.getIsAvailable()) {
                    mOnOptionClickListener.onAvailableOptionClick(productChild);
                } else {
                    mOnOptionClickListener.onUnavailableOptionClick();
                }
            });
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_size_item, parent, false);
        return new SizeItemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        SizeItemViewHolder sizeItemViewHolder = (SizeItemViewHolder) holder;
        ProductChild productChild = mProductChildren.get(position);

        if (productChild.getIsAvailable()) {
            sizeItemViewHolder.textSoldOut.setVisibility(View.GONE);
        } else {
            sizeItemViewHolder.textSoldOut.setVisibility(View.VISIBLE);
        }

        sizeItemViewHolder.textSize.setText(productChild.getSizeLabel());

    }

    @Override
    public int getItemCount() {
        if (mProductChildren == null) return 0;
        return mProductChildren.size();
    }

    interface OnOptionClickListener {

        void onAvailableOptionClick(ProductChild productChild);

        void onUnavailableOptionClick();
    }
}
