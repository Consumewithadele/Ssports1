package com.sssports.sssports.ui.main.filter;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.crystal.crystalrangeseekbar.widgets.CrystalRangeSeekbar;
import com.hannesdorfmann.mosby3.mvp.MvpFragment;
import com.sssports.sssports.R;
import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.meta.Pricing;
import com.sssports.sssports.ui.main.MainScreenListener;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import se.emilsjolander.stickylistheaders.StickyListHeadersListView;

/**
 * Created by mlukovic on 8/7/17.
 */

public class FilterListFragment extends MvpFragment<FilterMVPContract.View, FilterMVPContract.Presenter> implements FilterMVPContract.View {

    private static final String ARG_CATEGORY = "category_filter";
    private static final String ARG_PRACING = "pricing_filter";
    private MainScreenListener mMainScreenListener;
    private String mCategoryId;
    private FilterAttributeListAdapter mFilterListAdapter;
    private FilterOptionListAdapter mFilterOptionListAdapter;
    private BrandOptionListAdapter mBrandOptionListAdapter;

    @BindView(R.id.filter_attribute_list) RecyclerView mFilterListView;
    @BindView(R.id.filter_option_list) RecyclerView mFilterOptionListView;
    @BindView(R.id.filter_brand_list) StickyListHeadersListView mBrandListView;
    @BindView(R.id.filter_title) TextView tvFilterTitle;
    @BindView(R.id.filter_back_image) ImageView ivBackButton;
    @BindView(R.id.filter_close_image) ImageView ivCloseImage;
    @BindView(R.id.btn_apply) Button btnApply;
    @BindView(R.id.btn_cancel_filter) Button btnCancel;
    @BindView(R.id.btn_done) Button btnDone;
    @BindView(R.id.filter_loader) ProgressBar filterLoader;
    @BindView(R.id.price_range_seek_bar) CrystalRangeSeekbar priceRangeSeekBar;
    @BindView(R.id.text_price_from) TextView tvPriceFrom;
    @BindView(R.id.text_price_to) TextView tvPriceTo;
    @BindView(R.id.layout_price_range) LinearLayout llPriceRange;
    @BindView(R.id.clear_all_btn) TextView clearButton;
    @BindView(R.id.label_to_currency) TextView tvLabelToCurrency;
    @BindView(R.id.label_from_currency) TextView tvLabelFromCurrency;

    public static Fragment newInstance(String category, Pricing pricing) {
        final FilterListFragment fragment = new FilterListFragment();
        final Bundle args = new Bundle();
        args.putString(ARG_CATEGORY, category);
        args.putParcelable(ARG_PRACING, pricing);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_filter_list, container, false);
        ButterKnife.bind(this, view);
        initFilterList();
        initOptionList();
        initBrandList();
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mCategoryId = (String) args.getString(ARG_CATEGORY);
            Pricing pricing = args.getParcelable(ARG_PRACING);
            presenter.setPriceRange(pricing);
            presenter.loadFilterList(mCategoryId);
        }

    }

    private void initFilterList() {
        List<Attribute> attributeList = new ArrayList<>();
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        mFilterListView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mFilterListView.getContext(), DividerItemDecoration.VERTICAL);
        mFilterListView.addItemDecoration(dividerItemDecoration);
        mFilterListAdapter = new FilterAttributeListAdapter(attributeList, attribute -> presenter.onAttributeItemClick(attribute));
        mFilterListView.setAdapter(mFilterListAdapter);
    }

    private void initOptionList() {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        mFilterOptionListView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mFilterOptionListView.getContext(), DividerItemDecoration.VERTICAL);
        mFilterOptionListView.addItemDecoration(dividerItemDecoration);
        ((SimpleItemAnimator) mFilterOptionListView.getItemAnimator()).setSupportsChangeAnimations(false);
        mFilterOptionListAdapter = new FilterOptionListAdapter(getContext(), option -> presenter.onOptionClick(option));
        mFilterOptionListView.setAdapter(mFilterOptionListAdapter);
    }

    private void initBrandList() {
        mBrandOptionListAdapter = new BrandOptionListAdapter(getContext(), null);
        mBrandOptionListAdapter.setOnBrandItemClickListener(option -> presenter.onOptionClick(option));
        mBrandListView.setAdapter(mBrandOptionListAdapter);
//        mBrandListView.setFastScrollEnabled(true);
    }

    @Override
    public void showBrandList(List<Option> optionList) {
        mBrandOptionListAdapter.addBrandList(optionList);
        showBackButton();
        mBrandListView.setVisibility(View.VISIBLE);
        btnApply.setVisibility(View.VISIBLE);
        btnCancel.setVisibility(View.VISIBLE);
        btnDone.setVisibility(View.GONE);
        mFilterOptionListView.setVisibility(View.GONE);
        mFilterListView.setVisibility(View.GONE);
        llPriceRange.setVisibility(View.GONE);
    }

    @Override
    public void showFilterList(List<Attribute> attributeList) {
        showTitle(getString(R.string.filter_title));
        mFilterListAdapter.addAttributeList(attributeList);
        mFilterListView.setVisibility(View.VISIBLE);
        mFilterOptionListView.setVisibility(View.GONE);
        llPriceRange.setVisibility(View.GONE);
        btnApply.setVisibility(View.GONE);
        btnCancel.setVisibility(View.GONE);
        btnDone.setVisibility(View.VISIBLE);
        mBrandListView.setVisibility(View.GONE);
    }

    @Override
    public void showOptionList(Attribute attribute) {
        mFilterOptionListAdapter.addAttribute(attribute);
        showBackButton();
        btnApply.setVisibility(View.VISIBLE);
        btnCancel.setVisibility(View.VISIBLE);
        btnDone.setVisibility(View.GONE);
        mFilterOptionListView.setVisibility(View.VISIBLE);
        mFilterListView.setVisibility(View.GONE);
        llPriceRange.setVisibility(View.GONE);
        mBrandListView.setVisibility(View.GONE);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception
        try {
            mMainScreenListener = (MainScreenListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @OnClick(R.id.filter_close_image)
    public void onCloseFilterClick() {
        mMainScreenListener.closeFilterMenu();
    }

    @Override
    public FilterMVPContract.Presenter createPresenter() {
        return new FilterListPresenterImpl(getActivity());
    }

    @Override
    public void showError() {
//        Toast.makeText(getContext(), R.string.error_while_loading_content, Toast.LENGTH_SHORT).show();
    }

    private void showBackButton() {
        ivBackButton.setVisibility(View.VISIBLE);
        ivCloseImage.setVisibility(View.GONE);
    }

    @Override
    public void showTitle(String label) {
        tvFilterTitle.setText(label);
    }

    @Override
    public void showCloseButton() {
        ivCloseImage.setVisibility(View.VISIBLE);
        ivBackButton.setVisibility(View.GONE);
    }

    @Override
    public void showLoader(boolean visible) {
        filterLoader.setVisibility(visible ? View.VISIBLE : View.GONE);
        clearButton.setVisibility(visible ? View.INVISIBLE : View.VISIBLE);
    }

    @Override
    public void applyFilter(HashMap<Attribute, List<Option>> filterHashMap) {
        mMainScreenListener.filterProductList(filterHashMap);
    }

    @Override
    public String getPriceLabel() {
        return getString(R.string.price);
    }

    @Override
    public void showPriceRange(Pricing pricing) {
        llPriceRange.setVisibility(View.VISIBLE);
        priceRangeSeekBar.setMinValue(pricing.getPriceFrom());
        priceRangeSeekBar.setMaxValue(pricing.getPriceTo());
        presenter.setMinMaxPriceValue(pricing.getPriceFrom(), pricing.getPriceTo());
        priceRangeSeekBar.setOnRangeSeekbarChangeListener((minValue, maxValue) -> {
            tvPriceFrom.setText(NumberFormat.getInstance().format(minValue));
            tvPriceTo.setText((NumberFormat.getInstance().format(maxValue)));
        });
        priceRangeSeekBar.setOnRangeSeekbarFinalValueListener(
                (minValue, maxValue) -> presenter.setMinMaxPriceValue(minValue, maxValue)
        );
        showBackButton();
        btnApply.setVisibility(View.VISIBLE);
        btnCancel.setVisibility(View.VISIBLE);
        btnDone.setVisibility(View.GONE);
        mFilterOptionListView.setVisibility(View.GONE);
        mFilterListView.setVisibility(View.GONE);
        boolean isRightToLeft = getResources().getBoolean(R.bool.is_right_to_left);
        if (isRightToLeft) {
            priceRangeSeekBar.setScaleX(-1);
            priceRangeSeekBar.setScaleY(1);
            priceRangeSeekBar.setTranslationX(1);
        }
        //Set FROM and TO labels based on currency
        String currency = SPDataManager.INSTANCE.getCurrentCurrency();
        String fromText = getResources().getString(R.string.from_currency, currency);
        String toText = getResources().getString(R.string.to_currency, currency);
        tvLabelFromCurrency.setText(fromText);
        tvLabelToCurrency.setText(toText);
    }

    @Override
    public void showClearButton(boolean visible) {
        clearButton.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
    }

    @Override
    public void resetPriceRange(Pricing mPricing) {
        if (priceRangeSeekBar != null && mPricing != null) {
            priceRangeSeekBar.setMinStartValue(mPricing.getPriceFrom());
            priceRangeSeekBar.setMaxStartValue(mPricing.getPriceTo());
            priceRangeSeekBar.apply();
        }
    }

    @OnClick(R.id.filter_back_image)
    public void onBackFilterClick() {
        presenter.onBackFilterClick();
    }

    @OnClick(R.id.btn_apply)
    public void onApplyFilterClickButton() {
        presenter.onApplyFilterClick();
    }

    @OnClick(R.id.btn_cancel_filter)
    public void onButtonCancelClick() {
        if (mFilterOptionListView.getVisibility() == View.VISIBLE ||
                llPriceRange.getVisibility() == View.VISIBLE ||
                mBrandListView.getVisibility() == View.VISIBLE) {
            presenter.onCancelButtonClick();
        } else {
            mMainScreenListener.closeFilterMenu();
        }
    }

    @OnClick(R.id.btn_done)
    public void onButtonDoneClick() {
        mMainScreenListener.closeFilterMenu();
    }

    @OnClick(R.id.clear_all_btn)
    public void onClearAllButtonClick() {
        if (mFilterOptionListView.getVisibility() == View.VISIBLE || mBrandListView.getVisibility() == View.VISIBLE) {
            presenter.clearAllOptions();
        } else {
            presenter.clearAllAttributes();
        }
    }
}
