package com.sssports.sssports.navigation;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.ui.checkoutsuccess.CheckoutSuccessActivity;
import com.sssports.sssports.ui.main.MainActivity;
import com.sssports.sssports.ui.pdp.ProductDetailsActivity;
import com.sssports.sssports.ui.shoppingbag.ShoppingBagActivity;
import com.sssports.sssports.util.CommonConstants;

import javax.inject.Inject;
import javax.inject.Singleton;

import timber.log.Timber;

import static com.sssports.sssports.util.CommonConstants.INTENT_FRAGMENT_ID;

/**
 * Class used to navigate through the application.
 */

@Singleton
public class Navigator {

    public static final String HOST_PRODUCT = "product";
    public static final String HOST_CATEGORY = "category";
    public static final String HOST_BRAND = "brand";
    public static final String HOST_SPORT = "sport";
    public static final String HOST_PLP = "plp";

    @Inject
    public Navigator() {
        //empty
    }

    /**
     * Opens home screen.
     *
     * @param context A Context needed to open the destiny activity.
     */
    public void navigateToHomeScreen(Context context, Screen screen) {
        if (context != null) {
            Intent intent = MainActivity.getCallingIntent(context, screen);
            context.startActivity(intent);
        }
    }

    /**
     * Opens Product Details Page screen
     *
     * @param context context A Context needed to open the destiny activity.
     * @param productId
     */
    public void navigateToProductDetailsPage(Context context, String productId, String productSku) {
//        if (context instanceof ProductDetailsActivity) {
//            ((ProductDetailsActivity) context).finish();
//        }
        Intent intent = ProductDetailsActivity.getCallingIntent(context, productId, productSku);
        context.startActivity(intent);
    }

    /**
     * Opens Shopping Bag Screen
     * @param context context A Context needed to open the destiny activity.
     */
    public void navigateToShoppingCart(Context context) {
        if (context != null) {
            Intent intent = ShoppingBagActivity.getCallingIntent(context);
            context.startActivity(intent);
        }
    }

    public void navigateToThankYouScreen(Context context, String orderId) {
        Intent intent = CheckoutSuccessActivity.getCallingIntent(context, orderId);
        context.startActivity(intent);
    }

    private void navigateToCategoryScreen(Context context, String link) {
        if (context instanceof MainActivity) {
            ((MainActivity) context).displaySelectedScreen(CommonConstants.FragmentId.FRAGMENT_CATEGORY, link);
        } else {
            Intent intent = new Intent(context, MainActivity.class);
            intent.putExtra(MainActivity.INTENT_LINK, link);
            intent.putExtra(INTENT_FRAGMENT_ID, CommonConstants.FragmentId.FRAGMENT_CATEGORY);
            context.startActivity(intent);
        }
    }

    private void navigateToPLP(Context context, String link) {
        if (context instanceof MainActivity) {
            ((MainActivity) context).displaySelectedScreen(CommonConstants.FragmentId.FRAGMENT_PLP, link);
        } else {
            Intent intent = new Intent(context, MainActivity.class);
            intent.putExtra(MainActivity.INTENT_LINK, link);
            intent.putExtra(INTENT_FRAGMENT_ID, CommonConstants.FragmentId.FRAGMENT_PLP);
            context.startActivity(intent);
        }
    }

    public void openLink(Context context, String link) {
        Uri uri = Uri.parse(link);
        String host = uri.getHost();
        String scheme = uri.getScheme();
        String id = uri.getLastPathSegment();

        if (scheme.equalsIgnoreCase("sss")) {

            switch (host) {
                case HOST_PRODUCT:
                    navigateToProductDetailsPage(context, id, null);
                    break;
                case HOST_CATEGORY:
                    navigateToCategoryScreen(context, link);
                    break;
                case HOST_BRAND:
//                    navigateToCategoryScreen(context, link);
                    navigateToPLP(context, link);
                    break;
                case HOST_SPORT:
//                    navigateToCategoryScreen(context, link);
                    navigateToPLP(context, link);
                    break;
                case HOST_PLP:
                    navigateToPLP(context, link);
                    break;
            }
        } else {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(uri);
            context.startActivity(i);
        }
    }
}
