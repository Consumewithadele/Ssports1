package com.sssports.sssports.ui.checkoutbilling.builder;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;

import com.sssports.sssports.ui.widgets.checkoutsummary.WidgetTypeOrderSummary;

/**
 * Created by mlukovic on 9/1/17.
 */

public class CheckoutBillingBuilderImpl implements CheckoutBillingBuilder {

    private Activity activity;
    private LinearLayout mHostLayout;
    private WidgetTypeOrderSummary mWidgetTypeOrderSummary;

    public CheckoutBillingBuilderImpl(Activity activity, LinearLayout hostLayout) {
        this.activity = activity;
        mHostLayout = hostLayout;
    }

    @Override
    public void buildCheckoutSummary(OnSummaryReadyListener onSummaryReadyListener) {
        mWidgetTypeOrderSummary = new WidgetTypeOrderSummary(activity, onSummaryReadyListener);
        View summaryView = mWidgetTypeOrderSummary.buildView();
        // Add margin top programmatically
        float scale = activity.getResources().getDisplayMetrics().density;
        int padding = (int) (15 * scale + 0.5f);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        );
        params.setMargins(0, padding, 0, 0);
        summaryView.setLayoutParams(params);
        mHostLayout.addView(summaryView);
    }

    @Override
    public void refreshCheckoutSummary(OnSummaryReadyListener onSummaryReadyListener) {
        if (mWidgetTypeOrderSummary != null) {
            mWidgetTypeOrderSummary.onRefreshSummaryRequested(onSummaryReadyListener);
        }
    }
}
