package com.sssports.sssports.ui.customviews;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.util.CommonConstants;

/**
 * Created by natalijaratajac on 8/19/17.
 */

public class CustomDialog extends Dialog implements View.OnClickListener {

    public Context mContext;
    public Dialog d;
    public Button positiveButton, negativeButton;
    private int mDialogType = CommonConstants.DIALOG_ONE_BUTTON;
    private String mText;
    private String mTitle;
    private String mPositiveButtonText;
    private String mNegativeButtonText;
    private OnButtonClickListener mOnPositiveButtonClickListener;
    private OnButtonClickListener mOnNegativeButtonClickListener;

    public interface OnButtonClickListener {
        void onClick(CustomDialog customDialog);
    }


    public CustomDialog(Context context, int type) {
        super(context);
        mContext = context;
        setCancelable(true);
        setCanceledOnTouchOutside(false);
        mDialogType = type;
        mPositiveButtonText = context.getResources().getString(R.string.ok);
        mNegativeButtonText = context.getResources().getString(R.string.cancel);
    }


    public CustomDialog(Context context, String title, String text, String buttonText) {
        super(context);
        mContext = context;
        mText = text;
        mTitle = title;
        mPositiveButtonText = buttonText;
        mDialogType = CommonConstants.DIALOG_ONE_BUTTON;
    }

    public CustomDialog(Context context, String title, String text, String positiveButtonText, String negativeButtonText) {
        super(context);
        mContext = context;
        mTitle = title;
        mText = text;
        mPositiveButtonText = positiveButtonText;
        mNegativeButtonText = negativeButtonText;
        mDialogType = CommonConstants.DIALOG_TWO_BUTTONS;
    }

    public CustomDialog setTitle(String title) {
        mTitle = title;
        return this;
    }

    public CustomDialog setContentText(String text) {
        mText = text;
        return this;
    }

    public CustomDialog setPositiveButtonText(String buttonText) {
        mPositiveButtonText = buttonText;
        return this;
    }

    public CustomDialog setNegativeButtonText(String buttonText) {
        mNegativeButtonText = buttonText;
        return this;
    }

    public CustomDialog setOnPositiveButtonClickListener(OnButtonClickListener onPositiveButtonClickListener) {
        mOnPositiveButtonClickListener = onPositiveButtonClickListener;
        return this;
    }

    public CustomDialog setOnNegativeButtonClickListener(OnButtonClickListener onNegativeButtonClickListener) {
        mOnNegativeButtonClickListener = onNegativeButtonClickListener;
        return this;
    }

    /**
     * Sets title, text, button text from string array id
     *
     * @param stringArrayId
     * @return dialog with set texts
     */
    public CustomDialog setArrayTextContent(int stringArrayId) {
        String[] stringArray = mContext.getResources().getStringArray(stringArrayId);
        if (!TextUtils.isEmpty(stringArray[0])) {
            mTitle = stringArray[0];
        }
        if (!TextUtils.isEmpty(stringArray[1])) {
            mText = stringArray[1];
        }
        if (!TextUtils.isEmpty(stringArray[2])) {
            mNegativeButtonText = stringArray[2];
        }
        if (!TextUtils.isEmpty(stringArray[3])) {
            mPositiveButtonText = stringArray[3];
        }
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        switch (mDialogType) {
            case CommonConstants.DIALOG_ONE_BUTTON:
                setContentView(R.layout.dialog_one_button);
                positiveButton = findViewById(R.id.positiveButton);
                negativeButton = findViewById(R.id.negativeButton);
                negativeButton.setVisibility(View.INVISIBLE);
                positiveButton.setOnClickListener(this);
                negativeButton.setOnClickListener(this);
                ((TextView) findViewById(R.id.text)).setText(mText);
                ((TextView) findViewById(R.id.positiveButton)).setText(mPositiveButtonText);
                if (mText == null || mText.equals(CommonConstants.EMPTY_STRING))
                    findViewById(R.id.text).setVisibility(View.GONE);
                break;
            case CommonConstants.DIALOG_TWO_BUTTONS:
                setContentView(R.layout.dialog_one_button);
                positiveButton = findViewById(R.id.positiveButton);
                negativeButton = findViewById(R.id.negativeButton);
                positiveButton.setTextColor(mContext.getResources().getColor(R.color.orange));
                negativeButton.setText(mNegativeButtonText);
                positiveButton.setOnClickListener(this);
                negativeButton.setOnClickListener(this);
                ((TextView) findViewById(R.id.text)).setText(mText);
                ((TextView) findViewById(R.id.positiveButton)).setText(mPositiveButtonText);
                if (mText.equals(CommonConstants.EMPTY_STRING))
                    findViewById(R.id.text).setVisibility(View.GONE);
                break;
            case CommonConstants.DIALOG_LOADER:
                setContentView(R.layout.dialog_loader);
        }

        ((TextView) findViewById(R.id.title)).setText(mTitle);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        getWindow().setAttributes(params);

    }

    public CustomDialog onCancelDialogListener(OnCancelListener onCancelListener) {
        super.setOnCancelListener(onCancelListener);
        return this;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.positiveButton: {
                if (mOnPositiveButtonClickListener != null) {
                    mOnPositiveButtonClickListener.onClick(CustomDialog.this);
                } else {
                    dismiss();
                }
                break;
            }
            case R.id.negativeButton: {
                if (mOnNegativeButtonClickListener != null) {
                    mOnNegativeButtonClickListener.onClick(CustomDialog.this);
                } else {
                    dismiss();
                }
                break;
            }
            default:
                dismiss();

        }
    }
}
