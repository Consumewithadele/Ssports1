package com.sssports.sssports.ui.widgets.uspbar;

import android.app.Activity;
import android.view.View;

import com.sssports.sssports.R;
import com.sssports.sssports.ui.widgets.WidgetType;

/**
 * Created by mlukovic on 7/3/17.
 */

public class WidgetTypeUspBar implements WidgetType {

    private Activity mActivity;

    public WidgetTypeUspBar(Activity activity) {
        mActivity = activity;
    }

    @Override
    public View buildView() {
        return mActivity.getLayoutInflater().inflate(R.layout.widget_type_usb_bar, null);
    }
}
