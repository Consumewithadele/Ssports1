package com.sssports.sssports.ui.shoppingbag;

import android.text.TextUtils;

import com.sssports.sssports.models.custom.CartItemViewModel;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.magento.CartItem;
import com.sssports.sssports.models.magento.CartItemRequest;
import com.sssports.sssports.networking.NetworkConstants;
import com.sssports.sssports.networking.NoConnectivityException;
import com.sssports.sssports.networking.services.MagentoApi;
import com.sssports.sssports.networking.services.SSSApi;
import com.sssports.sssports.util.CommonConstants;

import java.util.ArrayList;
import java.util.List;

import moe.banana.jsonapi2.Document;
import retrofit2.Response;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by mlukovic on 8/26/17.
 */

public class ShoppingCartInteractorImpl implements ShoppingBagMvpContract.Interactor {

    private ShoppingBagMvpContract.Presenter presenter;
    private MagentoApi magentoApi;
    private SSSApi sssApi;

    public ShoppingCartInteractorImpl(ShoppingBagMvpContract.Presenter presenter, MagentoApi magentoApi, SSSApi sssApi) {
        this.presenter = presenter;
        this.magentoApi = magentoApi;
        this.sssApi = sssApi;
    }

    @Override
    public void getCartItems(String cartId) {
        magentoApi.getCartDetails(cartId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .flatMap(cartItems -> {
                            if (cartItems.size() == 0)
                                throw new IndexOutOfBoundsException("Empty list of cart items");
                            return sssApi.getProductListDetailsBySku(TextUtils.join(",", cartItems), CommonConstants.INCLUDE_CONFIG)
                                    .subscribeOn(Schedulers.io())
                                    .observeOn(AndroidSchedulers.mainThread());
                        },
                        this::mergeCartItems).subscribe(cartItemViewModels -> presenter.onCartItemsReady(cartItemViewModels),
                throwable -> {
                    if (throwable instanceof NoConnectivityException) {
                        presenter.noInternetConnection();
                    } else {
                        presenter.onGetCartItemsError();
                    }
                });
    }

    @Override
    public void deleteItemFromCart(CartItemViewModel cartItem) {
        magentoApi.deleteCartItem(cartItem.getQuoteId(), cartItem.getItemId())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(response -> {
                    if (response.isSuccessful()) {
                        presenter.onDeleteCartItemSuccess(cartItem);
                    } else {
                        presenter.onDeleteCartItemError(cartItem);
                    }
                }, throwable -> {
                    if (throwable instanceof NoConnectivityException) {
                        presenter.noInternetConnection();
                    } else {
                        presenter.onGetCartItemsError();
                    }
                });
    }

    @Override
    public void addOneItemToCart(CartItem cartItem) {
        CartItemRequest cartItemRequest = new CartItemRequest();
        cartItemRequest.setCartItem(cartItem);
        magentoApi.addToCart(cartItem.getQuoteId(), cartItemRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(
                        cartItemResponse -> {
                            if (cartItemResponse.isSuccessful()) {
                                presenter.onAddItemToCartSuccess(cartItem);
                            } else {
                                switch (cartItemResponse.code()) {
                                    case NetworkConstants.HttpCode.HTTP_400:
                                        presenter.onErrorThereIsNoItem(cartItem);
                                        break;
                                    default:
                                        presenter.onAddItemToCartError();

                                }

                            }
                        }, throwable -> {
                            if (throwable instanceof NoConnectivityException) {
                                presenter.noInternetConnection();
                            } else {
                                presenter.onAddItemToCartError();
                            }
                        }
                );
    }

    @Override
    public void deleteOneItemFromCart(CartItemViewModel cartItemViewModel) {
        CartItemRequest cartItemRequest = new CartItemRequest();
        CartItem cartItem = new CartItem(cartItemViewModel.getSku(), cartItemViewModel.getQuantity()-1, cartItemViewModel.getQuoteId());
        cartItemRequest.setCartItem(cartItem);
        magentoApi.updateCart(cartItemViewModel.getQuoteId(), cartItemViewModel.getItemId(), cartItemRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Response<CartItem>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable throwable) {
                        if (throwable instanceof NoConnectivityException) {
                            presenter.noInternetConnection();
                        } else {
                            presenter.onDeleteOneItemError(cartItemViewModel);
                        }

                    }

                    @Override
                    public void onNext(Response<CartItem> cartItemResponse) {
                        if (cartItemResponse.isSuccessful()) {
                            presenter.onDeleteOneItemSuccess(cartItemViewModel);
                        } else {
                            presenter.onDeleteOneItemError(cartItemViewModel);
                        }
                    }
                });

    }

    private List<CartItemViewModel> mergeCartItems(List<CartItem> cartItems, Document<Product> productList) {
        List<CartItemViewModel> cartItemViewModels = new ArrayList<>();
        for (CartItem cartItem : cartItems) {
            for (Product product : productList.asArrayDocument()) {
                if (cartItem.getSku().equalsIgnoreCase(product.getSku())) {
                    cartItemViewModels.add(new CartItemViewModel(cartItem, product));
                }
            }
        }
        return cartItemViewModels;
    }
}
