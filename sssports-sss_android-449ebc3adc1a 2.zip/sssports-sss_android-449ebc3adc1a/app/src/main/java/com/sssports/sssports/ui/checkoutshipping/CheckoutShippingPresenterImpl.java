package com.sssports.sssports.ui.checkoutshipping;

import android.app.Activity;
import android.text.TextUtils;

import com.sssports.sssports.SSSApp;
import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.locale.SharedPrefConstants;
import com.sssports.sssports.locale.SharedPreferenceManager;
import com.sssports.sssports.models.custom.UserDetailsDb;
import com.sssports.sssports.models.jsonapi.Field;
import com.sssports.sssports.models.jsonapi.NewsletterAndShippingMethodsZip;
import com.sssports.sssports.models.jsonapi.Newsletter;
import com.sssports.sssports.models.magento.UserDetailsDto;
import com.sssports.sssports.models.magento.ShippingAddress;
import com.sssports.sssports.models.magento.ShippingMethod;
import com.sssports.sssports.models.jsonapi.Country;
import com.sssports.sssports.models.jsonapi.Region;
import com.sssports.sssports.networking.services.MagentoApi;
import com.sssports.sssports.networking.services.SSSApi;
import com.sssports.sssports.util.ReadFromJsonFIle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import rx.Observable;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Created by natalijaratajac on 8/25/17.
 */

public class CheckoutShippingPresenterImpl implements CheckoutShippingContract.CheckoutShippingPresenter {

    private CheckoutShippingContract.CheckoutShippingView checkoutShippingView;
    private Activity activity;
    private SSSApi sssApi;
    private MagentoApi magentoApi;

    private List<Country> countries;
    private List<ShippingMethod> shippingMethods;

    private UserDetailsDto userDetailsDto;
    private UserDetailsDb userDetailsDb;
    private SharedPreferenceManager sharedPreferenceManager;
    private boolean subscribeToNewsletter;
    private boolean saveData;

    public CheckoutShippingPresenterImpl(CheckoutShippingContract.CheckoutShippingView checkoutShippingView, Activity activity) {
        this.checkoutShippingView = checkoutShippingView;
        this.activity = activity;
        sssApi = ((SSSApp) activity.getApplication()).getApplicationComponent().sssService();
        magentoApi = ((SSSApp)activity.getApplication()).getApplicationComponent().magentoService();
        userDetailsDto = new UserDetailsDto();
        userDetailsDb = new UserDetailsDb();
        sharedPreferenceManager = new SharedPreferenceManager(activity, SharedPrefConstants.PreferenceName.USER_DATA);
    }

    @Override
    public void loadData() {
        countries = ReadFromJsonFIle.getCountriesFromJsonFile("countries.json", activity);
        for (Country country : countries) {
            country.setRegionList(ReadFromJsonFIle.getRegionListFromJson(country.getCode() + ".json", activity));
        }
        checkoutShippingView.showAllTextViews();
        checkoutShippingView.showAllEditTexts();
        prefillAllDataFromSharedPefs();
        checkoutShippingView.hideLoading();
    }

    @Override
    public void setPhoneNumber(String s) {
        userDetailsDto.setPhoneNumber(s);
    }

    @Override
    public void setPoBox(String s) {
        userDetailsDto.setPoBox(s);
    }

    @Override
    public void setRegion(String s) {
        userDetailsDto.setRegion(s);
        userDetailsDto.setCity(s);
    }

    @Override
    public void setCountry(String countryId, String countryName) {
        userDetailsDto.setCountry(countryId);
        userDetailsDb.setCountryName(countryName);
    }

    @Override
    public void setAddress(String s) {
        String[] addressList = new String[1];
        addressList[0] = s;
        userDetailsDto.setAddress(addressList);
    }

    @Override
    public void setLastName(String s) {
        userDetailsDto.setLastName(s);
    }

    @Override
    public void setFirstName(String s) {
        userDetailsDto.setFirstName(s);
    }

    @Override
    public void setEmail(String s) {
        userDetailsDto.setEmail(s);
    }

    @Override
    public void setSubscriptionToNewsletter(boolean isChecked) {
        subscribeToNewsletter = isChecked;
    }

    @Override
    public void setSaveData(boolean isChecked) {
        SPDataManager.INSTANCE.setCheckboxStateSaveShippingAddress(isChecked);
        saveData = isChecked;
    }

    @Override
    public boolean getSaveData() {
        return saveData;
    }

    @Override
    public void prefillAllDataFromSharedPefs() {
        UserDetailsDb userDetailsDtoFromSharedPrefs = (UserDetailsDb) sharedPreferenceManager.getObject(SharedPrefConstants.PreferenceKeyName.USER_DETAILS, UserDetailsDb.class);
        if (userDetailsDtoFromSharedPrefs == null) {
            int positionCountry = countries.indexOf(new Country(SPDataManager.INSTANCE.getCountry()));
            checkoutShippingView.prefillCountryAndRegion(countries, positionCountry,0);
            return;
        }

        checkoutShippingView.setSaveShippingInfoCheckbox(SPDataManager.INSTANCE.isShippingInfoSaved());

        checkoutShippingView.prefillEmail(userDetailsDtoFromSharedPrefs.getEmail());
        checkoutShippingView.prefillFirstName(userDetailsDtoFromSharedPrefs.getFirstName());
        checkoutShippingView.prefillLastName(userDetailsDtoFromSharedPrefs.getLastName());
        checkoutShippingView.prefillAddress(userDetailsDtoFromSharedPrefs.getAddress()[0]);
        int positionCountry = 0;
        int positionRegion = 0;
        int i = 0;
        for (Country country : countries) {
            if (country.getCode() != null && country.getCode().equalsIgnoreCase(userDetailsDtoFromSharedPrefs.getCountry())) {
                positionCountry = i;
                break;
            }
            i++;
        }
        i = 0;
        for (Region region : countries.get(positionCountry).getRegionList()) {
            if (region.getName() != null && region.getName().equalsIgnoreCase(userDetailsDtoFromSharedPrefs.getRegion())) {
                positionRegion = i;
                break;
            }
            i++;
        }
        checkoutShippingView.prefillCountryAndRegion(countries,positionCountry,positionRegion);
        checkoutShippingView.prefillPoBox(userDetailsDtoFromSharedPrefs.getPoBox());
        checkoutShippingView.prefillPhoneNumber(userDetailsDtoFromSharedPrefs.getPhoneNumber());
    }

    @Override
    public List<ShippingMethod> getAvailableShippingMethods() {
        return shippingMethods;
    }

    @Override
    public void continueToShippingMethod() {
        if (!checkIfAllDataIsEntered()) {
            checkoutShippingView.showSnackBarPleaseFillAllData();
            return;
        }

        userDetailsDb.setFirstName(userDetailsDto.getFirstName());
        userDetailsDb.setLastName(userDetailsDto.getLastName());
        userDetailsDb.setEmail(userDetailsDto.getEmail());
        userDetailsDb.setAddress(userDetailsDto.getAddress());
        userDetailsDb.setCountry(userDetailsDto.getCountry());
        userDetailsDb.setRegion(userDetailsDto.getRegion());
        userDetailsDb.setPoBox(userDetailsDto.getPoBox());
        userDetailsDb.setPhoneNumber(userDetailsDto.getPhoneNumber());
        userDetailsDb.setCity(userDetailsDto.getCity());

        sharedPreferenceManager.putObject(SharedPrefConstants.PreferenceKeyName.USER_DETAILS, userDetailsDb);

        sendDataToServer();
    }

    private boolean checkIfAllDataIsEntered() {
        if (TextUtils.isEmpty(userDetailsDto.getEmail()) || TextUtils.isEmpty(userDetailsDto.getFirstName())
                || TextUtils.isEmpty(userDetailsDto.getLastName()) || userDetailsDto.getAddress() == null || TextUtils.isEmpty(userDetailsDto.getAddress()[0])
                || TextUtils.isEmpty(userDetailsDto.getCountry())
                || TextUtils.isEmpty(userDetailsDto.getPoBox()) || TextUtils.isEmpty(userDetailsDto.getPhoneNumber()))
            return false;
        if (!validatePhoneNumber(userDetailsDto.getPhoneNumber())){
            checkoutShippingView.showPhoneNumberErrorMessage();
            return false;
        }
        if (!validateEmail(userDetailsDto.getEmail())){
            checkoutShippingView.showEmailErrorMessage();
            return false;
        }

        return true;
    }

    private boolean validatePhoneNumber(String phoneNumber) {

//        "/^\+?(\d[.\- ]*){9,14}$/"
        String regex = "^\\+?(\\d[.\\- ]*){9,14}$";
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(phoneNumber).matches();
    }

    private boolean validateEmail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void sendDataToServer() {
        checkoutShippingView.showLoaderDialog();

        String cartId = SPDataManager.INSTANCE.getProductCartId();
        ShippingAddress shippingAddress = new ShippingAddress();
        shippingAddress.setAddress(userDetailsDto);

        if (subscribeToNewsletter) {
            sendDataToServerWithSubscription(cartId, shippingAddress);
        } else {
            sendDataToServerWithoutSubscription(cartId, shippingAddress);
        }
    }

    private void sendDataToServerWithoutSubscription(String cartId, ShippingAddress shippingAddress) {
        magentoApi.sendShippingAddress(cartId, shippingAddress)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<List<ShippingMethod>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error sending shipping address");
                        checkoutShippingView.hideLoaderDialog();
                        checkoutShippingView.showErrorDialog();
                    }

                    @Override
                    public void onNext(List<ShippingMethod> shippingMethodList) {

                        checkoutShippingView.hideLoaderDialog();
                        onSuccessShipping(shippingMethodList);
                    }
                });
    }

    private void sendDataToServerWithSubscription(String cartId, ShippingAddress shippingAddress) {

        Newsletter newsletter = new Newsletter();
        newsletter.setEmail(userDetailsDto.getEmail());
        Field field = new Field();
        field.setFirstName(userDetailsDto.getFirstName());
        field.setLastName(userDetailsDto.getLastName());
        newsletter.setField(field);

        Observable<List<ShippingMethod>> shippingMethodsObservable = magentoApi.sendShippingAddress(cartId, shippingAddress);
        Observable<Newsletter> newsletterObservable = sssApi.subscribeToNewsletter(newsletter);

        Observable.zip(newsletterObservable,
                shippingMethodsObservable,
                (newsletterResponse, shippingMethodsResponse) -> new NewsletterAndShippingMethodsZip(newsletterResponse, shippingMethodsResponse))
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(newsletterAndShippingMethodsZip -> {

                            checkoutShippingView.hideLoaderDialog();
                            onSuccessShipping(newsletterAndShippingMethodsZip.getShippingMethods());
                        },
                        error -> {
                            Timber.d("Error sending subscription and shipping address");
                            checkoutShippingView.hideLoaderDialog();
                            checkoutShippingView.showErrorDialog();
                        }
                );
    }

    private void onSuccessShipping(List<ShippingMethod> shippingMethodList) {
        if (shippingMethodList == null || shippingMethodList.isEmpty()) {
            checkoutShippingView.showErrorDialog();
            return;
        }

        shippingMethods = shippingMethodList;
        checkoutShippingView.openCheckoutBillingScreen();
    }
}
