package com.sssports.sssports.locale;

import android.content.Context;
import android.widget.ArrayAdapter;

import com.sssports.sssports.R;
import com.sssports.sssports.models.custom.Country;
import com.sssports.sssports.models.custom.Language;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Adeleclark on 8/16/17.
 */

public class LocaleBuilder {


    public static List<Language> buildLanguageList(Context context) {

        List<Language> languageList = new ArrayList<>();

        languageList.add(new Language(context, LocaleConstants.Language.ENGLISH, R.string.lang_english));
        languageList.add(new Language(context, LocaleConstants.Language.ARABIC, R.string.lang_arabic));

        return languageList;
    }

    public static int getSelectedLanguageIndex(List<Language> languageList, String locale) {
        int index = 0;
        for (int i = 0; i < languageList.size(); i++) {
            if(languageList.get(i).getCode().equalsIgnoreCase(locale)) {
                index = i;
                break;
            }
        }
        return index;
    }

    public static List<Country> buildCountryList(Context context) {
        List<Country> countryList = new ArrayList<>();

        countryList.add(new Country(context, LocaleConstants.Country.UAE, R.string.country_uae, LocaleConstants.Currency.UAE));
        countryList.add(new Country(context, LocaleConstants.Country.SAUDI_ARABIA, R.string.country_saudi_arabia, LocaleConstants.Currency.SAUDI_ARABIA));
        countryList.add(new Country(context, LocaleConstants.Country.QATAR, R.string.country_qatar, LocaleConstants.Currency.QATAR));
        countryList.add(new Country(context, LocaleConstants.Country.KUWAIT, R.string.country_kuwait, LocaleConstants.Currency.KUWAIT));
//        countryList.add(new Country(context, LocaleConstants.Country.INTERNATIONAL, R.string.country_international, LocaleConstants.Currency.INTERNATIONAL));

        return countryList;
    }
}
