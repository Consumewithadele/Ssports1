package com.sssports.sssports.ui.main.plp;

import android.animation.Animator;
import android.graphics.Paint;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Product;

import java.util.ArrayList;
import java.util.List;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by mlukovic on 8/4/17.
 */

public class ProductAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_PRODUCT = 0;
    public static final int ITEM_TYPE_LOADER = 1;

    private List<Product> mProductList;
    private ProductClickListener mProductClickListener;
    private boolean isLoaderVisible = true;

    public ProductAdapter(List<Product> productList, ProductClickListener productClickListener) {
        mProductList = productList;
        mProductClickListener = productClickListener;
    }

    public void addProducts(List<Product> productList) {
        mProductList.addAll(productList);
        notifyDataSetChanged();
    }

    public void removeAllProducts() {
        mProductList = new ArrayList<>();
        notifyDataSetChanged();
    }

    public void showLoader(boolean visible) {
        isLoaderVisible = visible;
    }

    // stores and recycles views as they are scrolled off screen
    public class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView imageViewProduct;
        public TextView tvProductName;
        public TextView textViewColors;
        public TextView tvPrice;
        public TextView tvNewPrice;
        public LottieAnimationView wishListAnimation;
        public ImageView ivWishListIcon;
        public LinearLayout linearLayout;
        public TextView tvSaleText;

        public ProductViewHolder(View itemView) {
            super(itemView);
            imageViewProduct = itemView.findViewById(R.id.image_view_product);
            tvProductName = itemView.findViewById(R.id.text_view_product_name);
            textViewColors = itemView.findViewById(R.id.text_view_num_colors);
            tvPrice = itemView.findViewById(R.id.old_price);
            tvNewPrice = itemView.findViewById(R.id.new_price);
            wishListAnimation = itemView.findViewById(R.id.icon_wish_list_anim);
            ivWishListIcon = itemView.findViewById(R.id.icon_wish_list);
            linearLayout = itemView.findViewById(R.id.ll_product);
            tvSaleText = itemView.findViewById(R.id.sale_text);
            itemView.setOnClickListener(this);
            linearLayout.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mProductClickListener != null)
                mProductClickListener.onClick(mProductList.get(getAdapterPosition()).getId());
        }
    }

    public class ProgressViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public ProgressViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.product_loader);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RecyclerView.ViewHolder vh;
        if (viewType == ITEM_TYPE_PRODUCT) {
            View v = LayoutInflater.from(parent.getContext()).
                    inflate(R.layout.adapter_sale_product, parent, false);

            vh = new ProductViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.progress_bar, parent, false);

            vh = new ProgressViewHolder(v);
        }
        return vh;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof ProductViewHolder) {

            ProductViewHolder productViewHolder = (ProductViewHolder) holder;

            Product product = mProductList.get(position);

            GlideApp.with(productViewHolder.imageViewProduct.getContext())
                    .load(product.getThumbnailUrl())
                    .transition(withCrossFade())
                    .placeholder(R.drawable.loading_placeholder)
                    .error(R.drawable.loading_placeholder)
                    .into(productViewHolder.imageViewProduct);

            productViewHolder.tvProductName.setText(product.getName());
            String numberOfColorsLabel = productViewHolder.imageViewProduct.getContext().getResources().getQuantityString(R.plurals.number_of_colors, product.getColorCount(), product.getColorCount());
            productViewHolder.textViewColors.setText(numberOfColorsLabel);

            try {
                productViewHolder.tvPrice.setText(product.getFormattedPrice());
            } catch (Exception e) {
                productViewHolder.tvPrice.setText(R.string.unavailable);
            }

            if (product.isOnSale()) {
                if (!TextUtils.isEmpty(product.getFormattedFinalPrice())) {
                    productViewHolder.tvNewPrice.setText(product.getFormattedFinalPrice());
                } else {
                    productViewHolder.tvNewPrice.setText(R.string.unavailable);
                }
//                productViewHolder.tvSaleText.setVisibility(View.VISIBLE);
                productViewHolder.tvNewPrice.setVisibility(View.VISIBLE);
                productViewHolder.tvPrice.setPaintFlags(productViewHolder.tvPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            } else {
//                productViewHolder.tvSaleText.findViewById(R.id.sale_text).setVisibility(View.GONE);
                productViewHolder.tvNewPrice.setVisibility(View.GONE);
                productViewHolder.tvPrice.setPaintFlags(productViewHolder.tvPrice.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            }

            if (!TextUtils.isEmpty(product.getBadgeBar())) {
                productViewHolder.tvSaleText.setVisibility(View.VISIBLE);
                productViewHolder.tvSaleText.setText(product.getBadgeBar());
            } else {
                productViewHolder.tvSaleText.setVisibility(View.GONE);
            }

            if (product.isInWishList()) {
                productViewHolder.ivWishListIcon.setSelected(true);
            } else {
                productViewHolder.ivWishListIcon.setSelected(false);
            }

            productViewHolder.wishListAnimation.addAnimatorListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animation, boolean isReverse) {
                }

                @Override
                public void onAnimationEnd(Animator animation, boolean isReverse) {
                    productViewHolder.wishListAnimation.setVisibility(View.GONE);
                }

                @Override
                public void onAnimationStart(Animator animator) {
                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    productViewHolder.wishListAnimation.setVisibility(View.GONE);
                }

                @Override
                public void onAnimationCancel(Animator animator) {
                }

                @Override
                public void onAnimationRepeat(Animator animator) {
                }
            });

            productViewHolder.ivWishListIcon.setOnClickListener(view -> {

                if (product.isInWishList()) {
                    productViewHolder.ivWishListIcon.setSelected(false);
                } else {
                    productViewHolder.wishListAnimation.setVisibility(View.VISIBLE);
                    productViewHolder.wishListAnimation.playAnimation();
                    productViewHolder.ivWishListIcon.setSelected(true);
                }
                product.setInWishList(!product.isInWishList());
            });

        } else {
            if (isLoaderVisible) {
                ((ProgressViewHolder) holder).progressBar.setVisibility(View.VISIBLE);
                ((ProgressViewHolder) holder).progressBar.setIndeterminate(true);
            } else {
                ((ProgressViewHolder) holder).progressBar.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public int getItemCount() {
        if (mProductList == null) return 0;
        return mProductList.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        return position == mProductList.size() ? ITEM_TYPE_LOADER : ITEM_TYPE_PRODUCT;
    }

    public interface ProductClickListener {
        void onClick(String productId);
    }
}
