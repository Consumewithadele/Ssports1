package com.sssports.sssports.di.modules;

import android.app.Application;
import android.content.Context;

import com.sssports.sssports.locale.SharedPreferenceManager;
import com.sssports.sssports.navigation.Navigator;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * This module provides objects which will live during the application lifecycle,
 * that is the reason why all of {@link Provides} methods use a {@link Singleton} scope.
 */

@Module
public class AppModule {

    private final Application mApplication;

    public AppModule(Application mApplication) {
        this.mApplication = mApplication;
    }

    @Provides
    @Singleton
    Context provideApplication() {
        return mApplication;
    }

    @Provides
    @Singleton
    Navigator provideNavigator() {
        return new Navigator();
    }

    @Provides
    @Singleton
    SharedPreferenceManager provideSharedPreferenceManager(Context context) {
        return new SharedPreferenceManager(context);
    }

//    @Provides
//    @Singleton
//    ApiService provideApiService() {
//        Timber.d("initialize the ApiService");
//        return null;
//    }

//    @Provides
//    @Singleton
//    UserRepository provideUserRepository(UserDataRepository userDataRepository) {
//        return userDataRepository;
//    }
}
