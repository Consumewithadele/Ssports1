package com.sssports.sssports.ui.shoppingbag.widgetbuilder;

import com.sssports.sssports.ui.checkoutbilling.builder.OnSummaryReadyListener;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public interface ShoppingBagDirector {

    void construct(OnSummaryReadyListener onSummaryReadyListener);

    void refreshSummary(OnSummaryReadyListener onSummaryReadyListener);
}
