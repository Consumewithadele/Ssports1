package com.sssports.sssports.ui.widgets.hero;

import com.sssports.sssports.models.jsonapi.Block;

import java.util.List;

/**
 * Contract for implementing MVP pattern for Hero Widget
 */

public class HeroWidgetContract {

    interface HeroWidgetView {

        void showBlockList(List<Block> blockList);

        void showLoader();

        void showError();

        void hideWidget();
    }

    interface HeroWidgetPresenter {

        void loadData();
    }
}
