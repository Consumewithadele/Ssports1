package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import java.io.Serializable;
import java.util.List;

import moe.banana.jsonapi2.HasMany;
import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by natalijaratajac on 8/8/17.
 */
@JsonApi(type = "selections")
public class Selection extends Resource implements Serializable {

    @Json(name = "product_id")
    private Integer productId;
    @Json(name = "attribute_id")
    private Integer attributeId;
    @Json(name = "position")
    private Integer position;
    @Json(name = "label")
    private String label;
    @Json(name = "attribute_code")
    private String attributeCode;
    @Json(name = "option_count")
    private Integer optionCount;

    //Relationship

    @Json(name = "options")
    private HasMany<Option> options = null;

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(Integer attributeId) {
        this.attributeId = attributeId;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getAttributeCode() {
        return attributeCode;
    }

    public void setAttributeCode(String attributeCode) {
        this.attributeCode = attributeCode;
    }

    public Integer getOptionCount() {
        return optionCount;
    }

    public void setOptionCount(Integer optionCount) {
        this.optionCount = optionCount;
    }

    public List<Option> getOptions() {
        return options.get(getContext());
    }
}
