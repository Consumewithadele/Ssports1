package com.sssports.sssports.models.custom;

import java.util.regex.Pattern;

/**
 * Created by natalijaratajac on 8/27/17.
 */

public enum CardType {


    UNKNOWN,
    VISA("^4[0-9]{6,}$"),
    MASTERCARD("^5[1-5][0-9]{5,}|222[1-9][0-9]{3,}|22[3-9][0-9]{4,}|2[3-6][0-9]{5,}|27[01][0-9]{4,}|2720[0-9]{3,}$");
//    for now not available by requirements
//    AMERICAN_EXPRESS("^3[47][0-9]{5,}$"),
//    DINERS_CLUB("^3(?:0[0-5]|[68][0-9])[0-9]{4,}$"),
//    DISCOVER("^6(?:011|5[0-9]{2})[0-9]{3,}$"),
//    JCB("^(?:2131|1800|35[0-9]{3})[0-9]{3,}$");

    private Pattern pattern;

    CardType() {
        this.pattern = null;
    }

    CardType(String pattern) {
        this.pattern = Pattern.compile(pattern);
    }

    public static CardType detect(String cardNumber) {

        for (CardType cardType : CardType.values()) {
            if (null == cardType.pattern) continue;
            if (cardType.pattern.matcher(cardNumber).matches()) return cardType;
        }

        return UNKNOWN;
    }
}
