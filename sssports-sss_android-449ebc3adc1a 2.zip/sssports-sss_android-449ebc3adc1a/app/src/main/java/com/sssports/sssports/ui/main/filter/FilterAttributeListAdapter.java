package com.sssports.sssports.ui.main.filter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Attribute;
import com.sssports.sssports.models.jsonapi.Option;

import java.util.List;

/**
 * Created by mlukovic on 8/7/17.
 */

public class FilterAttributeListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Attribute> mAttributeList;
    private OnFilterItemClickListener mOnFilterItemClickListener;

    public FilterAttributeListAdapter(List<Attribute> attributeList, OnFilterItemClickListener onFilterItemClickListener) {
        mAttributeList = attributeList;
        mOnFilterItemClickListener = onFilterItemClickListener;
    }

    public void addAttributeList(List<Attribute> attributeList) {
        mAttributeList = attributeList;
        notifyDataSetChanged();
    }

    class FilterItemViewHolder extends RecyclerView.ViewHolder {

        public TextView filterName;
        public TextView filterSelectedOptionList;

        public FilterItemViewHolder(View itemView) {
            super(itemView);
            filterName = itemView.findViewById(R.id.filter_name);
            filterSelectedOptionList = itemView.findViewById(R.id.filter_list_option);
            itemView.setOnClickListener(view -> mOnFilterItemClickListener.onClick(mAttributeList.get(getAdapterPosition())));
        }
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_filter_attribute_item, parent, false);
        return new FilterItemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        FilterItemViewHolder viewHolder = (FilterItemViewHolder) holder;
        Attribute filterAttribute = mAttributeList.get(position);
        viewHolder.filterName.setText(filterAttribute.getLabel());
        String selectedOptionsString = getSelectedOptionsString(filterAttribute);
        if (selectedOptionsString.length() > 0) {
            viewHolder.filterSelectedOptionList.setText(getSelectedOptionsString(filterAttribute));
            viewHolder.filterSelectedOptionList.setVisibility(View.VISIBLE);
        } else {
            viewHolder.filterSelectedOptionList.setVisibility(View.GONE);
        }
    }

    private String getSelectedOptionsString(Attribute filterAttribute) {
        StringBuilder stringBuilder = new StringBuilder();
        if (filterAttribute.getOptionList() != null) {
            for (Option option : filterAttribute.getOptionList()) {
                if (option.isSelected()) {
                    stringBuilder.append(option.getLabel());
                    stringBuilder.append(", ");
                }
            }
        }
        if (stringBuilder.length() > 1) {
            stringBuilder.deleteCharAt(stringBuilder.length() - 2);
        }
        return stringBuilder.toString();
    }

    @Override
    public int getItemCount() {
        if (mAttributeList == null) return 0;
        return mAttributeList.size();
    }

    interface OnFilterItemClickListener {
        void onClick(Attribute attribute);
    }
}
