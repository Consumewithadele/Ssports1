
package com.sssports.sssports.models.sli;

import com.squareup.moshi.Json;

public class Next {

    @Json(name = "name")
    private Integer name;
    @Json(name = "start")
    private Integer start;

    public Integer getName() {
        return name;
    }

    public void setName(Integer name) {
        this.name = name;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

}
