package com.sssports.sssports.models.magento;

import com.squareup.moshi.Json;

/**
 * Created by mlukovic on 8/26/17.
 */

public class CartItemRequest {

    @Json(name = "cartItem")
    private CartItem cartItem;

    public CartItem getCartItem() {
        return cartItem;
    }

    public void setCartItem(CartItem cartItem) {
        this.cartItem = cartItem;
    }
}
