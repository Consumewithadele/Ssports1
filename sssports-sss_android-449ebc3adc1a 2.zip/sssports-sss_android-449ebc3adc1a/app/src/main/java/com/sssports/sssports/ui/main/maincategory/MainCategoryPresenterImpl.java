package com.sssports.sssports.ui.main.maincategory;

import android.app.Activity;

import com.sssports.sssports.SSSApp;
import com.sssports.sssports.di.component.ApplicationComponent;
import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.networking.services.SSSApi;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Created by mlukovic on 7/31/17.
 */

public class MainCategoryPresenterImpl implements MainCategoryContract.MainCategoryPresenter {

    private MainCategoryContract.MainCategoryView mMainCategoryView;
    private Activity mActivity;

    private SSSApi sssApi;

    public MainCategoryPresenterImpl(MainCategoryContract.MainCategoryView mainCategoryView, Activity activity) {
        mMainCategoryView = mainCategoryView;
        mActivity = activity;
        sssApi = ((SSSApp) activity.getApplication()).getApplicationComponent().sssService();
    }

    @Override
    public void loadData() {
        mMainCategoryView.showLoading(true);
        sssApi.getScreens("categories", /*"en_GB",*/ 1, "widgets.blocks.actions")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(
                        screen -> {
                            if (screen != null && screen.getWidgets() != null && screen.getWidgets().get(0) != null) {
                                mMainCategoryView.showCategoryList(screen.getWidgets().get(0).getBlockList());
                            } else {
                                mMainCategoryView.showError();
                            }
                            mMainCategoryView.showLoading(false);
                        },
                        e -> {
                            Timber.d(e.getMessage());
                            mMainCategoryView.showError();
                            mMainCategoryView.showLoading(false);
                        }
                );
    }

    protected ApplicationComponent getApplicationComponent() {
        if (mActivity != null) {
            return ((SSSApp) mActivity.getApplication()).getApplicationComponent();
        } else {
            return null;
        }
    }
}
