package com.sssports.sssports.ui.customviews;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.sssports.sssports.R;
import com.sssports.sssports.util.CommonConstants;

/**
 * Created by natalijaratajac on 8/20/17.
 */

public class ListDialog extends Dialog {

    public Context mContext;

    private String title;
    private String titleText;
    private String text1;
    private String text2;
    private String text3;

    private int dialogType;

    private View.OnClickListener onFirstButtonClickListener;
    private View.OnClickListener onSecondButtonClickListener;
    private View.OnClickListener onThirdButtonClickListener;

    public ListDialog(Context context, String title, String text1, String text2, String text3) {
        super(context);
        mContext = context;
        this.title = title;
        this.text1 = text1;
        this.text2 = text2;
        this.text3 = text3;
        dialogType = CommonConstants.DIALOG_THREE_OPTIONS;
    }

    public ListDialog(Context context, String title, String text1, String text2) {
        super(context);
        mContext = context;
        this.title = title;
        this.text1 = text1;
        this.text2 = text2;
        dialogType = CommonConstants.DIALOG_TWO_OPTIONS;
    }

    public ListDialog(Context context, String title, String text1) {
        super(context);
        mContext = context;
        this.title = title;
        this.text1 = text1;
        dialogType = CommonConstants.DIALOG_ONE_OPTION;
    }

    public void setTitleText(String titleText) {
        this.titleText = titleText;
    }

    public void setOnFirstButtonClickListener(View.OnClickListener onFirstButtonClickListener) {
        this.onFirstButtonClickListener = onFirstButtonClickListener;
    }

    public void setOnSecondButtonClickListener(View.OnClickListener onSecondButtonClickListener) {
        this.onSecondButtonClickListener = onSecondButtonClickListener;
    }

    public void setOnThirdButtonClickListener(View.OnClickListener onThirdButtonClickListener) {
        this.onThirdButtonClickListener = onThirdButtonClickListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_list);

        TextView tvTitle = findViewById(R.id.tv_title);
        TextView tvTitleText = findViewById(R.id.tv_title_text);
        TextView firstOption = findViewById(R.id.first_option);
        TextView secondOption = findViewById(R.id.second_option);
        TextView thirdOption = findViewById(R.id.third_option);
        View titleDivider = findViewById(R.id.title_divider);
        View secondDivider = findViewById(R.id.second_divider);

        if (TextUtils.isEmpty(title)) {
            tvTitle.setVisibility(View.GONE);
            titleDivider.setVisibility(View.GONE);
        } else {
            tvTitle.setText(title);
        }

        if (TextUtils.isEmpty(titleText)) {
            tvTitleText.setVisibility(View.GONE);
        } else {
            tvTitleText.setText(titleText);
        }

        switch (dialogType) {
            case CommonConstants.DIALOG_ONE_OPTION:
                secondOption.setVisibility(View.GONE);
                thirdOption.setVisibility(View.GONE);
                secondDivider.setVisibility(View.GONE);
                firstOption.setText(text1);
                break;
            case CommonConstants.DIALOG_TWO_OPTIONS:
                thirdOption.setVisibility(View.GONE);
                firstOption.setText(text1);
                secondOption.setText(text2);
                break;
            case CommonConstants.DIALOG_THREE_OPTIONS:
                firstOption.setText(text1);
                secondOption.setText(text2);
                thirdOption.setText(text3);
                break;
        }

        firstOption.setOnClickListener(onFirstButtonClickListener);

        secondOption.setOnClickListener(onSecondButtonClickListener);

        thirdOption.setOnClickListener(onThirdButtonClickListener);
    }
}
