package com.sssports.sssports.models.custom;

import com.sssports.sssports.models.jsonapi.Config;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.magento.CartItem;
import com.sssports.sssports.util.CommonConstants;

/**
 * Created by mlukovic on 8/27/17.
 */

public class CartItemViewModel {

    public CartItemViewModel(CartItem cartItem, Product product) {
        itemId = cartItem.getItemId();
        sku = cartItem.getSku();
        quoteId = cartItem.getQuoteId();
        name = cartItem.getName();
        quantity = cartItem.getQty();
        id = product.getId();
        color = product.getColor();
        for (Config config : product.getConfigList()) {
            if (config.getCode().contains(CommonConstants.SIZE)) {
                size = config.getLabel();
            }
        }
        availableQuantity = product.getQuantity();
        thumbnailUrl = product.getThumbnailUrl();
        formattedFinalPrice = product.getFormattedFinalPrice();
    }

    private Integer itemId;
    private String quoteId;
    private String sku;
    private String formattedFinalPrice;
    private String name;
    private Integer quantity;
    private String id;
    private String color;
    private String size;
    private Integer availableQuantity;
    private String thumbnailUrl;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Integer getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(Integer availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getFormattedFinalPrice() {
        return formattedFinalPrice;
    }

    public void setFormattedFinalPrice(String formattedFinalPrice) {
        this.formattedFinalPrice = formattedFinalPrice;
    }

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public String getQuoteId() {
        return quoteId;
    }

    public void setQuoteId(String quoteId) {
        this.quoteId = quoteId;
    }
}
