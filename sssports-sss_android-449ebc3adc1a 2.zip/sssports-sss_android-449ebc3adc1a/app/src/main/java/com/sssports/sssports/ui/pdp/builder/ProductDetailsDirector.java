package com.sssports.sssports.ui.pdp.builder;

import com.sssports.sssports.ui.widgets.productdetail.ProductDetailListener;

/**
 * Created by natalijaratajac on 8/8/17.
 */

public interface ProductDetailsDirector {

    void construct(ProductDetailListener productDetailListener);
}
