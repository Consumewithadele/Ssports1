package com.sssports.sssports.ui.main.maincategory;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Block;
import com.sssports.sssports.ui.main.MainScreenListener;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import timber.log.Timber;

/**
 * Created by mlukovic on 7/19/17.
 */

public class MainCategoryFragment extends Fragment implements MainCategoryContract.MainCategoryView {

    @BindView(R.id.main_grid_view_categories) GridView gridViewCategories;
    @BindView(R.id.rl_holder) RelativeLayout rlHolder;
    @BindView(R.id.loader_category_fragment) ProgressBar loaderCategoryFragment;

    private MainCategoryContract.MainCategoryPresenter categoryPresenter;
    private OnMainCategorySelectedListener mCallback;
    private MainScreenListener mOnTitleChangeListener;

    public static int height = 0;

    public static MainCategoryFragment newInstance() {
        return new MainCategoryFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main_category, container, false);
        ButterKnife.bind(this, view);

        categoryPresenter = new MainCategoryPresenterImpl(this, getActivity());
        categoryPresenter.loadData();
        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        //Set title
        mOnTitleChangeListener.showScreenTitle(null);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception
        try {
            mCallback = (OnMainCategorySelectedListener) context;
            mOnTitleChangeListener = (MainScreenListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @Override
    public void showCategoryList(List<Block> blockList) {
        MainCategoryAdapter categoryAdapter = new MainCategoryAdapter(blockList, getActivity(), link -> {
            if (mCallback != null) {
                mCallback.onCategorySelected(link);
            }
        });
        gridViewCategories.setAdapter(categoryAdapter);
    }

    @Override
    public void showLoading(boolean visible) {
        loaderCategoryFragment.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    @Override
    public void showError() {
        Timber.d("Error while loading categories");
    }

    public interface OnMainCategorySelectedListener {
        void onCategorySelected(String link);
    }
}
