package com.sssports.sssports.ui.widgets.productverticalscroll;

import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.models.meta.Page;
import com.sssports.sssports.ui.BaseActivity;

import java.util.List;

import javax.inject.Inject;

/**
 * Presenter part implementation of MVP for Product Vertical Scroll List Widget
 */

public class ProductVerticalPresenterImpl implements ProductVerticalContract.ProductVerticalPresenter {

    private ProductVerticalContract.ProductVerticalView productVerticalView;
    private ProductVerticalContract.ProductVerticalInteractor productVerticalInteractor;
    private boolean isProductsLoading;
    private Widget mWidget;
    private static final int PAGE_SIZE = 8;
    private int currentPage = 0;
    private int lastPage = 1;

    @Inject
    public ProductVerticalPresenterImpl(ProductVerticalContract.ProductVerticalView productVerticalView, Widget widget, BaseActivity activity) {
        this.productVerticalView = productVerticalView;
        mWidget = widget;
        productVerticalInteractor = new ProductVerticalInteractorImpl(this, activity);
        productVerticalView.showTitle(mWidget.getLabel());
        productVerticalView.showDescription(mWidget.getText());
    }

    @Override
    public void loadProducts() {
        if (!isProductsLoading && currentPage < lastPage) {
            isProductsLoading = true;
            productVerticalInteractor.getProductListData(mWidget.getId(), currentPage + 1, PAGE_SIZE);
            productVerticalView.showLoader();
        }
    }

    @Override
    public void onProductListDataReady(List productList, Page page) {
        lastPage = page.getLastPage();
        currentPage = page.getCurrentPage();
        productVerticalView.addProductList(productList);
        productVerticalView.hideLoader();
        isProductsLoading = false;
    }
}
