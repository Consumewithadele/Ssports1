package com.sssports.sssports.ui.widgets.productdetail;

import android.animation.Animator;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.Paint;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.duolingo.open.rtlviewpager.RtlViewPager;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Option;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.ProductChild;
import com.sssports.sssports.models.jsonapi.ProductImage;
import com.sssports.sssports.ui.widgets.WidgetType;
import com.sssports.sssports.ui.widgets.multiselection.ColourwayAdapter;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.relex.circleindicator.CircleIndicator;

/**
 * Created by natalijaratajac on 8/13/17.
 */

public class WidgetTypeProductDetail implements WidgetType, ProductDetailsMvpContract.View {

    @BindView(R.id.vp_product_detail_image) RtlViewPager viewPagerImage;
    @BindView(R.id.indicator) CircleIndicator circleIndicator;
    @BindView(R.id.ll_product_detail_widget) LinearLayout llProductDetailWidget;

    @BindView(R.id.tv_product_detail_title) TextView tvTitle;
    @BindView(R.id.tv_product_detail_detail_old_price) TextView tvOldPrice;
    @BindView(R.id.tv_product_detail_new_price) TextView tvNewPrice;
    @BindView(R.id.iv_play_video) ImageView ivPlayVideo;
    @BindView(R.id.icon_wish_list_anim) LottieAnimationView wishListAnimation;
    @BindView(R.id.icon_wish_list) ImageView ivWishListIcon;
    @BindView(R.id.product_color) TextView tvProductColor;
    @BindView(R.id.tv_size) TextView tvSize;
    @BindView(R.id.rl_select_size) RelativeLayout rlSelectSize;
    @BindView(R.id.ll_product_color) LinearLayout llProductColor;
    @BindView(R.id.top_divider) View viewTopDivider;

    //Colorway
    @BindView(R.id.rv_colour_products) RecyclerView rvColourProducts;
    @BindView(R.id.tv_product_code) TextView tvProductCode;

    private ProductDetailsMvpContract.Presenter presenter;
    private ColourwayAdapter mColourwayAdapter;

    private Activity mActivity;
    private Product mProduct;
    private int mCurrentPage = 0;
    private boolean mAutoScrollEnabled;

    public WidgetTypeProductDetail(Activity activity, Product product, boolean autoScrollEnabled, ProductDetailListener productDetailListener) {
        mActivity = activity;
        mProduct = product;
        mAutoScrollEnabled = autoScrollEnabled;
        presenter = new ProductDetailsPresenterImpl(this, productDetailListener);
    }

    @Override
    public View buildView() {
        View widgetProductDetailView = mActivity.getLayoutInflater().inflate(R.layout.widget_type_product_detail, null);
        ButterKnife.bind(this, widgetProductDetailView);

        showData(mProduct);
        this.initColorWayList();
        presenter.loadLoadData(mProduct);

        return widgetProductDetailView;
    }

    public void showData(Product product) {

        tvTitle.setText(mProduct.getName());

        if (TextUtils.isEmpty(product.getVideoUrl())) {
            ivPlayVideo.setVisibility(View.INVISIBLE);
        } else {
            ivPlayVideo.setVisibility(View.VISIBLE);
        }

        setAddToWishList(product);
    }

    private void setAddToWishList(Product product) {

        wishListAnimation.addAnimatorListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation, boolean isReverse) {
            }

            @Override
            public void onAnimationEnd(Animator animation, boolean isReverse) {
                wishListAnimation.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationStart(Animator animator) {
            }

            @Override
            public void onAnimationEnd(Animator animator) {
                wishListAnimation.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationCancel(Animator animator) {
            }

            @Override
            public void onAnimationRepeat(Animator animator) {
            }
        });

        ivWishListIcon.setOnClickListener(view -> {

            if (product.isInWishList()) {
                ivWishListIcon.setSelected(false);
            } else {
                wishListAnimation.setVisibility(View.VISIBLE);
                wishListAnimation.playAnimation();
                ivWishListIcon.setSelected(true);
            }
            product.setInWishList(!product.isInWishList());
        });
    }

    private void playAutoScroll() {
        Handler handler = new Handler();

        Runnable update = () -> {
            if (mCurrentPage == mProduct.getImages().size()) {
                mCurrentPage = 0;
            }
            viewPagerImage.setCurrentItem(mCurrentPage++, true);
        };

        new Timer().schedule(new TimerTask() {

            @Override
            public void run() {
                handler.post(update);
            }
        }, 0, 4000);
    }

    @Override
    public void showProductColor(String color) {
        tvProductColor.setVisibility(View.VISIBLE);
        tvProductColor.setText(color);
    }

    @Override
    public void showSizeList(List<ProductChild> filteredProductsBySize) {
        Dialog dialog = new Dialog(mActivity);
        dialog.setContentView(R.layout.dialog_select_option);
        RecyclerView sizeListView = dialog.findViewById(R.id.lv);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity);
        sizeListView.setLayoutManager(layoutManager);

        SizeListAdapter sizeListAdapter = new SizeListAdapter(filteredProductsBySize, new SizeListAdapter.OnOptionClickListener() {
            @Override
            public void onAvailableOptionClick(ProductChild productChild) {
                presenter.onSizeChange(productChild);
                dialog.dismiss();
            }

            @Override
            public void onUnavailableOptionClick() {
                Toast.makeText(mActivity, R.string.selected_option_is_not_available, Toast.LENGTH_SHORT).show();
            }
        });

        sizeListView.setAdapter(sizeListAdapter);
        dialog.setCancelable(true);
        dialog.show();
    }

    @Override
    public void showErrorGettingSizeList() {
        //TODO show better message
        Toast.makeText(mActivity, R.string.error_while_loading_content, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void showSelectedSize(ProductChild productChild) {
        tvSize.setText(productChild.getSizeLabel());
    }

    @Override
    public void showProductName(String name) {
        String productCode = mActivity.getResources().getString(R.string.product_code, name);
        tvProductCode.setText(productCode);
    }

    @Override
    public void showProductImages(List<ProductImage> images) {
        ProductDetailAdapter adapter = new ProductDetailAdapter(images, mActivity);

        viewPagerImage.setAdapter(adapter);
        circleIndicator.setViewPager(viewPagerImage);

        if (mAutoScrollEnabled) {
            playAutoScroll();
        }
    }

    private void initColorWayList() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.HORIZONTAL, false);
        rvColourProducts.setLayoutManager(layoutManager);
    }

    @Override
    public void showColorWayList(List<Option> optionColorList) {
        mColourwayAdapter = new ColourwayAdapter(mActivity, optionColorList);
        rvColourProducts.setAdapter(mColourwayAdapter);
        mColourwayAdapter.setOnColourClickListener(option -> presenter.onColorChange(option));
    }

    @OnClick(R.id.rl_select_size)
    public void onSelectSizeClick() {
        presenter.getSizeList();
    }

    @Override
    public void resetSizeLabel() {
        tvSize.setText(mActivity.getResources().getString(R.string.select_size));
    }

    @Override
    public void showPrice(ProductChild productChild) {
        tvOldPrice.setText(mProduct.getFormattedPrice());

        if (productChild.isOnSale()) {
            tvNewPrice.setText(productChild.getFormattedFinalPrice());
            tvNewPrice.setVisibility(View.VISIBLE);
            tvOldPrice.setPaintFlags(tvOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            tvOldPrice.setVisibility(View.VISIBLE);
        } else {
            tvNewPrice.setVisibility(View.GONE);
            tvOldPrice.setVisibility(View.VISIBLE);
        }

        if (!productChild.getIsAvailable()) {
            tvNewPrice.setVisibility(View.VISIBLE);
            tvNewPrice.setText(R.string.out_of_stock);
            tvOldPrice.setVisibility(View.GONE);
        }
    }

    @Override
    public void showPrice(Product product) {
        tvOldPrice.setText(mProduct.getFormattedPrice());

        if (product.isOnSale()) {
            tvNewPrice.setText(product.getFormattedFinalPrice());
            tvNewPrice.setVisibility(View.VISIBLE);
            tvOldPrice.setPaintFlags(tvOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            tvOldPrice.setVisibility(View.VISIBLE);
        } else {
            tvNewPrice.setVisibility(View.GONE);
            tvOldPrice.setVisibility(View.VISIBLE);
        }

        if (!product.isAvailable()) {
            tvNewPrice.setVisibility(View.VISIBLE);
            tvNewPrice.setText(R.string.out_of_stock);
            tvOldPrice.setVisibility(View.GONE);
        }
    }

    @Override
    public void disableProductSizeList() {
        rlSelectSize.setVisibility(View.GONE);
    }

    @Override
    public void disableColorWayList() {
        rvColourProducts.setVisibility(View.GONE);
    }

    @Override
    public void hideProductColor() {
        viewTopDivider.setVisibility(View.GONE);
        llProductColor.setVisibility(View.GONE);
    }
}
