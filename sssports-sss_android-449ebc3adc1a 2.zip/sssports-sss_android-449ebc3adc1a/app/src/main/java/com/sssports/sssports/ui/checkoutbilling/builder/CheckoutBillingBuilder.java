package com.sssports.sssports.ui.checkoutbilling.builder;

/**
 * Created by mlukovic on 9/1/17.
 */

public interface CheckoutBillingBuilder {

    void buildCheckoutSummary(OnSummaryReadyListener onSummaryReadyListener);

    void refreshCheckoutSummary(OnSummaryReadyListener onSummaryReadyListener);
}
