package com.sssports.sssports.ui.widgets;

import android.widget.ScrollView;

import com.sssports.sssports.models.jsonapi.Widget;
/**
 * Created by Adeleclark on 7/3/17.
 */

public interface WidgetBuilder {

    void buildCategoryWidget(Widget widget);

    void buildUspBarWidget();

    void buildHeroWidget(Widget widget, boolean autoScrollEnabled);

    void buildProductsHorizontalScrollWidget(Widget widget);

    void buildBlogPostWidget(Widget widget);

    void buildSaleBannerWidget(Widget widget);

    void buildProductVerticalScrollWidget(Widget widget, ScrollView scrollView);

    void buildSliderContentWidget(Widget widget);

    void buildPromotionWidget(Widget widget);
}
