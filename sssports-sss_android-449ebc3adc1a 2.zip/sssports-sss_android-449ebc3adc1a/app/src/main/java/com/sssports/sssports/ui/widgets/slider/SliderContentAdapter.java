package com.sssports.sssports.ui.widgets.slider;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.load.DecodeFormat;
import com.sssports.sssports.GlideApp;
import com.sssports.sssports.R;
import com.sssports.sssports.models.jsonapi.Block;

import java.util.List;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * Created by mlukovic on 7/16/17.
 */

public class SliderContentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Block> mBlockList;
    private Context mContext;
    private ItemClickListener mItemClickListener;

    SliderContentAdapter(Context context, List<Block> blockList, ItemClickListener itemClickListener) {
        mBlockList = blockList;
        mContext = context;
        mItemClickListener = itemClickListener;
    }

    class SliderContentHolder extends RecyclerView.ViewHolder {

        ImageView ivProductImage;
        TextView tvProductTitle;
        Button btnCTA;

        public SliderContentHolder(View itemView) {
            super(itemView);
            ivProductImage = itemView.findViewById(R.id.slider_widget_image);
            tvProductTitle = itemView.findViewById(R.id.slider_widget_title);
            btnCTA = itemView.findViewById(R.id.cta_slider_button);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_slider_content_widget, parent, false);
        return new SliderContentHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Block block = mBlockList.get(position);

        SliderContentHolder sliderContentHolder = (SliderContentHolder) holder;

        GlideApp.with(mContext)
                .load(block.getImageUrl())
                .transition(withCrossFade())
                .placeholder(R.drawable.loading_placeholder)
                .error(R.drawable.loading_placeholder)
                .into(sliderContentHolder.ivProductImage);


        sliderContentHolder.tvProductTitle.setText(block.getLabel());

        if (block.getActionList() != null && block.getActionList().get(0) != null) {
            sliderContentHolder.btnCTA.setText(block.getActionList().get(0).getText());
            sliderContentHolder.btnCTA.setOnClickListener(view -> mItemClickListener.onClick(block.getActionList().get(0).getLink()));
        }
    }

    @Override
    public int getItemCount() {
        if (mBlockList == null) return 0;
        return mBlockList.size();
    }

    interface ItemClickListener {
        void onClick(String link);
    }
}
