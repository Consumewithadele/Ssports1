package com.sssports.sssports.ui.widgets.checkoutsummary;

import com.sssports.sssports.networking.services.MagentoApi;

import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Created by mlukovic on 9/1/17.
 */

public class OrderSummaryInteractorImpl implements SummaryMvpContract.Interactor {

    private MagentoApi magentoApi;
    private SummaryMvpContract.Presenter presenter;

    public OrderSummaryInteractorImpl(MagentoApi magentoApi, SummaryMvpContract.Presenter presenter) {
        this.magentoApi = magentoApi;
        this.presenter = presenter;
    }

    @Override
    public void getSummaryTotalList(String cartId) {
        magentoApi.getSummaryTotals(cartId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(cartTotalSummaryResponse -> {
                            if (cartTotalSummaryResponse.isSuccessful()) {
                                presenter.onSummaryDataReady(cartTotalSummaryResponse.body());
                            } else {
                                presenter.onSummaryDataError();
                            }
                        },
                        throwable -> {
                            Timber.d(throwable.toString());
                            presenter.onSummaryDataError();
                        });
    }
}
