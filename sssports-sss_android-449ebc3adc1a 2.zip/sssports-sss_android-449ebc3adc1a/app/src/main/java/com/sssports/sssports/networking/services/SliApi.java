package com.sssports.sssports.networking.services;

import com.sssports.sssports.models.sli.SearchResult;

import retrofit2.Response;
import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

/**
 * Created by Adeleclark on 9/3/17.
 */

public interface SliApi {

    @GET("/search")
    Observable<Response<SearchResult>> search(@Query("w") String keyword, @Query("ts") String format, @Query("cur") String currency);
}
