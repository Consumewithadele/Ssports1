package com.sssports.sssports.ui.splash;

import com.sssports.sssports.di.PerActivity;

import dagger.Module;
import dagger.Provides;

/**
 * Splash Screen module
 */

@Module
public class SplashScreenModule {

    private final SplashScreenContract.View splashScreenView;

    public SplashScreenModule(SplashScreenContract.View splashScreenView) {
        this.splashScreenView = splashScreenView;
    }

    @Provides
    @PerActivity
    SplashScreenContract.View providesSplashScreenView() {
        return splashScreenView;
    }

}
