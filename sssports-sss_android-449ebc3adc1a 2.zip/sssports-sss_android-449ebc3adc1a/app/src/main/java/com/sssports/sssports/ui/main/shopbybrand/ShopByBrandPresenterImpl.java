package com.sssports.sssports.ui.main.shopbybrand;

import android.app.Activity;

import com.hannesdorfmann.mosby3.mvp.MvpBasePresenter;
import com.sssports.sssports.SSSApp;
import com.sssports.sssports.models.jsonapi.Brand;
import com.sssports.sssports.networking.services.SSSApi;

import moe.banana.jsonapi2.Document;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Created by natalijaratajac on 7/31/17.
 */

public class ShopByBrandPresenterImpl extends MvpBasePresenter<ShopByBrandContract.ShopByBrandFragmentView> implements ShopByBrandContract.ShopByBrandFragmentPresenter {

    private ShopByBrandContract.ShopByBrandFragmentView mBrandView;
    private Activity mActivity;

    SSSApi sssApi;

    public ShopByBrandPresenterImpl(ShopByBrandContract.ShopByBrandFragmentView mBrandView,  Activity activity) {
        this.mBrandView = mBrandView;
        this.mActivity = activity;
        sssApi = ((SSSApp)activity.getApplication()).getApplicationComponent().sssService();
    }

    @Override
    public void loadData() {
        mBrandView.showLoading();
        sssApi.getBrands()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Document<Brand>>() {
                    @Override
                    public void onCompleted() {}

                    @Override
                    public void onError(Throwable e) {
                        Timber.d("Error getting Category Screen");
                        mBrandView.showError();
                        mBrandView.hideLoading();
                    }

                    @Override
                    public void onNext(Document<Brand> brandDocument) {
                        mBrandView.showBrandList(brandDocument.asArrayDocument());
                        mBrandView.showBrandLogos(brandDocument.asArrayDocument());
                        mBrandView.hideLoading();
                    }
                });
    }
}
