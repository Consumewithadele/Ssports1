package com.sssports.sssports.ui.widgets;

import android.view.View;

/**
 * Every Widget SHOULD implement this interface
 */

public interface WidgetType {

    View buildView();
}
