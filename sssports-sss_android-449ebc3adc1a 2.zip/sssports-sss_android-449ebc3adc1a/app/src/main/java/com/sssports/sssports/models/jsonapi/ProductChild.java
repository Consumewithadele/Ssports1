package com.sssports.sssports.models.jsonapi;

import com.squareup.moshi.Json;

import java.util.List;

import moe.banana.jsonapi2.HasMany;
import moe.banana.jsonapi2.JsonApi;
import moe.banana.jsonapi2.Resource;

/**
 * Created by mlukovic on 8/19/17.
 */
@JsonApi(type = "product-children")
public class ProductChild extends Resource {

    @Json(name = "type_id")
    private String typeId;
    @Json(name = "sku")
    private String sku;
    @Json(name = "created_at")
    private String createdAt;
    @Json(name = "updated_at")
    private String updatedAt;
    @Json(name = "price")
    private Double price;
    @Json(name = "final_price")
    private Double finalPrice;
    @Json(name = "parent_id")
    private Integer parentId;
    @Json(name = "name")
    private String name;
    @Json(name = "slug")
    private String slug;
    @Json(name = "thumbnail_url")
    private String thumbnailUrl;
    @Json(name = "quantity")
    private Integer quantity;
    @Json(name = "is_available")
    private Boolean isAvailable;
    @Json(name = "currency_code")
    private String currencyCode;
    @Json(name = "formatted_price")
    private String formattedPrice;
    @Json(name = "formatted_final_price")
    private String formattedFinalPrice;
    @Json(name = "color")
    private Integer color;
    @Json(name = "size")
    private Integer size;
    @Json(name = "on_sale")
    private Boolean onSale;

    private boolean isColorSelected;

    @Json(name = "images")
    private HasMany<ProductImage> images = null;

    //custom field
    private String sizeLabel;

    public ProductChild() {

    }

    public ProductChild(Product product) {
        this.sku = product.getSku();
    }

    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Integer getColor() {
        return color;
    }

    public void setColor(Integer color) {
        this.color = color;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Boolean getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(Boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public String getSizeLabel() {
        return sizeLabel;
    }

    public void setSizeLabel(String sizeLabel) {
        this.sizeLabel = sizeLabel;
    }

    @Override
    public String toString() {
        return sizeLabel;
    }

    public boolean isColorSelected() {
        return isColorSelected;
    }

    public void setColorSelected(boolean colorSelected) {
        isColorSelected = colorSelected;
    }

    public List<ProductImage> getImages() {
        return images.get(getContext());
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(Double finalPrice) {
        this.finalPrice = finalPrice;
    }

    public Boolean getOnSale() {
        return onSale;
    }

    public void setImages(HasMany<ProductImage> images) {
        this.images = images;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Boolean getAvailable() {
        return isAvailable;
    }

    public void setAvailable(Boolean available) {
        isAvailable = available;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getFormattedPrice() {
        return formattedPrice;
    }

    public void setFormattedPrice(String formattedPrice) {
        this.formattedPrice = formattedPrice;
    }

    public String getFormattedFinalPrice() {
        return formattedFinalPrice;
    }

    public void setFormattedFinalPrice(String formattedFinalPrice) {
        this.formattedFinalPrice = formattedFinalPrice;
    }

    public Boolean isOnSale() {
        return onSale;
    }

    public void setOnSale(Boolean onSale) {
        this.onSale = onSale;
    }
}
