package com.sssports.sssports.ui.pdp;

import android.text.TextUtils;

import com.sssports.sssports.locale.SPDataManager;
import com.sssports.sssports.models.jsonapi.Product;
import com.sssports.sssports.models.jsonapi.ProductChild;
import com.sssports.sssports.models.jsonapi.Screen;
import com.sssports.sssports.models.jsonapi.Widget;
import com.sssports.sssports.networking.services.MagentoApi;
import com.sssports.sssports.networking.services.SSSApi;

import moe.banana.jsonapi2.Document;
import rx.Observable;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Created by Adeleclark on 8/8/17.
 */

public class ProductDetailsPresenterImpl implements ProductDetailsContract.ProductDetailsPresenter {


    private ProductDetailsContract.ProductDetailsView view;
    private ProductChild mSelectedProductChild;
    private ProductDetailsContract.ProductDetailsInteractor interactor;

    SSSApi sssApi;

    public ProductDetailsPresenterImpl(ProductDetailsContract.ProductDetailsView view, SSSApi sssApi, MagentoApi magentoApi) {
        this.view = view;
        this.sssApi = sssApi;
        interactor = new ProductDetailsInteractorImpl(this, magentoApi);

    }

    @Override
    public void loadDataByProductId(String productId) {
        view.showLoading();

        sssApi.getProductDetails(/*"53440"*/productId, "selections.options,images,children.images")
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(product -> {
                            view.hideLoading();
                            view.showProductDetails(product);
                            loadWidgets(product);
                        },
                        error -> {
                            Timber.d("Error getting Related products: " + error.toString());
                            view.showError();
                            view.hideLoading();
                        }
                );


    }

    @Override
    public void loadDataBySku(String productSku) {
        view.showLoading();

        sssApi.getProductListDetailsBySku(/*"53440"*/productSku, "selections.options,images,children.images")
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(productList -> {
                            Product product = productList.asArrayDocument().get(0);
                            view.hideLoading();
                            view.showProductDetails(product);
                            loadWidgets(product);
                        },
                        error -> {
                            Timber.d("Error getting Related products: " + error.toString());
                            view.showError();
                            view.hideLoading();
                        }
                );
    }

    @Override
    public void onProductChildChanged(ProductChild productChild) {
        mSelectedProductChild = productChild;
        view.enableAddToBagButton(productChild != null);
    }

    @Override
    public void onCartCreated(String cartId) {
        if (mSelectedProductChild != null) {
            SPDataManager.INSTANCE.saveProductCartId(cartId);
            interactor.addToCart(cartId, mSelectedProductChild);
        }
    }

    @Override
    public void onAddToBagClick() {
        if (mSelectedProductChild != null) {
            view.showAddToBagLoader(true);
            String productCartId = SPDataManager.INSTANCE.getProductCartId();
            if (TextUtils.isEmpty(productCartId)) {
                interactor.createCart();
            } else {
                interactor.addToCart(productCartId, mSelectedProductChild);
            }
        } else {
            view.showEnableToAddToBagMessage();
        }
    }

    @Override
    public void onAddToCartSuccess() {
        view.showAddToBagLoader(false);
        view.showAddToBagSuccessDialog();
    }

    @Override
    public void addToBagError() {
        view.showAddToBagError();
        view.showAddToBagLoader(false);
    }

    private void loadWidgets(Product product) {
        Observable<Screen> screenIdForRelatedProductsObservable = sssApi.getScreenIdForRelatedProductsAndWidgets("product", 1);
        screenIdForRelatedProductsObservable
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        screen -> loadRelatedProducts(screen.getId(), product.getId()),
                        throwable -> {
                            view.showError();
                            Timber.d("Error getting Related products: " + throwable.getMessage());
                        }
                );
    }

    private void loadRelatedProducts(String screenId, String productId) {
        sssApi.getRelatedProductsAndWidgets(screenId, productId, "blocks.actions,products")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .unsubscribeOn(Schedulers.io())
                .subscribe(new Observer<Document<Widget>>() {
                               @Override
                               public void onCompleted() {
                               }

                               @Override
                               public void onError(Throwable e) {
                                   Timber.d("Error getting Category Screen");
                                   view.showError();
                                   view.hideLoading();
                               }

                               @Override
                               public void onNext(Document<Widget> widgetDocument) {
                                   view.showRelatedProductsAndWidgets(widgetDocument.asArrayDocument());
                                   view.hideLoading();
                               }
                           }
                );
    }


}
